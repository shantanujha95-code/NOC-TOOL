"""
Network Operations GUI
======================

Main window for the Network Operations tool. Launched from the backup
tool's toolbar via the "Launch Operations" button.

Features:
  1. Multi-tab SSH terminal — one-click login to selected devices,
     each in its own tab with interactive shell + config push panel.
  2. Config Push (bulk) — push config commands to multiple devices.
  3. Config Compare — side-by-side diff of two devices' running-configs.
  4. Config Templates — save/load reusable config snippets.
  5. Compliance Check — run security rules against device configs.
  6. Quick Diagnostics — show version, show interface, ping.
  7. Change History — audit trail of every config push.
"""

import difflib
import os
import sys
import threading
import queue
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkinter import font as tkfont
from datetime import datetime
from typing import Dict, List, Optional

from device_manager import DeviceManager
from ssh_session import ConfigPusher, ConfigPushResult
import putty_embed
from compliance import (
    ALL_RULES, run_compliance_for_device, DeviceComplianceReport,
)
from config_templates import TemplateManager, ConfigTemplate
from change_history import ChangeHistory, ChangeRecord
from security_utils import is_password_prompt, sanitize_error_message
from vendors import get_vendor, vendor_label as fw_vendor_label, load_custom_vendors


# ── colour constants (shared with the backup tool) ─────────────
COLORS = {
    "bg_dark":       "#1a3a5f",
    "bg_medium":     "#29629b",
    "bg_light":      "#dce8f5",
    "bg_white":      "#ffffff",
    "text_dark":     "#1a3a5f",
    "text_light":    "#ffffff",
    "text_gray":     "#666666",
    "success":       "#228b22",
    "fail":          "#c82828",
    "warning":       "#d27814",
    "row_alt":       "#f0f5fa",
    "btn_primary":   "#29629b",
    "btn_danger":    "#c82828",
    "btn_success":   "#228b22",
    "btn_warning":   "#d27814",
}

CHECK_OFF = "\u2610"


# Maximize/Restore helper — adds a button to any Toplevel header
def add_maximize_button(header_frame, dialog):
    """Add a maximize/restore button to a dialog header.

    When maximized, the dialog fills most of the screen.
    When restored, it returns to its original size and position.
    """
    state = {"maximized": False, "orig_geom": None}

    def toggle():
        if not state["maximized"]:
            # Maximize: save current geometry, expand to fill screen
            state["orig_geom"] = dialog.geometry()
            dialog.update_idletasks()
            sw = dialog.winfo_screenwidth()
            sh = dialog.winfo_screenheight()
            # Leave space for taskbar (60px) and small margin
            dialog.geometry(f"{sw-20}x{sh-100}+10+30")
            btn.configure(text="\u2611 Restore")
            state["maximized"] = True
        else:
            # Restore: return to original size and position
            if state["orig_geom"]:
                dialog.geometry(state["orig_geom"])
            btn.configure(text="\u2610 Maximize")
            state["maximized"] = False

    btn = tk.Button(
        header_frame, text="\u2610 Maximize", command=toggle,
        bg=COLORS["bg_dark"], fg=COLORS["text_light"],
        font=("Segoe UI", 8, "bold"), relief="flat",
        padx=8, pady=2, cursor="hand2", bd=0,
        activebackground=COLORS["bg_medium"],
    )
    btn.pack(side="right", padx=8, pady=4)
    return btn
CHECK_ON  = "\u2612"

# Router/Switch vendor display names
RS_VENDOR_NAMES = {
    "cisco_ios": "Cisco IOS", "cisco_xe": "Cisco IOS-XE",
    "cisco_xr": "Cisco IOS-XR", "cisco_nxos": "Cisco NX-OS",
    "juniper_junos": "Juniper JunOS", "huawei": "Huawei VRP",
    "arista_eos": "Arista EOS", "hp_comware": "HP Comware",
    "dell_os10": "Dell OS10", "dell_os6": "Dell OS6",
    "mikrotik_routeros": "MikroTik RouterOS",
    "extreme_exos": "Extreme EXOS", "ruckus_fastiron": "Ruckus FastIron",
}


# ════════════════════════════════════════════════════════════════
# SSH TERMINAL TAB
# ════════════════════════════════════════════════════════════════

class PuttyEmbeddedTab(tk.Frame):
    """One tab hosting a REAL embedded putty.exe window (Windows only),
    plus the same config-push panel as before.

    This replaces the old hand-rolled Tk-Text interactive shell. Instead
    of re-implementing terminal handling, putty.exe itself is launched
    and its native window is reparented into this tab (see
    putty_embed.py) — so every terminal-fidelity concern (colour,
    cursor-addressed full-screen apps, key handling, resize) is
    resolved by virtue of it being real PuTTY, not our code.

    The config-push panel on the right is unchanged: it already used
    its own independent ConfigPusher() connection rather than piggy-
    backing on the interactive shell, so it keeps working exactly as
    before with zero changes needed here.
    """

    def __init__(self, parent, device: dict, credentials: dict, ops_window):
        super().__init__(parent, bg=COLORS["bg_white"])
        self.device = device
        self.credentials = credentials
        self.ops_window = ops_window
        self._maximized = False
        self._saved_paned_sash = None
        self._hwnd = None
        self._proc = None
        self._closing = False
        self._resize_after_id = None
        self._watchdog_id = None
        self._launch_poll_id = None
        self._focus_poll_id = None
        self._last_left_down = False
        self._build_ui()
        self._connect()

    def _build_ui(self):
        # ── Top: device info bar ────────────────────────────────
        info_bar = tk.Frame(self, bg=COLORS["bg_dark"], height=30)
        info_bar.pack(fill="x")
        info_bar.pack_propagate(False)
        dtype = self.device.get("device_type", "").title()
        ip = self.device.get("ip_address", "?")
        host = self.device.get("hostname", "?")
        port = self.device.get("port", 22)
        status_text = f"  {host} ({ip}:{port}) — {dtype}  [Embedded PuTTY]"
        self.status_label = tk.Label(
            info_bar, text=status_text,
            bg=COLORS["bg_dark"], fg=COLORS["text_light"],
            font=("Segoe UI", 9, "bold"), anchor="w",
        )
        self.status_label.pack(side="left", padx=5)

        right_bar = tk.Frame(info_bar, bg=COLORS["bg_dark"])
        right_bar.pack(side="right", padx=5)

        self.max_btn = tk.Button(
            right_bar, text="☐ Maximize", command=self._toggle_maximize,
            bg=COLORS["bg_dark"], fg=COLORS["text_light"],
            font=("Segoe UI", 8, "bold"), relief="flat",
            padx=6, pady=0, cursor="hand2", bd=0,
            activebackground=COLORS["bg_medium"],
        )
        self.max_btn.pack(side="right", padx=(5, 0))

        self.conn_status = tk.Label(
            right_bar, text=" Launching PuTTY...",
            bg=COLORS["bg_dark"], fg="#ff9999",
            font=("Segoe UI", 9), anchor="e",
        )
        self.conn_status.pack(side="right")

        # ── Main area: embedded PuTTY (left) + config push panel (right) ──
        self.paned = tk.PanedWindow(self, orient="horizontal",
                                    bg=COLORS["bg_light"], sashwidth=4)
        self.paned.pack(fill="both", expand=True)

        # ── Left: container that will host the real PuTTY window ──
        term_frame = tk.LabelFrame(
            self.paned, text="  PuTTY (embedded)  ",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9, "bold"),
            padx=4, pady=4,
        )
        self.paned.add(term_frame, minsize=350, width=500)
        self._term_frame = term_frame

        # This inner frame's HWND is the reparent target. A dedicated
        # inner frame (rather than term_frame itself) keeps the
        # LabelFrame's own border/label out of the embedded window's
        # coordinate space.
        self.embed_frame = tk.Frame(term_frame, bg="#1e1e1e")
        self.embed_frame.pack(fill="both", expand=True)
        self.embed_frame.bind("<Configure>", self._on_container_resize)

        self._not_supported_label = None
        if not putty_embed.is_supported():
            self._not_supported_label = tk.Label(
                self.embed_frame,
                text="Embedded PuTTY requires Windows.\n"
                     "Use 'External PuTTY (separate window)' from the\n"
                     "toolbar dropdown instead on this platform.",
                bg="#1e1e1e", fg="#ff9999", font=("Segoe UI", 10),
                justify="center",
            )
            self._not_supported_label.pack(expand=True)

        # ── Right: config push panel (unchanged from before) ───
        push_frame = tk.LabelFrame(
            self.paned, text="  Config Push  ",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9, "bold"),
            padx=8, pady=8,
        )
        self.paned.add(push_frame, minsize=250, width=350)
        self._push_frame = push_frame

        tk.Label(push_frame, text="Config Commands (one per line):",
                 bg=COLORS["bg_white"], font=("Segoe UI", 9, "bold"),
                 ).pack(anchor="w", pady=(0, 4))

        self.push_text = tk.Text(
            push_frame, height=10, font=("Consolas", 9),
            bg="#fafafa", relief="solid", bd=1, wrap="none",
        )
        self.push_text.pack(fill="both", expand=True, pady=(0, 8))

        tpl_row = tk.Frame(push_frame, bg=COLORS["bg_white"])
        tpl_row.pack(fill="x", pady=(0, 4))
        tk.Label(tpl_row, text="Template:", bg=COLORS["bg_white"],
                 font=("Segoe UI", 8)).pack(side="left", padx=(0, 4))
        self.tpl_var = tk.StringVar(value="(none)")
        tpl_combo = ttk.Combobox(tpl_row, textvariable=self.tpl_var,
                                 values=self._get_template_names(),
                                 state="readonly", width=20)
        tpl_combo.pack(side="left", fill="x", expand=True)
        tpl_combo.bind("<<ComboboxSelected>>", self._on_template_select)

        tk.Button(push_frame, text="Push Config to This Device",
                  command=self._push_config,
                  bg=COLORS["btn_success"], fg="white",
                  font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=10, pady=4, cursor="hand2",
                  ).pack(fill="x", pady=(4, 0))

        tk.Label(push_frame, text="Output:", bg=COLORS["bg_white"],
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", pady=(8, 2))
        self.push_output = tk.Text(
            push_frame, height=8, font=("Consolas", 8),
            bg="#f5f5f5", relief="solid", bd=1, state="disabled",
            wrap="word",
        )
        self.push_output.pack(fill="both", expand=True)

    # ── Maximize / Restore ─────────────────────────────────────
    def _toggle_maximize(self):
        if not self._maximized:
            self._saved_paned_sash = self.paned.sash_coord(0)[0]
            self._push_frame.pack_forget()
            self.paned.forget(self._push_frame)
            self.max_btn.configure(text="☐ Restore")
            self._maximized = True
        else:
            self.paned.add(self._push_frame, minsize=250, width=350)
            self.max_btn.configure(text="☐ Maximize")
            self._maximized = False
            if self._saved_paned_sash:
                try:
                    self.paned.sash_place(0, self._saved_paned_sash, 0)
                except Exception:
                    pass
        # Also collapse/restore the device list on the left of the main
        # window down to just the checkbox + hostname columns, so the
        # terminal gets the width freed up rather than just the config
        # push panel's space within this one tab.
        self.ops_window._set_device_panel_maximized(self._maximized)

        # The paned-window reconfigure changes the embedded PuTTY
        # window's size, and clicking the Maximize button itself moves
        # keyboard focus to that Tk button — deterministically hand
        # focus back to the terminal once the layout settles, so you
        # don't have to click into it again just to keep typing. Delay
        # lets the <Configure>-triggered resize (see
        # _on_container_resize) land first.
        if self._hwnd:
            self.after(150, self.focus_terminal)

    # ── Launch + embed real putty.exe ───────────────────────────
    def _connect(self):
        if not putty_embed.is_supported():
            self.conn_status.configure(text=" Unsupported platform", fg="#ff9999")
            return

        ops_win = self.ops_window
        putty_path = ops_win._find_putty()
        if not putty_path:
            self.conn_status.configure(text=" PuTTY not found", fg="#ff9999")
            messagebox.showerror(
                "PuTTY Not Found",
                "Could not find putty.exe on this system.\n\n"
                "Install PuTTY (https://www.putty.org) and make sure "
                "putty.exe is on your PATH, or place it alongside this "
                "application, then try again.",
                parent=self)
            return

        host = self.device.get("ip_address", "")
        port = self.device.get("port", 22)
        username = self.credentials.get("username", "")
        password = self.credentials.get("password", "")
        enable_password = self.credentials.get("enable_password", "")
        device_type = self.device.get("device_type", "")

        # Tkinter widgets, including self.after(), must only be touched from
        # the Tk/main thread. The old implementation called self.after()
        # directly from _do_launch(), which runs in a worker thread. On
        # Windows this can leave the callback queued behind Tcl's thread
        # boundary (or fail with a TclError), producing the exact CI symptom
        # where PuTTY is alive and find_window_by_pid() succeeds, but
        # self._hwnd never gets populated.
        #
        # Keep ALL PuTTY process/window discovery in the worker, then use a
        # small main-thread poll to consume the result.
        result_queue = queue.Queue()

        def _do_launch():
            try:
                proc = putty_embed.launch(
                    putty_path, host, port, username, password
                )
                hwnd = putty_embed.find_window_by_pid(
                    proc.pid, timeout=8.0
                )
                result_queue.put(("ok", proc, hwnd))

                # Auto-enter enable mode the same way the old paramiko flow
                # did. This remains in the worker because it intentionally
                # sleeps between keystrokes and does not touch Tk widgets.
                if hwnd and enable_password and "cisco" in device_type:
                    putty_embed.auto_enable_sequence(
                        hwnd, enable_password
                    )
            except putty_embed.PuttyLaunchError as e:
                result_queue.put(("error", str(e)))
            except Exception as e:
                result_queue.put(("error", str(e)))

        def _consume_launch_result():
            if self._closing:
                return

            try:
                result = result_queue.get_nowait()
            except queue.Empty:
                self._launch_poll_id = self.after(50, _consume_launch_result)
                return

            if result[0] == "error":
                self._on_launch_failed(result[1])
                return

            _, proc, hwnd = result
            self._proc = proc
            self._on_window_found(hwnd)

        self._launch_poll_id = self.after(50, _consume_launch_result)
        threading.Thread(target=_do_launch, daemon=True).start()

    def _on_launch_failed(self, err: str):
        self.conn_status.configure(text=" Launch failed", fg="#ff9999")
        messagebox.showerror(
            "Launch Failed",
            f"Could not launch PuTTY for {self.device.get('hostname', '?')}:\n{err}",
            parent=self)

    def _on_window_found(self, hwnd):
        if self._closing:
            if hwnd:
                putty_embed.close(hwnd)
            return
        if not hwnd:
            self.conn_status.configure(text=" Window not found", fg="#ff9999")
            messagebox.showwarning(
                "PuTTY Window Not Found",
                "PuTTY launched but its window couldn't be located in time.\n"
                "It may still be open as a separate window.",
                parent=self)
            return

        self._hwnd = hwnd
        container_hwnd = self.embed_frame.winfo_id()
        w = max(1, self.embed_frame.winfo_width())
        h = max(1, self.embed_frame.winfo_height())
        putty_embed.embed(hwnd, container_hwnd, w, h)
        self.conn_status.configure(text=" Connected ✓ (real PuTTY)", fg="#99ff99")
        putty_embed.focus(hwnd)

        # Watch for the user closing PuTTY itself (e.g. via its own
        # system menu before we stripped it, or the process exiting).
        self._watchdog_id = self.after(1000, self._watchdog)

        # Makes clicking back into this terminal after clicking away
        # reliably regain keyboard focus. See the long comment on
        # putty_embed.is_left_button_down for why this is a poll
        # rather than a system-wide mouse hook.
        self._last_left_down = False
        self._focus_poll_id = self.after(20, self._poll_click_focus)

    def _poll_click_focus(self):
        if self._closing:
            return
        if not self._hwnd:
            self._focus_poll_id = self.after(20, self._poll_click_focus)
            return
        try:
            down = putty_embed.is_left_button_down()
            if down and not self._last_left_down:
                x, y = putty_embed.get_cursor_pos()
                fx = self.embed_frame.winfo_rootx()
                fy = self.embed_frame.winfo_rooty()
                fw = self.embed_frame.winfo_width()
                fh = self.embed_frame.winfo_height()
                if fx <= x <= fx + fw and fy <= y <= fy + fh:
                    putty_embed.focus(self._hwnd)
            self._last_left_down = down
        except Exception:
            pass
        self._focus_poll_id = self.after(20, self._poll_click_focus)

    def _watchdog(self):
        if self._closing:
            return
        if self._hwnd and not putty_embed.is_window_alive(self._hwnd):
            self.conn_status.configure(text=" Disconnected", fg="#ff9999")
            self._hwnd = None
            return
        self._watchdog_id = self.after(1000, self._watchdog)

    def _on_container_resize(self, event):
        if self._resize_after_id:
            self.after_cancel(self._resize_after_id)
        self._resize_after_id = self.after(80, self._do_container_resize)

    def _do_container_resize(self):
        self._resize_after_id = None
        if self._hwnd:
            putty_embed.resize(self._hwnd, self.embed_frame.winfo_width(),
                                self.embed_frame.winfo_height())

    def focus_terminal(self):
        """Called by NetworkOperationsWindow when this tab becomes the
        selected notebook tab, so typing goes to PuTTY immediately."""
        if self._hwnd:
            putty_embed.focus(self._hwnd)

    # ── Config push panel (unchanged logic) ─────────────────────
    def _get_template_names(self):
        names = ["(none)"]
        try:
            names += [t.name for t in self.ops_window.template_manager.get_all()]
        except Exception:
            pass
        return names

    def _on_template_select(self, event):
        name = self.tpl_var.get()
        if name == "(none)":
            return
        tpl = self.ops_window.template_manager.get_by_name(name)
        if tpl:
            self.push_text.delete("1.0", "end")
            self.push_text.insert("1.0", "\n".join(tpl.commands))

    def _push_config(self):
        """Push the config commands from the right panel to this device.

        Uses its own independent ConfigPusher connection — this was
        already decoupled from the interactive-shell channel before
        this refactor, so it's untouched by the switch to embedded
        PuTTY.
        """
        commands_text = self.push_text.get("1.0", "end").strip()
        if not commands_text:
            messagebox.showinfo("Info", "No commands to push.", parent=self)
            return
        commands = [c.strip() for c in commands_text.splitlines() if c.strip()]
        if not commands:
            return

        if not messagebox.askyesno(
            "Confirm Config Push",
            f"Push {len(commands)} command(s) to {self.device['hostname']} ({self.device['ip_address']})?\n\n"
            "This will modify the device configuration.",
            parent=self,
        ):
            return

        self.push_output.configure(state="normal")
        self.push_output.delete("1.0", "end")
        self.push_output.insert("end", f"Pushing {len(commands)} command(s)...\n\n")
        self.push_output.configure(state="disabled")

        def _do_push():
            pusher = ConfigPusher()
            result = pusher.push_config(self.device, commands, self.credentials)
            self.after(0, lambda: self._on_push_done(result, commands))

        threading.Thread(target=_do_push, daemon=True).start()

    def _on_push_done(self, result: ConfigPushResult, commands: List[str]):
        self.push_output.configure(state="normal")
        self.push_output.delete("1.0", "end")
        if result.success:
            self.push_output.insert("end", "✓ Config pushed successfully\n\n", "success")
            self.push_output.tag_configure("success", foreground=COLORS["success"])
            self.push_output.insert("end", result.output)
        else:
            self.push_output.insert("end", "✗ Config push failed\n\n", "error")
            self.push_output.tag_configure("error", foreground=COLORS["fail"])
            self.push_output.insert("end", f"Error: {result.error}\n")
        self.push_output.configure(state="disabled")

        self.ops_window.change_history.add(ChangeRecord(
            device_id=self.device.get("id", ""),
            hostname=self.device.get("hostname", ""),
            ip_address=self.device.get("ip_address", ""),
            device_type=self.device.get("device_type", ""),
            commands=commands,
            success=result.success,
            error=result.error,
            output=result.output,
        ))

    def close(self):
        """Clean up: stop the watchdog and close the real PuTTY process."""
        self._closing = True
        if self._watchdog_id:
            self.after_cancel(self._watchdog_id)
            self._watchdog_id = None
        if self._resize_after_id:
            self.after_cancel(self._resize_after_id)
            self._resize_after_id = None
        if self._launch_poll_id:
            self.after_cancel(self._launch_poll_id)
            self._launch_poll_id = None
        if self._hwnd:
            putty_embed.unregister_focus_target(self._hwnd)
            putty_embed.close(self._hwnd)
            self._hwnd = None
        elif self._proc:
            try:
                self._proc.terminate()
            except Exception:
                pass




# ════════════════════════════════════════════════════════════════
# CONFIG COMPARE DIALOG
# ════════════════════════════════════════════════════════════════

class ConfigCompareDialog(tk.Toplevel):
    """Compare running-configs of two devices side by side.

    Layout:
      - Device selectors at top
      - Two side-by-side text panels (Device A left, Device B right)
        with synchronized scrolling
      - Unified diff at the bottom showing what changed
    """

    def __init__(self, parent, manager: DeviceManager, ops_window):
        super().__init__(parent)
        self.manager = manager
        self.ops_window = ops_window
        self.title("Compare Device Configurations")
        self.configure(bg=COLORS["bg_white"])
        self.geometry("1200x800")
        self.transient(parent)

        x = parent.winfo_x() + (parent.winfo_width() - 1200) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 800) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        # Last comparison results, kept around so Export has something
        # to write even after the dialog's been open a while.
        self._last_config_a = ""
        self._last_config_b = ""
        self._last_diff_lines = []
        self._last_dev_a = None
        self._last_dev_b = None

        self._build_ui()

    def _build_ui(self):
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="  Compare Device Configurations",
                 bg=COLORS["bg_dark"], fg=COLORS["text_light"],
                 font=("Segoe UI", 13, "bold")).pack(side="left", padx=10)
        add_maximize_button(header, self)

        # Device selectors
        sel_frame = tk.Frame(self, bg=COLORS["bg_light"])
        sel_frame.pack(fill="x", padx=15, pady=10)

        devices = self.manager.get_all_devices()
        device_labels = [f"{d['hostname']} ({d['ip_address']})" for d in devices]

        tk.Label(sel_frame, text="Device A:", bg=COLORS["bg_light"],
                 font=("Segoe UI", 9, "bold")).grid(row=0, column=0, padx=5, pady=5)
        self.dev_a_var = tk.StringVar()
        ttk.Combobox(sel_frame, textvariable=self.dev_a_var,
                     values=device_labels, state="readonly", width=30).grid(
            row=0, column=1, padx=5)

        tk.Label(sel_frame, text="Device B:", bg=COLORS["bg_light"],
                 font=("Segoe UI", 9, "bold")).grid(row=0, column=2, padx=5, pady=5)
        self.dev_b_var = tk.StringVar()
        ttk.Combobox(sel_frame, textvariable=self.dev_b_var,
                     values=device_labels, state="readonly", width=30).grid(
            row=0, column=3, padx=5)

        tk.Button(sel_frame, text="Compare", command=self._do_compare,
                  bg=COLORS["btn_primary"], fg="white",
                  font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=15, pady=3, cursor="hand2").grid(
            row=0, column=4, padx=10)

        # Sync-scroll toggle: on by default (matches old behavior), but
        # each panel can scroll independently when unchecked so you can
        # e.g. keep Device A's interface section in view while scrolling
        # down Device B to find the matching block.
        self.sync_scroll_var = tk.BooleanVar(value=True)
        tk.Checkbutton(sel_frame, text="Sync Scrolling", variable=self.sync_scroll_var,
                       bg=COLORS["bg_light"], font=("Segoe UI", 9),
                       ).grid(row=0, column=5, padx=(15, 5))

        tk.Button(sel_frame, text="Export...", command=self._export_comparison,
                  bg=COLORS["btn_success"], fg="white",
                  font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=15, pady=3, cursor="hand2").grid(
            row=0, column=6, padx=10)

        # ── Side-by-side panels ────────────────────────────────
        # PanedWindow: Device A config (left) | Device B config (right)
        side_paned = tk.PanedWindow(self, orient="horizontal",
                                    bg=COLORS["bg_light"], sashwidth=4)
        side_paned.pack(fill="both", expand=True, padx=15, pady=(0, 4))

        # Left: Device A
        left_frame = tk.LabelFrame(side_paned, text="  Device A Config  ",
                                   bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                                   font=("Segoe UI", 9, "bold"),
                                   padx=2, pady=2)
        side_paned.add(left_frame, minsize=400)

        self.text_a = tk.Text(left_frame, wrap="none", font=("Consolas", 9),
                              bg="#1e1e1e", fg="#d4d4d4", relief="flat",
                              state="disabled")
        scroll_a_y = ttk.Scrollbar(left_frame, orient="vertical", command=self._on_scroll_a)
        scroll_a_x = ttk.Scrollbar(left_frame, orient="horizontal", command=self.text_a.xview)
        self.text_a.configure(yscrollcommand=self._set_scroll_a, xscrollcommand=scroll_a_x.set)
        self.text_a.pack(side="left", fill="both", expand=True)
        scroll_a_y.pack(side="right", fill="y")
        scroll_a_x.pack(side="bottom", fill="x")
        self._scroll_a_y = scroll_a_y

        # Right: Device B
        right_frame = tk.LabelFrame(side_paned, text="  Device B Config  ",
                                    bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                                    font=("Segoe UI", 9, "bold"),
                                    padx=2, pady=2)
        side_paned.add(right_frame, minsize=400)

        self.text_b = tk.Text(right_frame, wrap="none", font=("Consolas", 9),
                              bg="#1e1e1e", fg="#d4d4d4", relief="flat",
                              state="disabled")
        scroll_b_y = ttk.Scrollbar(right_frame, orient="vertical", command=self._on_scroll_b)
        scroll_b_x = ttk.Scrollbar(right_frame, orient="horizontal", command=self.text_b.xview)
        self.text_b.configure(yscrollcommand=self._set_scroll_b, xscrollcommand=scroll_b_x.set)
        self.text_b.pack(side="left", fill="both", expand=True)
        scroll_b_y.pack(side="right", fill="y")
        scroll_b_x.pack(side="bottom", fill="x")
        self._scroll_b_y = scroll_b_y

        # ── Unified diff (bottom) ──────────────────────────────
        diff_frame = tk.LabelFrame(self, text="  Unified Diff  ",
                                   bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                                   font=("Segoe UI", 9, "bold"),
                                   padx=2, pady=2)
        diff_frame.pack(fill="both", expand=False, padx=15, pady=(4, 15))
        diff_frame.configure(height=180)
        diff_frame.pack_propagate(False)

        self.diff_text = tk.Text(diff_frame, wrap="none", font=("Consolas", 8),
                                 bg="#1e1e1e", fg="#d4d4d4", relief="flat",
                                 state="disabled", height=8)
        diff_scroll_y = ttk.Scrollbar(diff_frame, orient="vertical", command=self.diff_text.yview)
        diff_scroll_x = ttk.Scrollbar(diff_frame, orient="horizontal", command=self.diff_text.xview)
        self.diff_text.configure(yscrollcommand=diff_scroll_y.set, xscrollcommand=diff_scroll_x.set)
        self.diff_text.pack(side="left", fill="both", expand=True)
        diff_scroll_y.pack(side="right", fill="y")
        diff_scroll_x.pack(side="bottom", fill="x")

        self.diff_text.tag_configure("added", foreground="#4ec9b0")
        self.diff_text.tag_configure("removed", foreground="#f44747")
        self.diff_text.tag_configure("header", foreground="#569cd6")
        self.diff_text.tag_configure("hunk", foreground="#ce9178")

        self.status_label = tk.Label(
            self, text="Select two devices and click Compare.",
            bg=COLORS["bg_white"], fg=COLORS["text_gray"],
            font=("Segoe UI", 9),
        )
        self.status_label.pack(pady=(0, 5))

    # ── Synchronized scrolling (each panel also has its own scrollbar
    # for fully independent scrolling — see the "Sync Scrolling" toggle) ──
    def _on_scroll_a(self, *args):
        """When panel A's scrollbar is dragged, scroll panel A (and B if synced)."""
        self.text_a.yview(*args)
        if self.sync_scroll_var.get():
            self.text_b.yview_moveto(self.text_a.yview()[0])
            self._scroll_b_y.set(*self.text_a.yview())

    def _on_scroll_b(self, *args):
        """When panel B's scrollbar is dragged, scroll panel B (and A if synced)."""
        self.text_b.yview(*args)
        if self.sync_scroll_var.get():
            self.text_a.yview_moveto(self.text_b.yview()[0])
            self._scroll_a_y.set(*self.text_b.yview())

    def _set_scroll_a(self, first, last):
        """Callback from text_a's yscrollcommand (mouse wheel, keys, etc.)."""
        self._scroll_a_y.set(first, last)
        if self.sync_scroll_var.get():
            self.text_b.yview_moveto(first)

    def _set_scroll_b(self, first, last):
        """Callback from text_b's yscrollcommand (mouse wheel, keys, etc.)."""
        self._scroll_b_y.set(first, last)
        if self.sync_scroll_var.get():
            self.text_a.yview_moveto(first)

    def _do_compare(self):
        a_label = self.dev_a_var.get()
        b_label = self.dev_b_var.get()
        if not a_label or not b_label:
            messagebox.showwarning("Selection", "Please select both devices.", parent=self)
            return
        if a_label == b_label:
            messagebox.showwarning("Selection", "Please select two different devices.", parent=self)
            return

        devices = self.manager.get_all_devices()
        dev_a = next((d for d in devices if f"{d['hostname']} ({d['ip_address']})" == a_label), None)
        dev_b = next((d for d in devices if f"{d['hostname']} ({d['ip_address']})" == b_label), None)
        if not dev_a or not dev_b:
            return

        self.status_label.configure(text="Fetching running-config from both devices...")
        self.update()

        def _fetch_and_diff():
            pusher = ConfigPusher()
            try:
                creds_a = self.ops_window._get_credentials_for(dev_a)
                creds_b = self.ops_window._get_credentials_for(dev_b)
                if not creds_a or not creds_a.get("username"):
                    self.after(0, lambda: self.status_label.configure(
                        text=f"No credentials for {dev_a['hostname']}"))
                    return
                if not creds_b or not creds_b.get("username"):
                    self.after(0, lambda: self.status_label.configure(
                        text=f"No credentials for {dev_b['hostname']}"))
                    return

                config_a = pusher.fetch_running_config(dev_a, creds_a)
                config_b = pusher.fetch_running_config(dev_b, creds_b)

                diff = list(difflib.unified_diff(
                    config_a.splitlines(), config_b.splitlines(),
                    fromfile=f"{dev_a['hostname']} ({dev_a['ip_address']})",
                    tofile=f"{dev_b['hostname']} ({dev_b['ip_address']})",
                    lineterm="",
                ))

                self.after(0, lambda: self._show_results(config_a, config_b, diff, dev_a, dev_b))

            except Exception as e:
                self.after(0, lambda: self.status_label.configure(text=f"Error: {e}"))

        threading.Thread(target=_fetch_and_diff, daemon=True).start()

    def _show_results(self, config_a, config_b, diff_lines, dev_a, dev_b):
        # Stash for Export
        self._last_config_a = config_a
        self._last_config_b = config_b
        self._last_diff_lines = diff_lines
        self._last_dev_a = dev_a
        self._last_dev_b = dev_b

        # Populate Device A panel
        self.text_a.configure(state="normal")
        self.text_a.delete("1.0", "end")
        self.text_a.insert("1.0", config_a)
        self.text_a.configure(state="disabled")

        # Populate Device B panel
        self.text_b.configure(state="normal")
        self.text_b.delete("1.0", "end")
        self.text_b.insert("1.0", config_b)
        self.text_b.configure(state="disabled")

        # Update labels
        self.text_a.master.configure(text=f"  Device A: {dev_a['hostname']} ({dev_a['ip_address']})  ")
        self.text_b.master.configure(text=f"  Device B: {dev_b['hostname']} ({dev_b['ip_address']})  ")

        # Populate unified diff
        self.diff_text.configure(state="normal")
        self.diff_text.delete("1.0", "end")
        if not diff_lines:
            self.diff_text.insert("end", "*** Configurations are identical — no differences found ***")
            self.status_label.configure(text="Configurations are identical.")
        else:
            added = sum(1 for l in diff_lines if l.startswith("+") and not l.startswith("+++"))
            removed = sum(1 for l in diff_lines if l.startswith("-") and not l.startswith("---"))
            self.status_label.configure(
                text=f"Found {added} added and {removed} removed lines.")
            for line in diff_lines:
                if line.startswith("+++") or line.startswith("---"):
                    self.diff_text.insert("end", line + "\n", "header")
                elif line.startswith("@@"):
                    self.diff_text.insert("end", line + "\n", "hunk")
                elif line.startswith("+"):
                    self.diff_text.insert("end", line + "\n", "added")
                elif line.startswith("-"):
                    self.diff_text.insert("end", line + "\n", "removed")
                else:
                    self.diff_text.insert("end", line + "\n")
        self.diff_text.configure(state="disabled")

    def _export_comparison(self):
        """Write Device A config, Device B config, and the unified diff
        to a single text file the user picks a location for."""
        if self._last_dev_a is None or self._last_dev_b is None:
            messagebox.showinfo(
                "Nothing to Export",
                "Run a comparison first (select two devices and click Compare).",
                parent=self)
            return

        default_name = f"compare_{self._last_dev_a['hostname']}_vs_{self._last_dev_b['hostname']}.txt"
        path = filedialog.asksaveasfilename(
            parent=self,
            title="Export Comparison",
            initialfile=default_name,
            defaultextension=".txt",
            filetypes=[("Text file", "*.txt"), ("All files", "*.*")],
        )
        if not path:
            return

        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("=" * 70 + "\n")
                f.write("DEVICE CONFIGURATION COMPARISON\n")
                f.write("=" * 70 + "\n")
                f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")

                f.write("-" * 70 + "\n")
                f.write(f"DEVICE A: {self._last_dev_a['hostname']} ({self._last_dev_a['ip_address']})\n")
                f.write("-" * 70 + "\n")
                f.write(self._last_config_a + "\n\n")

                f.write("-" * 70 + "\n")
                f.write(f"DEVICE B: {self._last_dev_b['hostname']} ({self._last_dev_b['ip_address']})\n")
                f.write("-" * 70 + "\n")
                f.write(self._last_config_b + "\n\n")

                f.write("-" * 70 + "\n")
                f.write("UNIFIED DIFF\n")
                f.write("-" * 70 + "\n")
                if self._last_diff_lines:
                    f.write("\n".join(self._last_diff_lines) + "\n")
                else:
                    f.write("(configurations are identical — no differences found)\n")

            messagebox.showinfo("Export Complete", f"Comparison exported to:\n{path}", parent=self)
        except Exception as e:
            messagebox.showerror("Export Failed", f"Could not write file:\n{e}", parent=self)


# ════════════════════════════════════════════════════════════════
# CUSTOM COMPLIANCE RULES DIALOG
# ════════════════════════════════════════════════════════════════

class CustomRulesDialog(tk.Toplevel):
    """Create, edit, and delete custom compliance rules.

    Custom rules use regex patterns to check the running-config. Each
    rule specifies:
      - A regex pattern to search for
      - Whether the pattern SHOULD be found (pass) or should NOT be found (fail)
      - Pass/fail messages
    Rules are stored in compliance_rules.json.
    """

    def __init__(self, parent, compliance_dialog):
        super().__init__(parent)
        self.compliance_dialog = compliance_dialog
        self.title("Custom Compliance Rules")
        self.configure(bg=COLORS["bg_white"])
        self.geometry("700x550")
        self.transient(parent)
        self.grab_set()

        x = parent.winfo_x() + (parent.winfo_width() - 700) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 550) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        self._build_ui()
        self._refresh_list()

    def _build_ui(self):
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="  Custom Compliance Rules",
                 bg=COLORS["bg_dark"], fg=COLORS["text_light"],
                 font=("Segoe UI", 13, "bold")).pack(side="left", padx=10)
        add_maximize_button(header, self)

        # Left: rule list
        left = tk.LabelFrame(self, text="  Rules  ",
                             bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                             font=("Segoe UI", 10, "bold"),
                             padx=8, pady=8, bd=1, relief="solid")
        left.pack(side="left", fill="both", expand=True, padx=(10, 5), pady=10)
        left.configure(width=260)
        left.pack_propagate(False)

        cols = ("label",)
        self.tree = ttk.Treeview(left, columns=cols, show="headings", height=10)
        self.tree.heading("label", text="Rule Name")
        self.tree.column("label", width=220, minwidth=100)
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        btn_frame = tk.Frame(left, bg=COLORS["bg_white"])
        btn_frame.pack(fill="x", pady=(8, 0))
        tk.Button(btn_frame, text="New", command=self._new,
                  bg=COLORS["btn_success"], fg="white", font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=10, pady=2, cursor="hand2").pack(side="left", padx=2)
        tk.Button(btn_frame, text="Delete", command=self._delete,
                  bg=COLORS["btn_danger"], fg="white", font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=10, pady=2, cursor="hand2").pack(side="left", padx=2)

        # Right: edit form
        right = tk.LabelFrame(self, text="  Rule Details  ",
                              bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                              font=("Segoe UI", 10, "bold"),
                              padx=10, pady=10, bd=1, relief="solid")
        right.pack(side="left", fill="both", expand=True, padx=(5, 10), pady=10)

        pad = {"padx": 5, "pady": 3}

        tk.Label(right, text="Rule Key *", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w", **pad)
        self.key_var = tk.StringVar()
        ttk.Entry(right, textvariable=self.key_var, width=25).grid(row=0, column=1, sticky="ew", **pad)

        tk.Label(right, text="Label *", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).grid(row=1, column=0, sticky="w", **pad)
        self.label_var = tk.StringVar()
        ttk.Entry(right, textvariable=self.label_var, width=25).grid(row=1, column=1, sticky="ew", **pad)

        tk.Label(right, text="Description", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9)).grid(row=2, column=0, sticky="w", **pad)
        self.desc_var = tk.StringVar()
        ttk.Entry(right, textvariable=self.desc_var, width=25).grid(row=2, column=1, sticky="ew", **pad)

        tk.Label(right, text="Regex Pattern *", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).grid(row=3, column=0, sticky="nw", **pad)
        self.pattern_var = tk.StringVar()
        ttk.Entry(right, textvariable=self.pattern_var, width=25).grid(row=3, column=1, sticky="ew", **pad)
        tk.Label(right, text="(e.g. 'access-list .* deny ip any any')",
                 bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                 font=("Segoe UI", 8)).grid(row=4, column=1, sticky="w", padx=5)

        tk.Label(right, text="Match Mode", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).grid(row=5, column=0, sticky="w", **pad)
        self.match_var = tk.StringVar(value="should_match")
        ttk.Combobox(right, textvariable=self.match_var, state="readonly", width=22,
                     values=["should_match (PASS if found)",
                             "should_not_match (FAIL if found)"]).grid(row=5, column=1, sticky="ew", **pad)

        tk.Label(right, text="Pass Message", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9)).grid(row=6, column=0, sticky="w", **pad)
        self.pass_msg_var = tk.StringVar()
        ttk.Entry(right, textvariable=self.pass_msg_var, width=25).grid(row=6, column=1, sticky="ew", **pad)

        tk.Label(right, text="Fail Message", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9)).grid(row=7, column=0, sticky="w", **pad)
        self.fail_msg_var = tk.StringVar()
        ttk.Entry(right, textvariable=self.fail_msg_var, width=25).grid(row=7, column=1, sticky="ew", **pad)

        btn_row = tk.Frame(right, bg=COLORS["bg_white"])
        btn_row.grid(row=8, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        tk.Button(btn_row, text="Save Rule", command=self._save,
                  bg=COLORS["btn_primary"], fg="white", font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=15, pady=4, cursor="hand2").pack(side="left", padx=2)
        tk.Button(btn_row, text="Load Example", command=self._load_example,
                  bg=COLORS["btn_warning"], fg="white", font=("Segoe UI", 9),
                  relief="flat", padx=10, pady=4, cursor="hand2").pack(side="left", padx=2)

        self.example_label = tk.Label(right, text="",
                                      bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                                      font=("Segoe UI", 8, "italic"), justify="left", wraplength=350)
        self.example_label.grid(row=9, column=0, columnspan=2, sticky="ew", pady=(4, 0))

        right.columnconfigure(1, weight=1)

    def _refresh_list(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for r in self.compliance_dialog._custom_rules:
            self.tree.insert("", "end", values=(r.get("label", "?"),), iid=r.get("key", ""))

    def _on_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        key = sel[0]
        for r in self.compliance_dialog._custom_rules:
            if r.get("key") == key:
                self.key_var.set(r.get("key", ""))
                self.label_var.set(r.get("label", ""))
                self.desc_var.set(r.get("description", ""))
                self.pattern_var.set(r.get("pattern", ""))
                self.match_var.set(
                    "should_match (PASS if found)" if r.get("should_match", True)
                    else "should_not_match (FAIL if found)")
                self.pass_msg_var.set(r.get("pass_message", ""))
                self.fail_msg_var.set(r.get("fail_message", ""))
                break

    EXAMPLE_RULES = [
        {"key": "no_http_server", "label": "No HTTP Server",
         "description": "HTTP server should be disabled (use HTTPS only)",
         "pattern": r"no\s+ip\s+http\s+server", "should_match": True,
         "pass_message": "HTTP server is disabled",
         "fail_message": "HTTP server is NOT disabled"},
        {"key": "acl_on_vty", "label": "ACL on VTY Lines",
         "description": "An access-list should be applied to VTY lines",
         "pattern": r"access-class\s+\d+\s+in", "should_match": True,
         "pass_message": "Access-list is applied to VTY lines",
         "fail_message": "No access-list on VTY lines"},
        {"key": "no_cdp_run", "label": "CDP Disabled on Edge",
         "description": "CDP should be disabled on edge ports",
         "pattern": r"no\s+cdp\s+enable", "should_match": True,
         "pass_message": "CDP is disabled on at least one interface",
         "fail_message": "CDP is enabled everywhere (info leak risk)"},
        {"key": "console_password", "label": "Console Password Set",
         "description": "Console port should have a password",
         "pattern": r"line\s+con\s+0.*?password", "should_match": True,
         "pass_message": "Console password is configured",
         "fail_message": "No console password set"},
        {"key": "no_directed_broadcast", "label": "No Directed Broadcast",
         "description": "Directed broadcasts should be disabled (smurf attack prevention)",
         "pattern": r"no\s+ip\s+directed-broadcast", "should_match": True,
         "pass_message": "Directed broadcast is disabled",
         "fail_message": "Directed broadcast is enabled (smurf risk)"},
        {"key": "no_source_route", "label": "No Source Routing",
         "description": "IP source routing should be disabled (spoofing prevention)",
         "pattern": r"no\s+ip\s+source-route", "should_match": True,
         "pass_message": "IP source routing is disabled",
         "fail_message": "IP source routing is enabled (spoofing risk)"},
    ]
    _example_index = [0]

    def _load_example(self):
        """Load the next example rule into the form."""
        idx = self._example_index[0] % len(self.EXAMPLE_RULES)
        ex = self.EXAMPLE_RULES[idx]
        self._example_index[0] += 1
        self.key_var.set(ex["key"])
        self.label_var.set(ex["label"])
        self.desc_var.set(ex["description"])
        self.pattern_var.set(ex["pattern"])
        self.match_var.set("should_match (PASS if found)" if ex["should_match"]
                           else "should_not_match (FAIL if found)")
        self.pass_msg_var.set(ex["pass_message"])
        self.fail_msg_var.set(ex["fail_message"])
        total = len(self.EXAMPLE_RULES)
        next_num = (self._example_index[0] % total) + 1
        self.example_label.configure(
            text=f"Example {idx+1}/{total}: {ex['description']}. "
                 f"Click 'Load Example' again for next. Edit and 'Save Rule' to add."
        )
        self.tree.selection_remove(self.tree.selection())

    def _new(self):
        self.key_var.set("")
        self.label_var.set("")
        self.desc_var.set("")
        self.pattern_var.set("")
        self.match_var.set("should_match (PASS if found)")
        self.pass_msg_var.set("")
        self.fail_msg_var.set("")
        self.tree.selection_remove(self.tree.selection())

    def _save(self):
        key = self.key_var.get().strip().lower().replace(" ", "_")
        label = self.label_var.get().strip()
        pattern = self.pattern_var.get().strip()
        if not key or not label or not pattern:
            messagebox.showwarning("Validation", "Key, Label, and Regex Pattern are required.", parent=self)
            return
        should_match = self.match_var.get().startswith("should_match")
        rule = {
            "key": key,
            "label": label,
            "description": self.desc_var.get().strip(),
            "pattern": pattern,
            "should_match": should_match,
            "pass_message": self.pass_msg_var.get().strip() or "Rule passed",
            "fail_message": self.fail_msg_var.get().strip() or "Rule failed",
        }
        # Replace if key exists
        rules = self.compliance_dialog._custom_rules
        rules = [r for r in rules if r.get("key") != key]
        rules.append(rule)
        self.compliance_dialog._custom_rules = rules
        self.compliance_dialog._save_custom_rules()
        self._refresh_list()
        messagebox.showinfo("Saved", f"Custom rule '{label}' saved.", parent=self)

    def _delete(self):
        sel = self.tree.selection()
        if not sel:
            return
        key = sel[0]
        if messagebox.askyesno("Confirm", f"Delete rule '{key}'?", parent=self):
            self.compliance_dialog._custom_rules = [
                r for r in self.compliance_dialog._custom_rules if r.get("key") != key
            ]
            self.compliance_dialog._save_custom_rules()
            self._refresh_list()
            self._new()


# ════════════════════════════════════════════════════════════════
# COMPLIANCE CHECK DIALOG
# ════════════════════════════════════════════════════════════════

class ComplianceDialog(tk.Toplevel):
    """Run compliance checks against device configurations.

    Enhanced with:
      - Option to run on ALL devices or SELECTED devices only
      - Rule selector: choose which rules to run
      - Custom compliance rules: create/edit/delete regex-based rules
    """

    def __init__(self, parent, manager: DeviceManager, ops_window):
        super().__init__(parent)
        self.manager = manager
        self.ops_window = ops_window
        self.title("Compliance Check")
        self.configure(bg=COLORS["bg_white"])
        self.geometry("1050x700")
        self.transient(parent)

        x = parent.winfo_x() + (parent.winfo_width() - 1050) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 700) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        # Load custom rules from file
        self._custom_rules = self._load_custom_rules()

        self._build_ui()

    def _load_custom_rules(self):
        """Load custom compliance rules from compliance_rules.json."""
        import json, os
        path = os.path.join(self.ops_window.data_dir, "compliance_rules.json")
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    def _save_custom_rules(self):
        """Save custom rules to compliance_rules.json."""
        import json, os
        path = os.path.join(self.ops_window.data_dir, "compliance_rules.json")
        os.makedirs(self.ops_window.data_dir, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self._custom_rules, f, indent=2, ensure_ascii=False)

    def _build_ui(self):
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="  Compliance Check",
                 bg=COLORS["bg_dark"], fg=COLORS["text_light"],
                 font=("Segoe UI", 13, "bold")).pack(side="left", padx=10)
        add_maximize_button(header, self)

        intro = tk.Frame(self, bg=COLORS["bg_light"])
        intro.pack(fill="x")
        tk.Label(intro,
                 text="  Fetches running-config from devices and checks them against security best-practice rules.\n"
                      "  Choose 'All Devices' or 'Selected Devices Only', pick which rules to run, then click Start.",
                 bg=COLORS["bg_light"], fg=COLORS["text_dark"],
                 font=("Segoe UI", 9), justify="left",
                 ).pack(anchor="w", padx=10, pady=8)

        # ── Control panel ──────────────────────────────────────
        ctrl = tk.Frame(self, bg=COLORS["bg_white"])
        ctrl.pack(fill="x", padx=15, pady=(0, 8))

        # Device scope selector
        tk.Label(ctrl, text="Scope:", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 4))
        self.scope_var = tk.StringVar(value="all")
        tk.Radiobutton(ctrl, text="All Devices", variable=self.scope_var,
                       value="all", bg=COLORS["bg_white"],
                       font=("Segoe UI", 9)).pack(side="left", padx=(0, 8))
        selected_count = len(self.ops_window._checked) if hasattr(self.ops_window, "_checked") else 0
        tk.Radiobutton(ctrl, text=f"Selected Only ({selected_count})", variable=self.scope_var,
                       value="selected", bg=COLORS["bg_white"],
                       font=("Segoe UI", 9)).pack(side="left", padx=(0, 15))

        # Run button
        tk.Button(ctrl, text="Start Compliance Check",
                  command=self._run_check,
                  bg=COLORS["btn_primary"], fg="white",
                  font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=15, pady=4, cursor="hand2").pack(side="left")

        # Custom rule button
        tk.Button(ctrl, text="Manage Custom Rules",
                  command=self._manage_custom_rules,
                  bg=COLORS["btn_warning"], fg="white",
                  font=("Segoe UI", 9),
                  relief="flat", padx=12, pady=4, cursor="hand2").pack(side="left", padx=10)

        self.comp_status = tk.Label(ctrl, text="Ready",
                                    bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                                    font=("Segoe UI", 9))
        self.comp_status.pack(side="left", padx=15)

        # ── Rule selector (checkboxes for each rule) ───────────
        rules_frame = tk.LabelFrame(self, text="  Rules to Check  ",
                                    bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                                    font=("Segoe UI", 9, "bold"),
                                    padx=8, pady=8, bd=1, relief="solid")
        rules_frame.pack(fill="x", padx=15, pady=(0, 8))

        self._rule_vars = {}
        rules_row = tk.Frame(rules_frame, bg=COLORS["bg_white"])
        rules_row.pack(fill="x")
        col = 0
        for rule in ALL_RULES:
            var = tk.BooleanVar(value=True)
            self._rule_vars[rule.key] = var
            cb = tk.Checkbutton(rules_row, text=rule.label, variable=var,
                                bg=COLORS["bg_white"], font=("Segoe UI", 8),
                                activebackground=COLORS["bg_white"])
            cb.grid(row=0, column=col, sticky="w", padx=8, pady=2)
            col += 1
        # Add custom rules
        for cr in self._custom_rules:
            var = tk.BooleanVar(value=True)
            key = f"custom_{cr.get('key', '')}"
            self._rule_vars[key] = var
            cb = tk.Checkbutton(rules_row, text=f"[Custom] {cr.get('label', '?')}", variable=var,
                                bg=COLORS["bg_white"], font=("Segoe UI", 8),
                                activebackground=COLORS["bg_white"])
            cb.grid(row=1, column=col % 5, sticky="w", padx=8, pady=2)
            col += 1

        # Select/deselect all
        rules_btn_row = tk.Frame(rules_frame, bg=COLORS["bg_white"])
        rules_btn_row.pack(fill="x", pady=(4, 0))
        tk.Button(rules_btn_row, text="Select All Rules",
                  command=lambda: [v.set(True) for v in self._rule_vars.values()],
                  bg=COLORS["btn_primary"], fg="white", font=("Segoe UI", 8),
                  relief="flat", padx=8, pady=2, cursor="hand2").pack(side="left", padx=2)
        tk.Button(rules_btn_row, text="Deselect All",
                  command=lambda: [v.set(False) for v in self._rule_vars.values()],
                  bg=COLORS["text_gray"], fg="white", font=("Segoe UI", 8),
                  relief="flat", padx=8, pady=2, cursor="hand2").pack(side="left", padx=2)

        # ── Results table ──────────────────────────────────────
        cols = ("hostname", "ip", "rule", "category", "result", "details")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=12)
        self.tree.heading("hostname", text="Hostname")
        self.tree.heading("ip", text="IP Address")
        self.tree.heading("rule", text="Rule")
        self.tree.heading("category", text="Category")
        self.tree.heading("result", text="Result")
        self.tree.heading("details", text="Details")

        self.tree.column("hostname", width=120, minwidth=80)
        self.tree.column("ip", width=100, minwidth=70)
        self.tree.column("rule", width=140, minwidth=80)
        self.tree.column("category", width=80, minwidth=60)
        self.tree.column("result", width=60, minwidth=50, anchor="center")
        self.tree.column("details", width=380, minwidth=200)

        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True, padx=(15, 0), pady=(0, 15))
        vsb.pack(side="right", fill="y")

        self.tree.tag_configure("pass", foreground=COLORS["success"])
        self.tree.tag_configure("fail", foreground=COLORS["fail"])

    def _run_check(self):
        """Run compliance check on all or selected devices."""
        # Determine which devices to check
        if self.scope_var.get() == "selected":
            devices = self.ops_window._get_selected_devices()
            if not devices:
                messagebox.showinfo("Info", "No devices selected. Select devices in the main window first.", parent=self)
                return
        else:
            devices = self.manager.get_all_devices()

        if not devices:
            messagebox.showinfo("Info", "No devices to check.", parent=self)
            return

        # Determine which rules to run
        selected_rule_keys = [k for k, v in self._rule_vars.items() if v.get()]
        if not selected_rule_keys:
            messagebox.showwarning("No Rules", "Please select at least one rule to check.", parent=self)
            return

        # Build the list of rules to run
        from compliance import ALL_RULES, ComplianceRule
        rules_to_run = []
        for rule in ALL_RULES:
            if rule.key in selected_rule_keys:
                rules_to_run.append(rule)
        # Add custom rules
        for cr in self._custom_rules:
            key = f"custom_{cr.get('key', '')}"
            if key in selected_rule_keys:
                rules_to_run.append(ComplianceRule(
                    key=cr["key"],
                    label=cr["label"],
                    description=cr.get("description", ""),
                    category="Custom",
                    check_fn=self._make_custom_check(cr),
                ))

        # Clear existing
        for item in self.tree.get_children():
            self.tree.delete(item)

        self.comp_status.configure(text=f"Checking {len(devices)} device(s) with {len(rules_to_run)} rule(s)...")

        def _run():
            pusher = ConfigPusher()
            for i, device in enumerate(devices):
                self.after(0, lambda d=device, n=i, r=rules_to_run: self._check_device(d, n, len(devices), pusher, r))

        threading.Thread(target=_run, daemon=True).start()

    def _make_custom_check(self, rule_def):
        """Create a check function for a custom regex-based rule."""
        import re
        pattern = rule_def.get("pattern", "")
        should_match = rule_def.get("should_match", True)  # True = pass if found, False = pass if NOT found
        pass_msg = rule_def.get("pass_message", "Rule passed")
        fail_msg = rule_def.get("fail_message", "Rule failed")
        def check(config):
            try:
                found = bool(re.search(pattern, config, re.IGNORECASE | re.MULTILINE))
                if should_match:
                    return (found, pass_msg if found else fail_msg)
                else:
                    return (not found, pass_msg if not found else fail_msg)
            except Exception as e:
                return (False, f"Error in custom rule: {e}")
        return check

    def _check_device(self, device, index, total, pusher, rules_to_run):
        self.comp_status.configure(
            text=f"[{index+1}/{total}] Fetching config from {device['hostname']}...")

        try:
            creds = self.ops_window._get_credentials_for(device)
            if not creds or not creds.get("username"):
                self.tree.insert("", "end", values=(
                    device["hostname"], device["ip_address"],
                    "—", "—", "SKIP", "No credentials for this device"
                ), tags=("fail",))
                return

            config = pusher.fetch_running_config(device, creds)
            # Run only the selected rules
            from compliance import run_compliance_check
            results = run_compliance_check(config, rules=rules_to_run)

            for r in results:
                tag = "pass" if r.passed else "fail"
                result_text = "PASS" if r.passed else "FAIL"
                self.tree.insert("", "end", values=(
                    device["hostname"], device["ip_address"],
                    r.rule_label, r.category, result_text, r.details
                ), tags=(tag,))

        except Exception as e:
            self.tree.insert("", "end", values=(
                device["hostname"], device["ip_address"],
                "—", "—", "ERROR", str(e)[:80]
            ), tags=("fail",))

        self.comp_status.configure(
            text=f"[{index+1}/{total}] Done — {device['hostname']}")

    def _manage_custom_rules(self):
        """Open a dialog to create/edit/delete custom compliance rules."""
        CustomRulesDialog(self, self)


# ════════════════════════════════════════════════════════════════
# QUICK DIAGNOSTICS DIALOG
# ════════════════════════════════════════════════════════════════

class DiagnosticsDialog(tk.Toplevel):
    """Quick diagnostics: show version, show interface, ping.

    Devices to run against are chosen with the same checkbox-tree
    pattern as the main device list — supports both picking specific
    device(s) and running against everything at once.
    """

    def __init__(self, parent, manager: DeviceManager, ops_window):
        super().__init__(parent)
        self.manager = manager
        self.ops_window = ops_window
        self.title("Quick Diagnostics")
        self.configure(bg=COLORS["bg_white"])
        self.geometry("1050x650")
        self.transient(parent)

        x = parent.winfo_x() + (parent.winfo_width() - 1050) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 650) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        self._item_to_device = {}
        self._checked = set()

        self._build_ui()

    def _build_ui(self):
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="  Quick Diagnostics",
                 bg=COLORS["bg_dark"], fg=COLORS["text_light"],
                 font=("Segoe UI", 13, "bold")).pack(side="left", padx=10)
        add_maximize_button(header, self)

        body = tk.Frame(self, bg=COLORS["bg_light"])
        body.pack(fill="both", expand=True)

        # ── Left: device picker (checkbox tree, same pattern as the
        # main device list — supports single or multiple selection) ──
        left = tk.Frame(body, bg=COLORS["bg_white"])
        left.configure(width=280)
        left.pack(side="left", fill="y", padx=(10, 5), pady=10)
        left.pack_propagate(False)

        chk = tk.Frame(left, bg=COLORS["bg_white"])
        chk.pack(fill="x", padx=8, pady=(8, 4))
        tk.Button(chk, text="Select All", command=lambda: self._select_all(True),
                  bg=COLORS["btn_primary"], fg="white", font=("Segoe UI", 8, "bold"),
                  relief="flat", padx=8, pady=2, cursor="hand2").pack(side="left", padx=2)
        tk.Button(chk, text="Clear", command=lambda: self._select_all(False),
                  bg=COLORS["text_gray"], fg="white", font=("Segoe UI", 8),
                  relief="flat", padx=8, pady=2, cursor="hand2").pack(side="left", padx=2)
        self.sel_count = tk.Label(chk, text="0 selected", bg=COLORS["bg_white"],
                                  fg=COLORS["text_dark"], font=("Segoe UI", 8, "bold"))
        self.sel_count.pack(side="left", padx=8)

        tree_frame = tk.Frame(left)
        tree_frame.pack(fill="both", expand=True, padx=8, pady=4)

        cols = ("select", "hostname", "ip")
        self.tree = ttk.Treeview(tree_frame, columns=cols, show="headings", selectmode="none")
        self.tree.heading("select", text="Select")
        self.tree.heading("hostname", text="Hostname")
        self.tree.heading("ip", text="IP Address")
        self.tree.column("select", width=50, minwidth=40, anchor="center", stretch=False)
        self.tree.column("hostname", width=110, minwidth=70)
        self.tree.column("ip", width=100, minwidth=70)

        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.tree.bind("<Button-1>", self._on_tree_click)
        self._refresh_device_tree()

        # ── Right: command controls + results ───────────────────
        right = tk.Frame(body, bg=COLORS["bg_light"])
        right.pack(side="right", fill="both", expand=True, padx=(5, 10), pady=10)

        ctrl = tk.Frame(right, bg=COLORS["bg_light"])
        ctrl.pack(fill="x", pady=(0, 8))

        tk.Label(ctrl, text="Command:", bg=COLORS["bg_light"],
                 font=("Segoe UI", 9, "bold")).grid(row=0, column=0, padx=5)
        self.cmd_var = tk.StringVar(value="show version")
        ttk.Combobox(ctrl, textvariable=self.cmd_var, width=26,
                     values=["show version", "show ip interface brief",
                             "show inventory", "show clock",
                             "show running-config", "show vlan brief",
                             "show ip route", "show access-lists"],
                     ).grid(row=0, column=1, padx=5)

        tk.Button(ctrl, text="Run on Selected", command=self._run_selected,
                  bg=COLORS["btn_success"], fg="white",
                  font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=12, pady=3, cursor="hand2").grid(
            row=0, column=2, padx=(10, 4))

        tk.Button(ctrl, text="Run on All Devices", command=self._run_all,
                  bg=COLORS["btn_primary"], fg="white",
                  font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=12, pady=3, cursor="hand2").grid(
            row=0, column=3, padx=4)

        self.diag_status = tk.Label(ctrl, text="Ready",
                                    bg=COLORS["bg_light"], fg=COLORS["text_gray"],
                                    font=("Segoe UI", 9))
        self.diag_status.grid(row=1, column=0, columnspan=4, sticky="w", padx=5, pady=(4, 0))

        # Results: notebook with one tab per device
        self.notebook = ttk.Notebook(right)
        self.notebook.pack(fill="both", expand=True)

    # ── device picker ────────────────────────────────────────────
    def _refresh_device_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self._item_to_device.clear()
        for d in self.manager.get_all_devices():
            check = CHECK_ON if d["id"] in self._checked else CHECK_OFF
            item_id = self.tree.insert("", "end", values=(check, d["hostname"], d["ip_address"]))
            self._item_to_device[item_id] = d
        self._update_sel_count()

    def _on_tree_click(self, event):
        if self.tree.identify("region", event.x, event.y) != "cell":
            return
        if self.tree.identify_column(event.x) != "#1":
            return
        item_id = self.tree.identify_row(event.y)
        if not item_id:
            return
        d = self._item_to_device.get(item_id)
        if not d:
            return
        if d["id"] in self._checked:
            self._checked.discard(d["id"])
            symbol = CHECK_OFF
        else:
            self._checked.add(d["id"])
            symbol = CHECK_ON
        values = list(self.tree.item(item_id, "values"))
        values[0] = symbol
        self.tree.item(item_id, values=values)
        self._update_sel_count()

    def _select_all(self, select: bool):
        if select:
            for d in self.manager.get_all_devices():
                self._checked.add(d["id"])
        else:
            self._checked.clear()
        self._refresh_device_tree()

    def _update_sel_count(self):
        self.sel_count.configure(text=f"{len(self._checked)} selected")

    def _get_selected_devices(self) -> List[dict]:
        return [d for d in self.manager.get_all_devices() if d["id"] in self._checked]

    # ── run diagnostics ─────────────────────────────────────────
    def _run_selected(self):
        devices = self._get_selected_devices()
        if not devices:
            messagebox.showinfo("Info", "Select one or more devices on the left first.", parent=self)
            return
        self._run_on(devices)

    def _run_all(self):
        devices = self.manager.get_all_devices()
        if not devices:
            return
        self._run_on(devices)

    def _run_on(self, devices: List[dict]):
        command = self.cmd_var.get().strip()
        if not command:
            return

        # Clear existing tabs
        for tab in self.notebook.tabs():
            self.notebook.forget(tab)

        self.diag_status.configure(text=f"Running '{command}' on {len(devices)} device(s)...")

        def _run():
            pusher = ConfigPusher()
            for i, device in enumerate(devices):
                self.after(0, lambda d=device, n=i: self._run_one(d, n, len(devices), command, pusher))

        threading.Thread(target=_run, daemon=True).start()

    def _run_one(self, device, index, total, command, pusher):
        # Create a tab for this device
        tab = tk.Frame(self.notebook, bg=COLORS["bg_white"])
        self.notebook.add(tab, text=f"{device['hostname']}")

        text = tk.Text(tab, wrap="word", font=("Consolas", 9),
                       bg="#1e1e1e", fg="#d4d4d4", relief="flat")
        scroll = ttk.Scrollbar(tab, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        text.insert("end", f"Running: {command}\n")
        text.insert("end", f"Device: {device['hostname']} ({device['ip_address']})\n")
        text.insert("end", "=" * 60 + "\n\n")

        try:
            creds = self.ops_window._get_credentials_for(device)
            if not creds or not creds.get("username"):
                text.insert("end", "*** No credentials for this device ***\n", "error")
                text.tag_configure("error", foreground=COLORS["fail"])
                return

            output = pusher.run_diagnostic(device, creds, command)
            text.insert("end", output)
        except Exception as e:
            text.insert("end", f"*** Error: {e} ***\n", "error")
            text.tag_configure("error", foreground=COLORS["fail"])

        self.diag_status.configure(
            text=f"[{index+1}/{total}] Done — {device['hostname']}")


# ════════════════════════════════════════════════════════════════
# TEMPLATE MANAGER DIALOG
# ════════════════════════════════════════════════════════════════

class TemplateManagerDialog(tk.Toplevel):
    """Manage config templates — create, edit, delete, deploy."""

    def __init__(self, parent, ops_window):
        super().__init__(parent)
        self.ops_window = ops_window
        self.tm = ops_window.template_manager
        self.title("Config Templates")
        self.configure(bg=COLORS["bg_white"])
        self.geometry("750x600")
        self.transient(parent)

        x = parent.winfo_x() + (parent.winfo_width() - 750) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 600) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        self._build_ui()
        self._refresh_list()

    def _build_ui(self):
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="  Config Templates",
                 bg=COLORS["bg_dark"], fg=COLORS["text_light"],
                 font=("Segoe UI", 13, "bold")).pack(side="left", padx=10)
        add_maximize_button(header, self)

        # Left: template list
        left = tk.LabelFrame(self, text="  Templates  ",
                             bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                             font=("Segoe UI", 10, "bold"),
                             padx=8, pady=8, bd=1, relief="solid")
        left.pack(side="left", fill="both", expand=True, padx=(10, 5), pady=10)
        left.configure(width=280)
        left.pack_propagate(False)

        cols = ("name", "category")
        self.tree = ttk.Treeview(left, columns=cols, show="headings",
                                 selectmode="browse", height=12)
        self.tree.heading("name", text="Template Name")
        self.tree.heading("category", text="Category")
        self.tree.column("name", width=180, minwidth=100)
        self.tree.column("category", width=80, minwidth=50)
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        btn_frame = tk.Frame(left, bg=COLORS["bg_white"])
        btn_frame.pack(fill="x", pady=(8, 0))
        tk.Button(btn_frame, text="New", command=self._new_template,
                  bg=COLORS["btn_success"], fg="white",
                  font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=10, pady=2, cursor="hand2").pack(side="left", padx=2)
        tk.Button(btn_frame, text="Delete", command=self._delete,
                  bg=COLORS["btn_danger"], fg="white",
                  font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=10, pady=2, cursor="hand2").pack(side="left", padx=2)

        # Right: edit form
        right = tk.LabelFrame(self, text="  Template Details  ",
                              bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                              font=("Segoe UI", 10, "bold"),
                              padx=10, pady=10, bd=1, relief="solid")
        right.pack(side="left", fill="both", expand=True, padx=(5, 10), pady=10)

        tk.Label(right, text="Name:", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.name_var = tk.StringVar()
        ttk.Entry(right, textvariable=self.name_var, width=35).pack(fill="x", pady=(0, 8))

        tk.Label(right, text="Category:", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.cat_var = tk.StringVar(value="General")
        ttk.Combobox(right, textvariable=self.cat_var, width=20,
                     values=["General", "Security", "SNMP", "Logging", "Network", "QoS"],
                     ).pack(fill="x", pady=(0, 8))

        tk.Label(right, text="Description:", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.desc_text = tk.Text(right, height=2, font=("Segoe UI", 9),
                                 bg="#fafafa", relief="solid", bd=1, wrap="word")
        self.desc_text.pack(fill="x", pady=(0, 8))

        tk.Label(right, text="Commands (one per line):", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).pack(anchor="w")
        self.cmd_text = tk.Text(right, height=10, font=("Consolas", 9),
                                bg="#fafafa", relief="solid", bd=1, wrap="none")
        self.cmd_text.pack(fill="both", expand=True, pady=(0, 8))

        tk.Button(right, text="Save Template", command=self._save,
                  bg=COLORS["btn_primary"], fg="white",
                  font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=15, pady=4, cursor="hand2").pack(side="right")

    def _refresh_list(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for t in self.tm.get_all():
            self.tree.insert("", "end", values=(t.name, t.category), iid=t.name)

    def _on_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        name = sel[0]
        tpl = self.tm.get_by_name(name)
        if tpl:
            self.name_var.set(tpl.name)
            self.cat_var.set(tpl.category)
            self.desc_text.delete("1.0", "end")
            self.desc_text.insert("1.0", tpl.description)
            self.cmd_text.delete("1.0", "end")
            self.cmd_text.insert("1.0", "\n".join(tpl.commands))

    def _new_template(self):
        self.name_var.set("")
        self.cat_var.set("General")
        self.desc_text.delete("1.0", "end")
        self.cmd_text.delete("1.0", "end")
        self.tree.selection_remove(self.tree.selection())

    def _save(self):
        name = self.name_var.get().strip()
        if not name:
            messagebox.showwarning("Validation", "Template name is required.", parent=self)
            return
        commands_text = self.cmd_text.get("1.0", "end").strip()
        commands = [c.strip() for c in commands_text.splitlines() if c.strip()]
        if not commands:
            messagebox.showwarning("Validation", "At least one command is required.", parent=self)
            return
        desc = self.desc_text.get("1.0", "end").strip()
        tpl = ConfigTemplate(
            name=name, commands=commands,
            description=desc, category=self.cat_var.get(),
        )
        self.tm.add(tpl)
        self._refresh_list()
        messagebox.showinfo("Saved", f"Template '{name}' saved.", parent=self)

    def _delete(self):
        sel = self.tree.selection()
        if not sel:
            return
        name = sel[0]
        if messagebox.askyesno("Confirm", f"Delete template '{name}'?", parent=self):
            self.tm.delete(name)
            self._refresh_list()
            self._new_template()


# ════════════════════════════════════════════════════════════════
# CHANGE HISTORY DIALOG
# ════════════════════════════════════════════════════════════════

class ChangeHistoryDialog(tk.Toplevel):
    """View the change history / audit trail.

    Enhanced with:
      - Search/filter by hostname/IP
      - Filter by result (All / Pass / Fail)
      - Export to CSV
      - Double-click a record to see full details (all commands + full output)
    """

    def __init__(self, parent, ops_window):
        super().__init__(parent)
        self.ops_window = ops_window
        self.history = ops_window.change_history
        self.title("Change History / Audit Trail")
        self.configure(bg=COLORS["bg_white"])
        self.geometry("1000x650")
        self.transient(parent)

        x = parent.winfo_x() + (parent.winfo_width() - 1000) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 650) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        self._build_ui()
        self._refresh()

    def _build_ui(self):
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="  Change History / Audit Trail",
                 bg=COLORS["bg_dark"], fg=COLORS["text_light"],
                 font=("Segoe UI", 13, "bold")).pack(side="left", padx=10)
        add_maximize_button(header, self)

        # ── Filter / search bar ────────────────────────────────
        filter_frame = tk.Frame(self, bg=COLORS["bg_light"])
        filter_frame.pack(fill="x", padx=15, pady=(8, 4))

        self.count_label = tk.Label(filter_frame, text=f"Total records: {self.history.count()}",
                                    bg=COLORS["bg_light"], fg=COLORS["text_dark"],
                                    font=("Segoe UI", 9, "bold"))
        self.count_label.pack(side="left", padx=10)

        tk.Label(filter_frame, text="Search:", bg=COLORS["bg_light"],
                 font=("Segoe UI", 9)).pack(side="left", padx=(15, 4))
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *a: self._refresh())
        ttk.Entry(filter_frame, textvariable=self.search_var, width=18).pack(side="left", padx=(0, 8))

        tk.Label(filter_frame, text="Result:", bg=COLORS["bg_light"],
                 font=("Segoe UI", 9)).pack(side="left", padx=(0, 2))
        self.result_filter_var = tk.StringVar(value="All")
        ttk.Combobox(filter_frame, textvariable=self.result_filter_var,
                     values=["All", "Pass", "Fail"], state="readonly", width=6).pack(side="left", padx=(0, 8))
        self.result_filter_var.trace_add("write", lambda *a: self._refresh())

        tk.Label(filter_frame, text="Source:", bg=COLORS["bg_light"],
                 font=("Segoe UI", 9)).pack(side="left", padx=(0, 2))
        self.source_filter_var = tk.StringVar(value="All")
        ttk.Combobox(filter_frame, textvariable=self.source_filter_var,
                     values=["All", "Config Push", "Interactive"], state="readonly", width=12).pack(side="left", padx=(0, 8))
        self.source_filter_var.trace_add("write", lambda *a: self._refresh())

        # Action buttons
        tk.Button(filter_frame, text="Export CSV", command=self._export_csv,
                  bg=COLORS["btn_primary"], fg="white", font=("Segoe UI", 9),
                  relief="flat", padx=10, pady=2, cursor="hand2").pack(side="left", padx=5)
        tk.Button(filter_frame, text="Clear History", command=self._clear,
                  bg=COLORS["btn_danger"], fg="white", font=("Segoe UI", 9),
                  relief="flat", padx=10, pady=2, cursor="hand2").pack(side="left", padx=5)

        self.result_count_label = tk.Label(filter_frame, text="", bg=COLORS["bg_light"],
                                           fg=COLORS["text_gray"], font=("Segoe UI", 8, "italic"))
        self.result_count_label.pack(side="right", padx=10)

        # ── Tree ────────────────────────────────────────────────
        cols = ("timestamp", "hostname", "ip", "source", "commands", "result", "error")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=15)
        self.tree.heading("timestamp", text="Timestamp")
        self.tree.heading("hostname", text="Hostname")
        self.tree.heading("ip", text="IP")
        self.tree.heading("source", text="Source")
        self.tree.heading("commands", text="Commands")
        self.tree.heading("result", text="Result")
        self.tree.heading("error", text="Error")

        self.tree.column("timestamp", width=140, minwidth=100)
        self.tree.column("hostname", width=110, minwidth=80)
        self.tree.column("ip", width=90, minwidth=70)
        self.tree.column("source", width=90, minwidth=70, anchor="center")
        self.tree.column("commands", width=220, minwidth=150)
        self.tree.column("result", width=50, minwidth=40, anchor="center")
        self.tree.column("error", width=200, minwidth=100)

        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True, padx=(15, 0), pady=(0, 15))
        vsb.pack(side="right", fill="y")

        self.tree.tag_configure("success", foreground=COLORS["success"])
        self.tree.tag_configure("fail", foreground=COLORS["fail"])
        # Double-click to view full details
        self.tree.bind("<Double-1>", self._show_detail)

    def _refresh(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        query = self.search_var.get().strip().lower() if hasattr(self, "search_var") else ""
        result_filter = self.result_filter_var.get() if hasattr(self, "result_filter_var") else "All"
        source_filter = self.source_filter_var.get() if hasattr(self, "source_filter_var") else "All"

        records = self.history.get_recent(200)
        shown = 0
        for r in records:
            # Apply search filter
            if query:
                # Also search in commands, not just hostname/IP
                cmds_str = " ".join(r.commands).lower()
                if (query not in r.hostname.lower()
                        and query not in r.ip_address.lower()
                        and query not in cmds_str):
                    continue
            # Apply result filter
            if result_filter == "Pass" and not r.success:
                continue
            if result_filter == "Fail" and r.success:
                continue
            # Apply source filter
            if source_filter == "Config Push" and r.source != "config_push":
                continue
            if source_filter == "Interactive" and r.source != "interactive":
                continue

            ts = r.timestamp.replace("T", " ").split(".")[0] if "T" in r.timestamp else r.timestamp
            cmds = " | ".join(r.commands[:3])
            if len(r.commands) > 3:
                cmds += f" ... (+{len(r.commands)-3} more)"
            result = "PASS" if r.success else "FAIL"
            tag = "success" if r.success else "fail"
            source_display = "Interactive" if r.source == "interactive" else "Config Push"
            self.tree.insert("", "end", values=(
                ts, r.hostname, r.ip_address, source_display, cmds, result, r.error[:80]
            ), tags=(tag,))
            shown += 1

        self.count_label.configure(text=f"Total records: {self.history.count()}")
        if shown == len(records):
            self.result_count_label.configure(text=f"showing {shown}")
        else:
            self.result_count_label.configure(text=f"showing {shown} of {len(records)}")

    def _show_detail(self, event):
        """Show full details of a change record in a popup."""
        sel = self.tree.selection()
        if not sel:
            return
        item = sel[0]
        values = self.tree.item(item, "values")
        if not values:
            return

        # Find the matching record
        ts_raw = values[0]
        hostname = values[1]
        records = self.history.get_recent(200)
        record = None
        for r in records:
            r_ts = r.timestamp.replace("T", " ").split(".")[0] if "T" in r.timestamp else r.timestamp
            if r_ts == ts_raw and r.hostname == hostname:
                record = r
                break
        if not record:
            return

        # Show detail dialog
        detail = tk.Toplevel(self)
        detail.title(f"Change Detail — {record.hostname}")
        detail.configure(bg=COLORS["bg_white"])
        detail.geometry("700x550")
        detail.transient(self)
        detail.grab_set()

        x = self.winfo_x() + (self.winfo_width() - 700) // 2
        y = self.winfo_y() + (self.winfo_height() - 550) // 2
        detail.geometry(f"+{x}+{y}")

        # Info
        info = tk.Frame(detail, bg=COLORS["bg_light"])
        info.pack(fill="x", padx=10, pady=10)
        tk.Label(info, text=f"  Timestamp: {ts_raw}\n  Device: {record.hostname} ({record.ip_address})\n  Result: {'PASS' if record.success else 'FAIL'}",
                 bg=COLORS["bg_light"], fg=COLORS["text_dark"],
                 font=("Segoe UI", 9, "bold"), justify="left").pack(anchor="w", padx=5, pady=5)

        if record.error:
            tk.Label(detail, text="Error:", bg=COLORS["bg_white"],
                     font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=10)
            err_text = tk.Text(detail, height=3, font=("Consolas", 9),
                               bg="#fde8e8", relief="solid", bd=1, wrap="word")
            err_text.pack(fill="x", padx=10, pady=(0, 5))
            err_text.insert("1.0", record.error)
            err_text.configure(state="disabled")

        # Commands
        tk.Label(detail, text="Commands Pushed:", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=10, pady=(5, 2))
        cmd_text = tk.Text(detail, height=6, font=("Consolas", 9),
                           bg="#fafafa", relief="solid", bd=1, wrap="none")
        cmd_text.pack(fill="x", padx=10, pady=(0, 5))
        cmd_text.insert("1.0", "\n".join(record.commands))
        cmd_text.configure(state="disabled")

        # Full output
        tk.Label(detail, text="Full Output:", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=10, pady=(5, 2))
        out_text = tk.Text(detail, height=12, font=("Consolas", 9),
                           bg="#1e1e1e", fg="#d4d4d4", relief="flat", wrap="word")
        out_scroll = ttk.Scrollbar(detail, orient="vertical", command=out_text.yview)
        out_text.configure(yscrollcommand=out_scroll.set)
        out_text.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=(0, 10))
        out_scroll.pack(side="right", fill="y", padx=(0, 10), pady=(0, 10))
        out_text.insert("1.0", record.output or "(no output)")
        out_text.configure(state="disabled")

    def _export_csv(self):
        """Export the change history to a CSV file."""
        filepath = filedialog.asksaveasfilename(
            title="Export Change History",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
            parent=self,
        )
        if not filepath:
            return
        import csv
        records = self.history.get_recent(1000)
        with open(filepath, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Timestamp", "Hostname", "IP", "Device Type",
                             "Source", "Commands", "Result", "Error", "Pushed By"])
            for r in records:
                writer.writerow([
                    r.timestamp, r.hostname, r.ip_address, r.device_type,
                    "Interactive" if r.source == "interactive" else "Config Push",
                    " | ".join(r.commands),
                    "PASS" if r.success else "FAIL",
                    r.error, r.pushed_by,
                ])
        messagebox.showinfo("Export Complete", f"Exported {len(records)} records to:\n{filepath}", parent=self)

    def _clear(self):
        if messagebox.askyesno("Confirm", "Clear ALL change history? This cannot be undone.", parent=self):
            self.history.clear()
            self._refresh()


# ════════════════════════════════════════════════════════════════
# BULK CONFIG PUSH DIALOG
# ════════════════════════════════════════════════════════════════

class BulkConfigPushDialog(tk.Toplevel):
    """Push config commands to multiple selected devices at once."""

    def __init__(self, parent, devices: List[dict], ops_window):
        super().__init__(parent)
        self.devices = devices
        self.ops_window = ops_window
        self.title("Bulk Config Push")
        self.configure(bg=COLORS["bg_white"])
        self.geometry("700x650")
        self.transient(parent)

        x = parent.winfo_x() + (parent.winfo_width() - 700) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 650) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        self._build_ui()

    def _build_ui(self):
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="  Bulk Config Push",
                 bg=COLORS["bg_dark"], fg=COLORS["text_light"],
                 font=("Segoe UI", 13, "bold")).pack(side="left", padx=10)
        add_maximize_button(header, self)

        intro = tk.Frame(self, bg=COLORS["bg_light"])
        intro.pack(fill="x")
        tk.Label(intro,
                 text=f"  Push config commands to {len(self.devices)} selected device(s). "
                      "Each device gets the same commands.",
                 bg=COLORS["bg_light"], fg=COLORS["text_dark"],
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=10, pady=8)

        # Template loader
        tpl_frame = tk.Frame(self, bg=COLORS["bg_white"])
        tpl_frame.pack(fill="x", padx=15, pady=(0, 4))
        tk.Label(tpl_frame, text="Load Template:", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9)).pack(side="left", padx=(0, 5))
        self.tpl_var = tk.StringVar(value="(none)")
        tpl_combo = ttk.Combobox(tpl_frame, textvariable=self.tpl_var,
                                 values=["(none)"] + [t.name for t in self.ops_window.template_manager.get_all()],
                                 state="readonly", width=25)
        tpl_combo.pack(side="left")
        tpl_combo.bind("<<ComboboxSelected>>", self._on_template)

        # Commands
        tk.Label(self, text="Config Commands (one per line):",
                 bg=COLORS["bg_white"], font=("Segoe UI", 9, "bold"),
                 ).pack(anchor="w", padx=15, pady=(4, 2))
        self.cmd_text = tk.Text(self, height=8, font=("Consolas", 9),
                                bg="#fafafa", relief="solid", bd=1, wrap="none")
        self.cmd_text.pack(fill="x", padx=15, pady=(0, 8))

        # Push button
        tk.Button(self, text=f"Push to {len(self.devices)} Device(s)",
                  command=self._push,
                  bg=COLORS["btn_success"], fg="white",
                  font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=20, pady=6, cursor="hand2").pack(pady=4)

        # Results
        tk.Label(self, text="Results:",
                 bg=COLORS["bg_white"], font=("Segoe UI", 9, "bold"),
                 ).pack(anchor="w", padx=15, pady=(8, 2))

        cols = ("hostname", "ip", "result", "error")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=8)
        self.tree.heading("hostname", text="Hostname")
        self.tree.heading("ip", text="IP")
        self.tree.heading("result", text="Result")
        self.tree.heading("error", text="Error")
        self.tree.column("hostname", width=150, minwidth=80)
        self.tree.column("ip", width=120, minwidth=70)
        self.tree.column("result", width=70, minwidth=50, anchor="center")
        self.tree.column("error", width=300, minwidth=150)
        self.tree.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        self.tree.tag_configure("success", foreground=COLORS["success"])
        self.tree.tag_configure("fail", foreground=COLORS["fail"])

    def _on_template(self, event):
        name = self.tpl_var.get()
        if name == "(none)":
            return
        tpl = self.ops_window.template_manager.get_by_name(name)
        if tpl:
            self.cmd_text.delete("1.0", "end")
            self.cmd_text.insert("1.0", "\n".join(tpl.commands))

    def _push(self):
        commands_text = self.cmd_text.get("1.0", "end").strip()
        if not commands_text:
            messagebox.showwarning("Validation", "No commands to push.", parent=self)
            return
        commands = [c.strip() for c in commands_text.splitlines() if c.strip()]
        if not commands:
            return

        if not messagebox.askyesno(
            "Confirm Bulk Push",
            f"Push {len(commands)} command(s) to {len(self.devices)} device(s)?\n\n"
            "This will modify the configuration on ALL selected devices.",
            parent=self,
        ):
            return

        # Clear results
        for item in self.tree.get_children():
            self.tree.delete(item)

        def _run():
            pusher = ConfigPusher()
            for i, device in enumerate(self.devices):
                self.after(0, lambda d=device, n=i: self._push_one(d, n, len(self.devices), commands, pusher))

        threading.Thread(target=_run, daemon=True).start()

    def _push_one(self, device, index, total, commands, pusher):
        creds = self.ops_window._get_credentials_for(device)
        if not creds or not creds.get("username"):
            self.tree.insert("", "end", values=(
                device["hostname"], device["ip_address"], "SKIP", "No credentials"
            ), tags=("fail",))
            return

        result = pusher.push_config(device, commands, creds)
        tag = "success" if result.success else "fail"
        result_text = "PASS" if result.success else "FAIL"
        self.tree.insert("", "end", values=(
            device["hostname"], device["ip_address"], result_text, result.error[:80]
        ), tags=(tag,))

        # Log to change history
        self.ops_window.change_history.add(ChangeRecord(
            device_id=device.get("id", ""),
            hostname=device.get("hostname", ""),
            ip_address=device.get("ip_address", ""),
            device_type=device.get("device_type", ""),
            commands=commands,
            success=result.success,
            error=result.error,
            output=result.output,
        ))


# ════════════════════════════════════════════════════════════════
# MAIN NETWORK OPERATIONS WINDOW
# ════════════════════════════════════════════════════════════════

class NetworkOperationsWindow(tk.Toplevel):
    """Main Network Operations window — launched from the backup tool."""

    def __init__(self, parent, manager: DeviceManager, data_dir: str):
        super().__init__(parent)
        self.manager = manager
        self.data_dir = data_dir
        self.template_manager = TemplateManager(data_dir)
        self.change_history = ChangeHistory(data_dir)

        self.title("Network Operations — SSH Terminal, Config Push, Compliance")
        self.geometry("1300x800")
        self.minsize(1100, 650)
        self.configure(bg=COLORS["bg_light"])

        self._terminal_tabs = []  # track open PuttyEmbeddedTab instances

        self._build_ui()
        # Fix C3: Clean up all SSH sessions when the window is closed
        self.protocol("WM_DELETE_WINDOW", self._on_ops_close)

    def _build_ui(self):
        # ── Header ─────────────────────────────────────────────
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=55)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header, text="  Network Operations Center",
            bg=COLORS["bg_dark"], fg=COLORS["text_light"],
            font=("Segoe UI", 16, "bold"), anchor="w",
        ).pack(side="left", padx=10)

        # ── Toolbar ────────────────────────────────────────────
        toolbar = tk.Frame(self, bg=COLORS["bg_white"], height=45)
        toolbar.pack(fill="x")
        toolbar.pack_propagate(False)

        tk.Button(toolbar, text="Login to Selected (SSH Terminal)",
                  command=self._login_selected,
                  bg=COLORS["btn_success"], fg="white",
                  font=("Segoe UI", 9, "bold"),
                  relief="flat", padx=14, pady=3, cursor="hand2").pack(side="left", padx=(10, 5), pady=6)

        # ── Open-in mode: embedded real PuTTY tab vs. separate PuTTY window ──
        # Both modes launch the REAL putty.exe — the only difference is
        # whether its window gets reparented into this app's tab strip
        # (Windows only; see putty_embed.py) or left as its own normal
        # window (works on every platform putty.exe runs on).
        tk.Label(toolbar, text="Open in:", bg=COLORS["bg_white"],
                  fg=COLORS["text_dark"], font=("Segoe UI", 9)
                  ).pack(side="left", padx=(12, 4))
        default_mode = "Embedded PuTTY Tab" if putty_embed.is_supported() else "External PuTTY (separate window)"
        self.launch_mode_var = tk.StringVar(value=default_mode)
        launch_mode_combo = ttk.Combobox(
            toolbar, textvariable=self.launch_mode_var,
            values=["Embedded PuTTY Tab", "External PuTTY (separate window)"],
            state="readonly", width=26, font=("Segoe UI", 9),
        )
        launch_mode_combo.pack(side="left", pady=6)

        tk.Button(toolbar, text="Bulk Config Push",
                  command=self._bulk_push,
                  bg=COLORS["btn_primary"], fg="white",
                  font=("Segoe UI", 9),
                  relief="flat", padx=14, pady=3, cursor="hand2").pack(side="left", padx=3, pady=6)

        tk.Button(toolbar, text="Compare Configs",
                  command=self._compare_configs,
                  bg=COLORS["bg_medium"], fg="white",
                  font=("Segoe UI", 9),
                  relief="flat", padx=14, pady=3, cursor="hand2").pack(side="left", padx=3, pady=6)

        tk.Button(toolbar, text="Compliance Check",
                  command=self._compliance_check,
                  bg=COLORS["bg_medium"], fg="white",
                  font=("Segoe UI", 9),
                  relief="flat", padx=14, pady=3, cursor="hand2").pack(side="left", padx=3, pady=6)

        tk.Button(toolbar, text="Quick Diagnostics",
                  command=self._diagnostics,
                  bg=COLORS["bg_medium"], fg="white",
                  font=("Segoe UI", 9),
                  relief="flat", padx=14, pady=3, cursor="hand2").pack(side="left", padx=3, pady=6)

        tk.Button(toolbar, text="Templates",
                  command=self._templates,
                  bg=COLORS["btn_warning"], fg="white",
                  font=("Segoe UI", 9),
                  relief="flat", padx=14, pady=3, cursor="hand2").pack(side="left", padx=3, pady=6)

        tk.Button(toolbar, text="Change History",
                  command=self._change_history,
                  bg=COLORS["text_gray"], fg="white",
                  font=("Segoe UI", 9),
                  relief="flat", padx=14, pady=3, cursor="hand2").pack(side="left", padx=3, pady=6)

        self.count_label = tk.Label(
            toolbar, text="0 devices", bg=COLORS["bg_white"],
            fg=COLORS["text_gray"], font=("Segoe UI", 9),
        )
        self.count_label.pack(side="right", padx=15)

        # ── Main content ───────────────────────────────────────
        content = tk.Frame(self, bg=COLORS["bg_light"])
        content.pack(fill="both", expand=True, padx=10, pady=5)

        # Left: device list
        left = tk.Frame(content, bg=COLORS["bg_white"])
        self.left_panel = left
        left.pack(side="left", fill="both", expand=True, padx=(0, 5))

        # Checkbox controls
        chk = tk.Frame(left, bg=COLORS["bg_white"])
        chk.pack(fill="x", padx=8, pady=(8, 4))
        tk.Button(chk, text="Select All", command=lambda: self._select_all(True),
                  bg=COLORS["btn_primary"], fg="white", font=("Segoe UI", 8, "bold"),
                  relief="flat", padx=8, pady=2, cursor="hand2").pack(side="left", padx=2)
        tk.Button(chk, text="Clear", command=lambda: self._select_all(False),
                  bg=COLORS["text_gray"], fg="white", font=("Segoe UI", 8),
                  relief="flat", padx=8, pady=2, cursor="hand2").pack(side="left", padx=2)
        self.sel_count = tk.Label(chk, text="0 selected", bg=COLORS["bg_white"],
                                  fg=COLORS["text_dark"], font=("Segoe UI", 8, "bold"))
        self.sel_count.pack(side="left", padx=8)

        # ── Search & filter bar ─────────────────────────────────
        # Same pattern as the backup tool: live search by hostname/IP
        # + dropdown filters for Type, Vendor, Location.
        search_frame = tk.Frame(left, bg=COLORS["bg_white"])
        search_frame.pack(fill="x", padx=8, pady=(2, 4))

        tk.Label(search_frame, text="Search:",
                 bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                 font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 4))
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *a: self._refresh_device_tree())
        ttk.Entry(search_frame, textvariable=self.search_var, width=14).pack(side="left", padx=(0, 6))

        tk.Label(search_frame, text="Type:",
                 bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                 font=("Segoe UI", 8)).pack(side="left", padx=(0, 2))
        self.search_type_var = tk.StringVar(value="Any")
        ttk.Combobox(search_frame, textvariable=self.search_type_var,
                     values=["Any", "Router", "Switch", "Firewall"],
                     state="readonly", width=7).pack(side="left", padx=(0, 4))
        self.search_type_var.trace_add("write", lambda *a: self._refresh_device_tree())

        tk.Label(search_frame, text="Vendor:",
                 bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                 font=("Segoe UI", 8)).pack(side="left", padx=(0, 2))
        self.search_vendor_var = tk.StringVar(value="Any")
        self.search_vendor_combo = ttk.Combobox(search_frame, textvariable=self.search_vendor_var,
                                                values=["Any"], state="readonly", width=12)
        self.search_vendor_combo.pack(side="left", padx=(0, 4))
        self.search_vendor_var.trace_add("write", lambda *a: self._refresh_device_tree())

        tk.Label(search_frame, text="Location:",
                 bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                 font=("Segoe UI", 8)).pack(side="left", padx=(0, 2))
        self.search_location_var = tk.StringVar(value="Any")
        self.search_location_combo = ttk.Combobox(search_frame, textvariable=self.search_location_var,
                                                  values=["Any"], state="readonly", width=10)
        self.search_location_combo.pack(side="left", padx=(0, 4))
        self.search_location_var.trace_add("write", lambda *a: self._refresh_device_tree())

        # Result count label
        self.search_result_label = tk.Label(
            search_frame, text="", bg=COLORS["bg_white"],
            fg=COLORS["text_gray"], font=("Segoe UI", 7, "italic"),
        )
        self.search_result_label.pack(side="right", padx=(4, 0))

        # Device tree
        tree_frame = tk.Frame(left)
        tree_frame.pack(fill="both", expand=True, padx=8, pady=4)

        cols = ("select", "hostname", "ip", "type", "vendor", "location")
        self.tree = ttk.Treeview(tree_frame, columns=cols, show="headings", selectmode="none")
        self.tree.heading("select", text="Select")
        self.tree.heading("hostname", text="Hostname")
        self.tree.heading("ip", text="IP Address")
        self.tree.heading("type", text="Type")
        self.tree.heading("vendor", text="Vendor")
        self.tree.heading("location", text="Location")
        self.tree.column("select", width=50, minwidth=40, anchor="center", stretch=False)
        self.tree.column("hostname", width=130, minwidth=80)
        self.tree.column("ip", width=110, minwidth=70)
        self.tree.column("type", width=65, minwidth=50, anchor="center")
        self.tree.column("vendor", width=100, minwidth=70)
        self.tree.column("location", width=120, minwidth=70)

        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.tree.bind("<Button-1>", self._on_tree_click)

        self._item_to_device = {}
        self._checked = set()
        self._refresh_device_tree()

        # Right: SSH terminal notebook
        right = tk.Frame(content, bg=COLORS["bg_white"])
        right.pack(side="right", fill="both", expand=True)

        # Header row with title + close-session buttons
        session_header = tk.Frame(right, bg=COLORS["bg_white"])
        session_header.pack(fill="x", padx=10, pady=(8, 4))
        tk.Label(session_header, text="SSH Terminal Sessions",
                 bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                 font=("Segoe UI", 10, "bold")).pack(side="left")
        # Close-session buttons (right side)
        tk.Button(session_header, text="Close Current Tab",
                  command=self._close_current_tab,
                  bg=COLORS["btn_danger"], fg="white", font=("Segoe UI", 8, "bold"),
                  relief="flat", padx=8, pady=2, cursor="hand2").pack(side="right", padx=2)
        tk.Button(session_header, text="Close All Sessions",
                  command=self._close_all_tabs,
                  bg=COLORS["text_gray"], fg="white", font=("Segoe UI", 8),
                  relief="flat", padx=8, pady=2, cursor="hand2").pack(side="right", padx=2)

        self.notebook = ttk.Notebook(right)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        # Right-click context menu on notebook tabs for closing
        self.notebook.bind("<Button-3>", self._on_tab_right_click)
        # Focus-follows-tab: when the user switches to a tab hosting an
        # embedded real PuTTY window, give that window keyboard focus
        # immediately (otherwise typing would go nowhere until clicked).
        self.notebook.bind("<<NotebookTabChanged>>", self._on_notebook_tab_changed)
        self._tab_context_menu = tk.Menu(self, tearoff=0)
        self._tab_context_menu.add_command(label="Close This Tab", command=self._close_current_tab)
        self._tab_context_menu.add_command(label="Close All Sessions", command=self._close_all_tabs)

        # Placeholder tab
        placeholder = tk.Frame(self.notebook, bg=COLORS["bg_white"])
        self.notebook.add(placeholder, text="No Sessions")
        tk.Label(placeholder,
                 text="Select devices from the left and click\n'Login to Selected (SSH Terminal)'",
                 bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                 font=("Segoe UI", 11), justify="center").pack(expand=True)

    # ── credential resolution ──────────────────────────────────
    def _get_credentials_for(self, device: dict) -> Optional[dict]:
        """Resolve credentials for a device using the same priority as the backup engine:
        per-device > per-vendor (firewall) > shared (single-cred mode) > shared.
        """
        # 1. Per-device credentials
        if device.get("use_device_creds") and device.get("device_username") and device.get("device_password"):
            return {
                "username": device["device_username"],
                "password": device["device_password"],
                "enable_password": device.get("device_enable_password", ""),
            }

        # 2. Per-vendor firewall credentials
        if device["device_type"] == "firewall":
            creds = self.manager.get_fw_credentials(device.get("vendor", ""))
            if creds and (creds.get("username") or creds.get("api_token")):
                return {
                    "username": creds.get("username", ""),
                    "password": creds.get("password", ""),
                    "enable_password": creds.get("enable_password", ""),
                }

        # 3. Shared credentials (works for single-cred mode too)
        shared = self.manager.get_shared_credentials()
        if shared.get("username") and shared.get("password"):
            return {
                "username": shared["username"],
                "password": shared["password"],
                "enable_password": shared.get("enable_password", ""),
            }

        return None

    # ── device tree ────────────────────────────────────────────
    def _refresh_device_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self._item_to_device.clear()

        all_devices = self.manager.get_all_devices()

        # Refresh the dynamic vendor/location dropdown options
        self._refresh_filter_options(all_devices)

        # Apply the search/filter bar
        filtered = self._filter_devices(all_devices)

        for d in filtered:
            dtype = d["device_type"]
            vkey = d.get("vendor", "")
            if dtype == "firewall":
                v_display = fw_vendor_label(vkey)
            else:
                v_display = RS_VENDOR_NAMES.get(vkey, vkey)
            check = CHECK_ON if d["id"] in self._checked else CHECK_OFF
            item_id = self.tree.insert("", "end", values=(
                check, d["hostname"], d["ip_address"],
                dtype.title(), v_display, d.get("location", "N/A"),
            ))
            self._item_to_device[item_id] = d

        self.count_label.configure(text=f"{len(all_devices)} devices")
        # Update the "showing N of M" result-count label
        if hasattr(self, "search_result_label"):
            shown = len(filtered)
            total = len(all_devices)
            if shown == total:
                self.search_result_label.configure(text=f"showing {shown}")
            else:
                self.search_result_label.configure(text=f"showing {shown} of {total}")
        self._update_sel_count()

    def _refresh_filter_options(self, devices):
        """Populate the Vendor and Location dropdowns with values that
        actually appear in the current device list."""
        if not hasattr(self, "search_vendor_combo"):
            return  # UI not built yet

        vendor_names = set()
        locations = set()
        for d in devices:
            dtype = d["device_type"]
            vkey = d.get("vendor", "")
            if dtype == "firewall":
                vendor_names.add(fw_vendor_label(vkey))
            else:
                vendor_names.add(RS_VENDOR_NAMES.get(vkey, vkey))
            loc = d.get("location", "")
            if loc:
                locations.add(loc)

        # Preserve the current selection (or fall back to "Any")
        current_vendor = self.search_vendor_var.get()
        current_location = self.search_location_var.get()

        vendor_values = ["Any"] + sorted(vendor_names)
        location_values = ["Any"] + sorted(locations)

        self.search_vendor_combo.configure(values=vendor_values)
        self.search_location_combo.configure(values=location_values)

        if current_vendor not in vendor_values:
            self.search_vendor_var.set("Any")
        if current_location not in location_values:
            self.search_location_var.set("Any")

    def _filter_devices(self, devices):
        """Apply the search bar + dropdown filters to a device list."""
        if not hasattr(self, "search_var"):
            return devices

        query = self.search_var.get().strip().lower()
        type_filter = self.search_type_var.get()
        vendor_filter = self.search_vendor_var.get()
        location_filter = self.search_location_var.get()

        out = []
        for d in devices:
            # Hostname / IP substring match (case-insensitive)
            if query:
                hostname = d.get("hostname", "").lower()
                ip = d.get("ip_address", "").lower()
                if query not in hostname and query not in ip:
                    continue

            # Device type filter
            if type_filter and type_filter != "Any":
                if d["device_type"] != type_filter.lower():
                    continue

            # Vendor filter (compare display name)
            if vendor_filter and vendor_filter != "Any":
                dtype = d["device_type"]
                vkey = d.get("vendor", "")
                if dtype == "firewall":
                    v_display = fw_vendor_label(vkey)
                else:
                    v_display = RS_VENDOR_NAMES.get(vkey, vkey)
                if v_display != vendor_filter:
                    continue

            # Location filter
            if location_filter and location_filter != "Any":
                if d.get("location", "") != location_filter:
                    continue

            out.append(d)
        return out

    def _on_tree_click(self, event):
        if self.tree.identify("region", event.x, event.y) != "cell":
            return
        if self.tree.identify_column(event.x) != "#1":
            return
        item_id = self.tree.identify_row(event.y)
        if not item_id:
            return
        d = self._item_to_device.get(item_id)
        if not d:
            return
        if d["id"] in self._checked:
            self._checked.discard(d["id"])
            symbol = CHECK_OFF
        else:
            self._checked.add(d["id"])
            symbol = CHECK_ON
        values = list(self.tree.item(item_id, "values"))
        values[0] = symbol
        self.tree.item(item_id, values=values)
        self._update_sel_count()

    def _select_all(self, select: bool):
        if select:
            for d in self.manager.get_all_devices():
                self._checked.add(d["id"])
        else:
            self._checked.clear()
        self._refresh_device_tree()

    def _update_sel_count(self):
        self.sel_count.configure(text=f"{len(self._checked)} selected")

    def _get_selected_devices(self) -> List[dict]:
        return [d for d in self.manager.get_all_devices() if d["id"] in self._checked]

    def _on_ops_close(self):
        """Close all SSH sessions and destroy the window (fixes C3)."""
        for tab in list(self._terminal_tabs):
            tab.close()
        self._terminal_tabs.clear()
        self.destroy()

    # ── feature handlers ───────────────────────────────────────
    def _login_selected(self):
        devices = self._get_selected_devices()
        if not devices:
            messagebox.showinfo("Info", "Select one or more devices to login.", parent=self)
            return

        use_embedded = self.launch_mode_var.get() == "Embedded PuTTY Tab"
        if use_embedded and not putty_embed.is_supported():
            messagebox.showwarning(
                "Windows Only",
                "Embedded PuTTY tabs require Windows (they work by "
                "reparenting a real putty.exe window, which is a "
                "Windows-specific mechanism).\n\n"
                "Switching to 'External PuTTY (separate window)' for "
                "this platform.",
                parent=self)
            self.launch_mode_var.set("External PuTTY (separate window)")
            use_embedded = False

        # Remove placeholder if present (only relevant for in-app tabs)
        if use_embedded and self.notebook.tabs() and \
                "No Sessions" in self.notebook.tab(self.notebook.tabs()[0], "text"):
            self.notebook.forget(self.notebook.tabs()[0])

        for device in devices:
            creds = self._get_credentials_for(device)
            if not creds or not creds.get("username"):
                messagebox.showwarning(
                    "No Credentials",
                    f"No credentials for {device['hostname']} ({device['ip_address']}).\n"
                    "Set credentials in the main backup tool first.",
                    parent=self)
                continue

            if not use_embedded:
                self._launch_putty(device, creds)
                continue

            tab = PuttyEmbeddedTab(self.notebook, device, creds, self)
            self.notebook.add(tab, text=f"{device['hostname']}")
            self._terminal_tabs.append(tab)
            self.notebook.select(tab)

    def _launch_putty(self, device: dict, creds: dict):
        """Launch the real putty.exe as its own separate OS window
        (not embedded — works on any platform putty.exe runs on).

        Passes the password via -pw so PuTTY doesn't prompt for it
        (per explicit request), and auto-types 'enable' + the enable
        secret + 'terminal length 0' once the shell is up, the same
        way the old paramiko-backed flow used to — this uses PID-based
        window discovery for the *separate* window too, purely to get
        an hwnd to post those keystrokes into (the window itself is
        never reparented/embedded in this mode).
        """
        putty_path = self._find_putty()
        if not putty_path:
            messagebox.showerror(
                "PuTTY Not Found",
                "Could not find putty.exe on this system.\n\n"
                "Install PuTTY (https://www.putty.org) and make sure "
                "putty.exe is on your PATH, or place it alongside this "
                "application, then try again.",
                parent=self)
            return

        host = device.get("ip_address", "")
        port = device.get("port", 22)
        username = creds.get("username", "")
        password = creds.get("password", "")
        enable_password = creds.get("enable_password", "")
        device_type = device.get("device_type", "")

        def _do_launch():
            try:
                proc = putty_embed.launch(putty_path, host, port, username, password)
            except putty_embed.PuttyLaunchError as e:
                self.after(0, lambda: messagebox.showerror(
                    "Launch Failed",
                    f"Could not launch PuTTY for {device.get('hostname', host)}:\n{e}",
                    parent=self))
                return
            if not putty_embed.is_supported() or not enable_password or "cisco" not in device_type:
                return
            hwnd = putty_embed.find_window_by_pid(proc.pid, timeout=8.0)
            if hwnd:
                putty_embed.auto_enable_sequence(hwnd, enable_password)

        threading.Thread(target=_do_launch, daemon=True).start()

    def _find_putty(self) -> Optional[str]:
        """Locate putty.exe: PATH first, then common Windows install dirs."""
        import os
        import shutil

        found = shutil.which("putty") or shutil.which("putty.exe")
        if found:
            return found

        candidates = [
            "C:\\Program Files\\PuTTY\\putty.exe",
            "C:\\Program Files (x86)\\PuTTY\\putty.exe",
        ]
        for path in candidates:
            if os.path.isfile(path):
                return path
        return None

    def _on_tab_right_click(self, event):
        """Show the right-click context menu on notebook tabs."""
        # Identify which tab was right-clicked
        tab_index = self.notebook.index(f"@{event.x},{event.y}")
        if tab_index is not None and tab_index >= 0:
            # Select the tab that was right-clicked
            self.notebook.select(tab_index)
            # Show the context menu
            self._tab_context_menu.tk_popup(event.x_root, event.y_root)

    def _on_notebook_tab_changed(self, event):
        current = self.notebook.select()
        if not current:
            return
        try:
            tab_widget = self.notebook.nametowidget(current)
        except Exception:
            return
        if isinstance(tab_widget, PuttyEmbeddedTab):
            # Small delay so the tab is actually visible/mapped first
            self.after(50, tab_widget.focus_terminal)
            # Keep the device-list collapse state in sync with whichever
            # tab is now showing, so switching tabs doesn't leave the
            # device panel collapsed for a tab that isn't maximized (or
            # vice versa).
            self._set_device_panel_maximized(tab_widget._maximized)

    def _set_device_panel_maximized(self, maximized: bool):
        """Collapse the device list down to just the checkbox + hostname
        columns (freeing horizontal space for the terminal), or restore
        all columns. Driven by a terminal tab's Maximize/Restore button."""
        if not hasattr(self, "_device_panel_saved_displaycols"):
            self._device_panel_saved_displaycols = self.tree["displaycolumns"]
        if maximized:
            self.tree["displaycolumns"] = ("select", "hostname")
            self.left_panel.configure(width=190)
            self.left_panel.pack_propagate(False)
        else:
            self.tree["displaycolumns"] = self._device_panel_saved_displaycols
            self.left_panel.pack_propagate(True)

    def _close_current_tab(self):
        """Close the currently selected SSH terminal tab."""
        current = self.notebook.select()
        if not current:
            return

        tab_text = self.notebook.tab(current, "text")

        # Don't close the placeholder
        if tab_text == "No Sessions":
            return

        # Find the PuttyEmbeddedTab instance and close its putty.exe process
        tab_widget = self.notebook.nametowidget(current)
        if isinstance(tab_widget, PuttyEmbeddedTab):
            tab_widget.close()
            if tab_widget in self._terminal_tabs:
                self._terminal_tabs.remove(tab_widget)

        # Remove the tab from the notebook
        self.notebook.forget(current)

        # If no tabs remain, show the placeholder
        if not self.notebook.tabs():
            placeholder = tk.Frame(self.notebook, bg=COLORS["bg_white"])
            self.notebook.add(placeholder, text="No Sessions")
            tk.Label(placeholder,
                     text="Select devices from the left and click\n'Login to Selected (SSH Terminal)'",
                     bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                     font=("Segoe UI", 11), justify="center").pack(expand=True)

    def _close_all_tabs(self):
        """Close all SSH terminal tabs (disconnect all sessions)."""
        if not self._terminal_tabs:
            return

        if not messagebox.askyesno(
            "Close All Sessions",
            f"Disconnect and close all {len(self._terminal_tabs)} SSH session(s)?",
            parent=self,
        ):
            return

        # Close all SSH connections
        for tab in list(self._terminal_tabs):
            tab.close()

        # Remove all tabs from the notebook
        for tab_id in self.notebook.tabs():
            self.notebook.forget(tab_id)

        self._terminal_tabs.clear()

        # Show the placeholder
        placeholder = tk.Frame(self.notebook, bg=COLORS["bg_white"])
        self.notebook.add(placeholder, text="No Sessions")
        tk.Label(placeholder,
                 text="Select devices from the left and click\n'Login to Selected (SSH Terminal)'",
                 bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                 font=("Segoe UI", 11), justify="center").pack(expand=True)

    def _bulk_push(self):
        devices = self._get_selected_devices()
        if not devices:
            messagebox.showinfo("Info", "Select one or more devices for bulk config push.", parent=self)
            return
        BulkConfigPushDialog(self, devices, self)

    def _compare_configs(self):
        ConfigCompareDialog(self, self.manager, self)

    def _compliance_check(self):
        ComplianceDialog(self, self.manager, self)

    def _diagnostics(self):
        DiagnosticsDialog(self, self.manager, self)

    def _templates(self):
        TemplateManagerDialog(self, self)

    def _change_history(self):
        ChangeHistoryDialog(self, self)
