"""
Config Template Manager
=======================

Stores and retrieves reusable configuration snippets that can be
deployed to devices via the Config Push feature.

Templates are stored in <data_dir>/config_templates.json as a list:
    [
        {
            "name": "Standard SNMP v3 Config",
            "description": "Standard SNMP v3 configuration for all sites",
            "category": "SNMP",
            "commands": ["snmp-server group ADMINS v3 priv", "snmp-server user ..."],
            "created_at": "2024-01-01T10:00:00",
            "updated_at": "2024-01-01T10:00:00",
        },
        ...
    ]
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Optional
from security_utils import secure_write_json, restrict_existing_file


TEMPLATES_FILE = "config_templates.json"


class ConfigTemplate:
    """A reusable config snippet."""

    def __init__(
        self,
        name: str,
        commands: List[str],
        description: str = "",
        category: str = "General",
        created_at: str = "",
        updated_at: str = "",
    ):
        self.name = name
        self.commands = commands
        self.description = description
        self.category = category
        self.created_at = created_at or datetime.now().isoformat()
        self.updated_at = updated_at or datetime.now().isoformat()

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "commands": self.commands,
            "description": self.description,
            "category": self.category,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, d: Dict) -> "ConfigTemplate":
        return cls(
            name=d.get("name", ""),
            commands=d.get("commands", []),
            description=d.get("description", ""),
            category=d.get("category", "General"),
            created_at=d.get("created_at", ""),
            updated_at=d.get("updated_at", ""),
        )


class TemplateManager:
    """Manages config templates stored in a JSON file."""

    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        self.templates_file = os.path.join(data_dir, TEMPLATES_FILE)
        self._templates: List[ConfigTemplate] = []
        self._load()
        restrict_existing_file(self.templates_file)

    def _load(self):
        if not os.path.exists(self.templates_file):
            self._templates = []
            # Seed with some built-in templates
            self._seed_builtin_templates()
            return
        try:
            with open(self.templates_file, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, list):
                self._templates = [ConfigTemplate.from_dict(d) for d in raw if isinstance(d, dict)]
        except (json.JSONDecodeError, IOError):
            self._templates = []

    def _save(self):
        secure_write_json(self.templates_file, [t.to_dict() for t in self._templates])

    def _seed_builtin_templates(self):
        """Create some starter templates so the user sees examples."""
        builtins = [
            ConfigTemplate(
                name="Enable SSH v2",
                description="Ensure SSH version 2 is enabled and RSA keys are generated",
                category="Security",
                commands=[
                    "ip domain-name example.com",
                    "crypto key generate rsa modulus 2048",
                    "ip ssh version 2",
                    "line vty 0 15",
                    "transport input ssh",
                    "exit",
                ],
            ),
            ConfigTemplate(
                name="Disable Telnet",
                description="Remove telnet from VTY lines for security",
                category="Security",
                commands=[
                    "line vty 0 15",
                    "transport input ssh",
                    "exit",
                ],
            ),
            ConfigTemplate(
                name="Standard SNMP v3",
                description="Configure SNMP v3 with authPriv (replace placeholders)",
                category="SNMP",
                commands=[
                    "snmp-server group NCM v3 priv read VIEW_ALL write VIEW_ALL",
                    "snmp-server user ncm-user NCM v3 auth sha YourAuthPass priv aes 128 YourPrivPass",
                    "snmp-server view VIEW_ALL iso included",
                ],
            ),
            ConfigTemplate(
                name="Enable Password Encryption",
                description="Encrypt all plaintext passwords in the config",
                category="Security",
                commands=[
                    "service password-encryption",
                ],
            ),
            ConfigTemplate(
                name="Remote Syslog Server",
                description="Forward logs to a remote syslog server (replace IP)",
                category="Logging",
                commands=[
                    "logging 10.0.0.100",
                    "logging trap informational",
                    "logging source-interface Loopback0",
                ],
            ),
            ConfigTemplate(
                name="Create VLAN 100",
                description="Create a data VLAN named DATA",
                category="Network",
                commands=[
                    "vlan 100",
                    "name DATA",
                    "exit",
                ],
            ),
        ]
        self._templates = builtins
        self._save()

    def get_all(self) -> List[ConfigTemplate]:
        return list(self._templates)

    def get_by_name(self, name: str) -> Optional[ConfigTemplate]:
        for t in self._templates:
            if t.name == name:
                return t
        return None

    def get_categories(self) -> List[str]:
        return sorted(set(t.category for t in self._templates))

    def add(self, template: ConfigTemplate):
        """Add a new template (replaces if name exists)."""
        self._templates = [t for t in self._templates if t.name != template.name]
        self._templates.append(template)
        self._save()

    def delete(self, name: str) -> bool:
        original = len(self._templates)
        self._templates = [t for t in self._templates if t.name != name]
        if len(self._templates) < original:
            self._save()
            return True
        return False

    def update(self, name: str, **kwargs):
        """Update fields of an existing template."""
        for t in self._templates:
            if t.name == name:
                for k, v in kwargs.items():
                    if hasattr(t, k):
                        setattr(t, k, v)
                t.updated_at = datetime.now().isoformat()
                self._save()
                return t
        return None
