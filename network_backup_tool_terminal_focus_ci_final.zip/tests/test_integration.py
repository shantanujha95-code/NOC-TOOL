import os
import sys
import types
import time
from pathlib import Path


def _fake_netmiko_module(config_text="hostname CI-ROUTER\ninterface Gi1\n description CI\n"):
    class FakeConnection:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.disconnected = False
            self.commands = []

        def enable(self):
            return "enabled"

        def send_command(self, command, **kwargs):
            self.commands.append(command)
            return config_text

        def send_config_set(self, commands, **kwargs):
            self.commands.extend(commands)
            return "\n".join(f"Applied: {c}" for c in commands)

        def save(self):
            return "saved"

        def disconnect(self):
            self.disconnected = True

    created = []

    def ConnectHandler(**kwargs):
        c = FakeConnection(**kwargs)
        created.append(c)
        return c

    return types.SimpleNamespace(ConnectHandler=ConnectHandler), created


def test_device_manager_roundtrip(tmp_path):
    from device_manager import DeviceManager

    manager = DeviceManager(data_dir=str(tmp_path))
    device = manager.add_device(
        hostname="CI-Router",
        ip_address="127.0.0.1",
        device_type="router",
        location="CI",
        vendor="cisco_ios",
        port=2222,
    )
    assert manager.device_count() == 1
    assert manager.get_device(device["id"])["hostname"] == "CI-Router"
    manager.update_backup_status(device["id"], True)
    assert manager.get_device(device["id"])["last_status"] == "success"


def test_backup_save_and_real_diff(tmp_path):
    from backup_engine import UnifiedBackupEngine

    engine = UnifiedBackupEngine(backup_base_dir=str(tmp_path / "backups"))
    device = {
        "id": "ci-1", "hostname": "CI-Router", "ip_address": "127.0.0.1",
        "device_type": "router", "location": "CI", "vendor": "cisco_ios", "port": 2222,
    }
    first = engine._save_backup(device, "hostname CI\ninterface Gi1\n description OLD\n", "ssh", "2026-01-01_00-00-00")
    second = engine._save_backup(device, "hostname CI\ninterface Gi1\n description NEW\n", "ssh", "2026-01-01_00-00-01")
    assert first.success
    assert second.success
    assert second.diff_summary == "+1 -1 lines changed"
    assert "description NEW" in second.diff_text
    assert engine.get_backup_count()["total"] == 2


def test_backup_orchestration_with_fake_netmiko(monkeypatch, tmp_path):
    fake, connections = _fake_netmiko_module()
    monkeypatch.setitem(sys.modules, "netmiko", fake)

    from backup_engine import UnifiedBackupEngine

    engine = UnifiedBackupEngine(backup_base_dir=str(tmp_path / "backups"))
    engine.set_shared_credentials("ciuser", "cipass", "")
    engine._test_reachability = lambda host, port: (True, "")
    device = {
        "id": "ci-2", "hostname": "CI-Router", "ip_address": "127.0.0.1",
        "device_type": "router", "location": "CI", "vendor": "cisco_ios", "port": 2222,
    }
    result = engine.backup_device(device)
    assert result.success
    assert result.backup_method == "ssh"
    assert connections
    assert any("show running-config" in c.commands for c in connections)


def test_config_pusher_push_fetch_and_diagnostic(monkeypatch):
    fake, connections = _fake_netmiko_module("hostname CI\ninterface Gi1\n description TEST\n")
    monkeypatch.setitem(sys.modules, "netmiko", fake)

    from ssh_session import ConfigPusher

    pusher = ConfigPusher()
    device = {
        "id": "ci-3", "hostname": "CI-Router", "ip_address": "127.0.0.1",
        "device_type": "router", "vendor": "cisco_ios", "port": 2222,
    }
    creds = {"username": "ciuser", "password": "cipass", "enable_password": ""}

    pushed = pusher.push_config(device, ["interface Gi1", "description CI"], creds)
    assert pushed.success
    assert pushed.commands_pushed == ["interface Gi1", "description CI"]

    config = pusher.fetch_running_config(device, creds)
    assert "hostname CI" in config

    diag = pusher.run_diagnostic(device, creds, "show version")
    assert "hostname CI" in diag
    assert len(connections) >= 3


def test_interactive_ssh_terminal_with_fake_paramiko(monkeypatch):
    import queue

    class FakeChannel:
        def __init__(self):
            self.sent = []
            self.closed = False
            self.recv_count = 0
            self.resized = None

        def settimeout(self, value):
            self.timeout = value

        def send(self, data):
            self.sent.append(data)
            return len(data)

        def recv_ready(self):
            return self.recv_count == 0

        def recv(self, n):
            self.recv_count += 1
            return b"CI-ROUTER# "

        def exit_status_ready(self):
            return False

        def resize_pty(self, **kwargs):
            self.resized = kwargs

        def close(self):
            self.closed = True

    class FakeClient:
        def __init__(self):
            self.channel = FakeChannel()
            self.closed = False

        def set_missing_host_key_policy(self, policy):
            self.policy = policy

        def connect(self, **kwargs):
            self.connect_kwargs = kwargs

        def invoke_shell(self, **kwargs):
            return self.channel

        def close(self):
            self.closed = True

    client = FakeClient()
    fake_paramiko = types.SimpleNamespace(
        SSHClient=lambda: client,
        AutoAddPolicy=lambda: object(),
    )
    monkeypatch.setitem(sys.modules, "paramiko", fake_paramiko)

    from ssh_session import SSHTerminal

    terminal = SSHTerminal("127.0.0.1", 2222, "ciuser", "cipass")
    assert terminal.connect()
    time.sleep(0.1)
    terminal.send("show version\n")
    terminal.send_command("show running-config")
    terminal.resize(120, 40, 1200, 800)
    output = terminal.get_output()
    assert "CI-ROUTER#" in output
    assert any(b"show version" in x for x in client.channel.sent)
    assert client.channel.resized["width"] == 120
    terminal.close()
    assert client.closed


def test_compliance_templates_history_and_report(tmp_path):
    from compliance import run_compliance_for_device
    from config_templates import TemplateManager, ConfigTemplate
    from change_history import ChangeHistory, ChangeRecord
    from report_generator import UnifiedReportGenerator
    from backup_engine import BackupResult

    config = """hostname CI\nip ssh version 2\nservice password-encryption\nenable secret 5 HASH\nbanner login ^CI^\nline vty 0 15\n transport input ssh\nlogging 10.0.0.1\nntp server 10.0.0.2\n"""
    device = {"id": "ci-4", "hostname": "CI-Router", "ip_address": "127.0.0.1", "device_type": "router"}
    report = run_compliance_for_device(device, config)
    assert report.total_count > 0
    assert report.passed_count > 0

    templates = TemplateManager(str(tmp_path))
    template = ConfigTemplate("CI Template", ["interface Gi1", "description CI"], category="CI")
    templates.add(template)
    assert any(t.name == "CI Template" for t in templates.get_all())

    history = ChangeHistory(str(tmp_path))
    history.add(ChangeRecord(device_id="ci-4", hostname="CI-Router", success=True, commands=["description CI"]))
    assert history.count() == 1
    assert history.get_for_device("ci-4")[0].success

    report_gen = UnifiedReportGenerator(output_dir=str(tmp_path / "reports"))
    result = BackupResult(
        device_id="ci-4", hostname="CI-Router", ip_address="127.0.0.1",
        device_type="router", vendor="cisco_ios", success=True,
        config_text="hostname CI\n", backup_method="ssh", diff_summary="No changes",
    )
    pdf = report_gen.generate([result], [device])
    assert Path(pdf).exists()
    assert Path(pdf).stat().st_size > 0


def test_terminal_focus_regression_after_click_away_and_return(monkeypatch):
    """Regression test for the embedded-PuTTY focus-loss bug.

    The terminal is a native child window, so Tk does not reliably receive
    Button-1 events from it. PuttyEmbeddedTab therefore uses a Win32 polling
    path. This test drives that exact path and verifies that a click inside
    the terminal calls putty_embed.focus() after focus has moved elsewhere.
    """
    import ops_gui

    class DummyFrame:
        def winfo_rootx(self):
            return 100

        def winfo_rooty(self):
            return 200

        def winfo_width(self):
            return 800

        def winfo_height(self):
            return 500

    class DummyTab:
        pass

    tab = DummyTab()
    tab._closing = False
    tab._hwnd = 12345
    tab._last_left_down = False
    tab.embed_frame = DummyFrame()
    tab._poll_click_focus = lambda: None
    tab.after = lambda delay, callback: None

    monkeypatch.setattr(ops_gui.putty_embed, "is_left_button_down", lambda: True)
    monkeypatch.setattr(ops_gui.putty_embed, "get_cursor_pos", lambda: (500, 400))

    focused = []
    monkeypatch.setattr(ops_gui.putty_embed, "focus", lambda hwnd: focused.append(hwnd))

    ops_gui.PuttyEmbeddedTab._poll_click_focus(tab)

    assert focused == [12345]
    assert tab._last_left_down is True


def test_terminal_focus_is_requested_after_maximize_restore(monkeypatch):
    """Regression test: maximize/restore must return keyboard focus to PuTTY."""
    import ops_gui

    class DummyButton:
        def __init__(self):
            self.text = None
        def configure(self, **kwargs):
            self.text = kwargs.get("text", self.text)

    class DummyFrame:
        def pack_forget(self):
            pass

    class DummyPaned:
        def sash_coord(self, index):
            return (250, 0)
        def forget(self, widget):
            pass
        def add(self, widget, **kwargs):
            pass
        def sash_place(self, index, x, y):
            pass

    class DummyTab:
        pass

    class DummyOps:
        def _set_device_panel_maximized(self, value):
            self.maximized = value

    tab = DummyTab()
    tab._maximized = False
    tab._saved_paned_sash = None
    tab._hwnd = 12345
    tab.paned = DummyPaned()
    tab._push_frame = DummyFrame()
    tab.max_btn = DummyButton()
    tab.ops_window = DummyOps()
    tab.focus_terminal = lambda: focused.append(12345)
    tab.after = lambda delay, callback: callback()

    focused = []
    monkeypatch.setattr(ops_gui.putty_embed, "focus", lambda hwnd: focused.append(hwnd))

    ops_gui.PuttyEmbeddedTab._toggle_maximize(tab)
    assert tab._maximized is True
    assert focused == [12345]

    ops_gui.PuttyEmbeddedTab._toggle_maximize(tab)
    assert tab._maximized is False
    assert focused == [12345, 12345]
