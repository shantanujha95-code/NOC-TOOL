"""
Windows end-to-end regression test for the REAL embedded PuTTY path.

The production path under test is:
    PuttyEmbeddedTab
        -> _connect()
        -> putty_embed.launch()
        -> putty_embed.find_window_by_pid()
        -> _on_window_found()
        -> putty_embed.embed()
        -> _poll_click_focus()
        -> putty_embed.focus()

A local Paramiko SSH server is used, so no external router is required.

The test is opt-in because it requires an interactive Windows desktop:
    RUN_REAL_PUTTY_TEST=1
"""

from __future__ import annotations

import ctypes
import os
import queue
import socket
import threading
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

if os.name != "nt":
    pytest.skip("Requires Windows.", allow_module_level=True)

if os.environ.get("RUN_REAL_PUTTY_TEST") != "1":
    pytest.skip("Set RUN_REAL_PUTTY_TEST=1 to enable.", allow_module_level=True)

import tkinter as tk

import paramiko

import ops_gui
import putty_embed


USERNAME = "ciuser"
PASSWORD = "ci-password"
WAIT = 20.0


class _Server(paramiko.ServerInterface):
    def __init__(self) -> None:
        self.shell_requested = threading.Event()

    def check_auth_password(self, username, password):
        if username == USERNAME and password == PASSWORD:
            return paramiko.AUTH_SUCCESSFUL
        return paramiko.AUTH_FAILED

    def get_allowed_auths(self, username):
        return "password"

    def check_channel_request(self, kind, chanid):
        if kind == "session":
            return paramiko.OPEN_SUCCEEDED
        return paramiko.OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED

    def check_channel_pty_request(
        self, channel, term, width, height, pixelwidth, pixelheight, modes
    ):
        return True

    def check_channel_shell_request(self, channel):
        self.shell_requested.set()
        return True


class LocalSSH:
    def __init__(self):
        self.host_key = paramiko.RSAKey.generate(2048)
        self.received = queue.Queue()
        self.ready = threading.Event()
        self.error = None
        self.stop = threading.Event()
        self.port = None
        self.thread = threading.Thread(
            target=self._run,
            name="ci-local-ssh",
            daemon=True,
        )

    @property
    def putty_hostkey(self) -> str:
        # PuTTY accepts the traditional colon-separated SSH fingerprint.
        return ":".join(f"{b:02x}" for b in self.host_key.get_fingerprint())

    def start(self):
        self.thread.start()
        if not self.ready.wait(WAIT):
            raise AssertionError("Local SSH server did not start.")
        if self.error:
            raise AssertionError("Local SSH server failed.") from self.error

    def stop_server(self):
        self.stop.set()
        if self.thread.is_alive():
            self.thread.join(timeout=3)

    def wait_for(self, expected: str, timeout=WAIT):
        deadline = time.monotonic() + timeout
        seen = []

        while time.monotonic() < deadline:
            try:
                value = self.received.get(timeout=0.25)
            except queue.Empty:
                continue

            seen.append(value)
            if expected in value:
                return

        raise AssertionError(
            f"SSH server did not receive {expected!r}. Received={seen!r}"
        )

    def _run(self):
        listener = None

        try:
            listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            listener.bind(("127.0.0.1", 0))
            listener.listen(5)
            listener.settimeout(0.5)

            self.port = listener.getsockname()[1]
            self.ready.set()

            while not self.stop.is_set():
                try:
                    client, _ = listener.accept()
                except socket.timeout:
                    continue

                transport = paramiko.Transport(client)
                transport.add_server_key(self.host_key)
                server = _Server()

                try:
                    transport.start_server(server=server)
                    channel = transport.accept(10)

                    if channel is None:
                        continue

                    channel.settimeout(0.25)

                    # Wait for PuTTY to request a shell, then provide a prompt.
                    server.shell_requested.wait(10)

                    try:
                        channel.send(b"CI-SSH> ")
                    except Exception:
                        pass

                    buffer = ""

                    while not self.stop.is_set() and transport.is_active():
                        try:
                            data = channel.recv(4096)
                        except socket.timeout:
                            continue
                        except Exception:
                            break

                        if not data:
                            break

                        buffer += data.decode(
                            "utf-8",
                            errors="replace",
                        )

                        # Normalize CR/LF and record complete commands.
                        normalized = buffer.replace("\r\n", "\n").replace(
                            "\r", "\n"
                        )

                        if "\n" not in normalized:
                            continue

                        lines = normalized.split("\n")
                        buffer = lines.pop()

                        for line in lines:
                            line = line.strip()
                            if line:
                                self.received.put(line)

                finally:
                    try:
                        transport.close()
                    except Exception:
                        pass

        except BaseException as exc:
            self.error = exc
            self.ready.set()

        finally:
            if listener:
                try:
                    listener.close()
                except Exception:
                    pass


def _wait(root, predicate, description, timeout=WAIT):
    deadline = time.monotonic() + timeout

    while time.monotonic() < deadline:
        root.update_idletasks()
        root.update()

        if predicate():
            return

        time.sleep(0.05)

    raise AssertionError(f"Timed out waiting for {description}.")


def _find_putty() -> str:
    explicit = os.environ.get("PUTTY_PATH")

    candidates = [
        explicit,
        r"C:\Program Files\PuTTY\putty.exe",
        r"C:\Program Files (x86)\PuTTY\putty.exe",
    ]

    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return str(Path(candidate))

    raise AssertionError(
        "putty.exe was not found. PUTTY_PATH was not set and "
        "standard PuTTY installation paths were empty."
    )


def _send_unicode(text: str):
    """
    Send genuine Windows keyboard input using SendInput.

    This is intentionally NOT putty_embed.send_text(): the regression
    being tested is actual focus/keyboard routing after a mouse click.
    """
    user32 = ctypes.windll.user32

    INPUT_KEYBOARD = 1
    KEYEVENTF_KEYUP = 0x0002
    KEYEVENTF_UNICODE = 0x0004
    VK_RETURN = 0x0D

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [
            ("wVk", ctypes.c_ushort),
            ("wScan", ctypes.c_ushort),
            ("dwFlags", ctypes.c_ulong),
            ("time", ctypes.c_ulong),
            ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
        ]

    class INPUT(ctypes.Structure):
        _fields_ = [
            ("type", ctypes.c_ulong),
            ("ki", KEYBDINPUT),
        ]

    def make_key(scan, flags):
        return INPUT(
            INPUT_KEYBOARD,
            KEYBDINPUT(0, scan, flags, 0, None),
        )

    for char in text:
        scan = ord(char)

        inputs = (INPUT * 2)(
            make_key(scan, KEYEVENTF_UNICODE),
            make_key(scan, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP),
        )

        sent = user32.SendInput(
            2,
            ctypes.byref(inputs),
            ctypes.sizeof(INPUT),
        )

        if sent != 2:
            raise AssertionError(
                f"SendInput failed while typing {char!r}; sent={sent}"
            )

    inputs = (INPUT * 2)(
        make_key(VK_RETURN, 0),
        make_key(VK_RETURN, KEYEVENTF_KEYUP),
    )

    sent = user32.SendInput(
        2,
        ctypes.byref(inputs),
        ctypes.sizeof(INPUT),
    )

    if sent != 2:
        raise AssertionError("SendInput failed for Enter.")


def _real_click(hwnd: int):
    """
    Generate a genuine Windows left click over the embedded PuTTY.

    PuttyEmbeddedTab._poll_click_focus() observes GetAsyncKeyState and
    GetCursorPos, so this exercises the exact production refocus path.
    """
    user32 = ctypes.windll.user32

    class RECT(ctypes.Structure):
        _fields_ = [
            ("left", ctypes.c_long),
            ("top", ctypes.c_long),
            ("right", ctypes.c_long),
            ("bottom", ctypes.c_long),
        ]

    rect = RECT()

    if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
        raise AssertionError("GetWindowRect failed.")

    x = (rect.left + rect.right) // 2
    y = (rect.top + rect.bottom) // 2

    if not user32.SetCursorPos(x, y):
        raise AssertionError("SetCursorPos failed.")

    MOUSEEVENTF_LEFTDOWN = 0x0002
    MOUSEEVENTF_LEFTUP = 0x0004

    user32.mouse_event(
        MOUSEEVENTF_LEFTDOWN,
        0,
        0,
        0,
        0,
    )

    time.sleep(0.08)

    user32.mouse_event(
        MOUSEEVENTF_LEFTUP,
        0,
        0,
        0,
        0,
    )


def _parent_hwnd(hwnd: int) -> int:
    return int(ctypes.windll.user32.GetParent(hwnd) or 0)


@pytest.mark.timeout(180)
def test_real_embedded_putty_focus_roundtrip():
    putty = _find_putty()
    ssh = LocalSSH()

    root = None
    tab = None

    # This is deliberately minimal, but matches the interface actually
    # used by PuttyEmbeddedTab in the uploaded project.
    fake_ops = SimpleNamespace(
        _find_putty=lambda: putty,
        _set_device_panel_maximized=lambda maximized: None,
        template_manager=SimpleNamespace(
            get_all=lambda: []
        ),
    )

    device = {
        "hostname": "CI-SSH",
        "ip_address": "127.0.0.1",
        "port": 0,
        "device_type": "linux",
    }

    credentials = {
        "username": USERNAME,
        "password": PASSWORD,
        "enable_password": "",
    }

    try:
        ssh.start()
        device["port"] = ssh.port

        # The production launch path accepts extra PuTTY arguments. Add the
        # generated CI server fingerprint only for this test so PuTTY does
        # not stop on its first-connection host-key confirmation dialog.
        # This still exercises the real putty_embed.launch() and the real
        # PuttyEmbeddedTab._connect() path.
        real_launch = putty_embed.launch

        def _ci_launch(putty_path, host, port, username, password="", extra_args=None):
            args = list(extra_args or [])
            args += ["-hostkey", ssh.putty_hostkey]
            return real_launch(
                putty_path, host, port, username, password, args
            )

        monkeypatch = pytest.MonkeyPatch()
        monkeypatch.setattr(putty_embed, "launch", _ci_launch)

        root = tk.Tk()
        root.title("NetworkBackupTool - CI Embedded PuTTY")
        root.geometry("1200x800")
        root.update_idletasks()
        root.update()

        # IMPORTANT: this is the exact constructor used by the uploaded
        # production ops_gui.py.
        tab = ops_gui.PuttyEmbeddedTab(
            root,
            device,
            credentials,
            fake_ops,
        )

        tab.pack(
            fill="both",
            expand=True,
        )

        root.update_idletasks()
        root.update()

        # Production _connect() runs automatically from __init__().
        _wait(
            root,
            lambda: tab._proc is not None,
            "PuTTY process to start",
        )

        proc = tab._proc

        try:
            _wait(
                root,
                lambda: tab._hwnd is not None,
                "real PuTTY HWND to be embedded",
            )
        except AssertionError as exc:
            process_alive = bool(
                proc is not None and proc.poll() is None
            )

            discovered = None

            if proc is not None and process_alive:
                discovered = putty_embed.find_window_by_pid(
                    proc.pid,
                    timeout=1.0,
                )

            raise AssertionError(
                f"{exc} "
                f"PID={getattr(proc, 'pid', None)}; "
                f"alive={process_alive}; "
                f"independent_find_window={discovered}"
            ) from exc

        hwnd = int(tab._hwnd)

        assert putty_embed.is_window_alive(hwnd), (
            f"PuTTY HWND {hwnd:#x} is not alive."
        )

        container_hwnd = int(tab.embed_frame.winfo_id())
        parent_hwnd = _parent_hwnd(hwnd)

        assert parent_hwnd == container_hwnd, (
            "PuTTY launched but was not actually embedded. "
            f"PuTTY HWND={hwnd:#x}; "
            f"parent={parent_hwnd:#x}; "
            f"container={container_hwnd:#x}"
        )

        # Give the SSH shell time to initialize.
        deadline = time.monotonic() + WAIT

        while time.monotonic() < deadline:
            root.update_idletasks()
            root.update()

            if ssh.error:
                raise AssertionError(
                    "Local SSH server failed."
                ) from ssh.error

            time.sleep(0.05)

        # --------------------------------------------------------
        # 1. Initial keyboard input.
        # --------------------------------------------------------
        tab.focus_terminal()
        root.update()

        _send_unicode("CI_INITIAL")
        ssh.wait_for("CI_INITIAL")

        # --------------------------------------------------------
        # 2. EXACT reported regression:
        #    focus away -> real click back -> keyboard.
        # --------------------------------------------------------
        outside = tk.Button(
            root,
            text="CLICK OUTSIDE TERMINAL",
        )
        outside.pack(side="bottom")

        outside.focus_set()

        root.update()
        time.sleep(0.1)

        _real_click(hwnd)

        # Production _poll_click_focus runs every 20ms.
        time.sleep(0.25)

        root.update_idletasks()
        root.update()

        _send_unicode("CI_CLICK_RETURN")
        ssh.wait_for("CI_CLICK_RETURN")

        # --------------------------------------------------------
        # 3. Production maximize/restore path.
        # --------------------------------------------------------
        tab._toggle_maximize()

        root.update_idletasks()
        root.update()

        time.sleep(0.25)

        tab._toggle_maximize()

        root.update_idletasks()
        root.update()

        time.sleep(0.25)

        tab.focus_terminal()

        _send_unicode("CI_MAX_RESTORE")
        ssh.wait_for("CI_MAX_RESTORE")

        # --------------------------------------------------------
        # 4. Resize path.
        # --------------------------------------------------------
        root.geometry("900x650")
        root.update_idletasks()
        root.update()
        time.sleep(0.25)

        root.geometry("1200x800")
        root.update_idletasks()
        root.update()
        time.sleep(0.25)

        tab.focus_terminal()

        _send_unicode("CI_RESIZE")
        ssh.wait_for("CI_RESIZE")

    finally:
        try:
            monkeypatch.undo()
        except Exception:
            pass

        if tab is not None:
            try:
                tab.close()
            except Exception:
                pass

        if root is not None:
            try:
                root.destroy()
            except Exception:
                pass

        ssh.stop_server()
