import os

os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")


def test_core_modules_import():
    import main
    import gui
    import device_manager
    import backup_engine
    import report_generator
    import vendors

    assert callable(main.smoke_test)
    assert vendors.active_vendors()


def test_main_smoke_test():
    # The full GUI smoke path is executed on the Windows GitHub runner.
    # Skip it on headless/non-Windows developer environments.
    import os, sys, pytest
    if sys.platform != "win32":
        pytest.skip("Windows GUI smoke test runs in GitHub Actions")
    import main
    main.smoke_test()
