"""
SSH Session Backend
===================

Provides an interactive SSH shell using paramiko's invoke_shell().
Each SSHTerminal instance manages one persistent SSH connection with:
  - A background thread that reads output from the shell channel
  - A queue that the GUI polls to get new output
  - send() for individual keystrokes (interactive terminal)
  - send_command() for full command lines
  - send_config_set() for pushing multiple config commands

Used by the Network Operations window for the multi-tab SSH terminal.
"""

import queue
import threading
import time
from typing import Optional, List


class SSHTerminal:
    """Interactive SSH terminal backed by paramiko invoke_shell()."""

    def __init__(
        self,
        host: str,
        port: int,
        username: str,
        password: str,
        enable_password: str = "",
        device_type: str = "cisco_ios",
        timeout: int = 15,
    ):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.enable_password = enable_password
        self.device_type = device_type
        self.timeout = timeout

        self.client = None
        self.channel = None
        self.output_queue: queue.Queue = queue.Queue()
        self._running = False
        self._reader_thread: Optional[threading.Thread] = None
        self.connected = False
        self.error = ""

    def connect(self) -> bool:
        """Open the SSH connection and start the interactive shell.

        Returns True on success, False on failure (sets self.error).
        """
        try:
            import paramiko
        except ImportError:
            self.error = "paramiko library not installed. Run: pip install paramiko"
            return False

        try:
            self.client = paramiko.SSHClient()
            self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.client.connect(
                hostname=self.host,
                port=self.port,
                username=self.username,
                password=self.password,
                timeout=self.timeout,
                allow_agent=False,
                look_for_keys=False,
            )
            self.channel = self.client.invoke_shell(term="xterm-256color")
            self.channel.settimeout(0.1)  # non-blocking reads

            self.connected = True
            self._running = True
            self._reader_thread = threading.Thread(
                target=self._read_loop, daemon=True
            )
            self._reader_thread.start()

            # Give the shell a moment to produce initial output (banner, prompt)
            time.sleep(0.5)

            # Enter enable mode if an enable password was provided and the
            # device type looks like a Cisco product.
            if self.enable_password and "cisco" in self.device_type:
                self.send_command("enable")
                time.sleep(0.3)
                self.send(self.enable_password + "\n")
                time.sleep(0.3)
                # Send terminal length 0 to disable pagination
                self.send_command("terminal length 0")
                time.sleep(0.2)

            return True

        except Exception as e:
            self.error = str(e)
            self.connected = False
            return False

    def _read_loop(self):
        """Background thread: read from the SSH channel and push to the queue.

        CRITICAL: Decode bytes as they arrive. We use utf-8 with
        errors='replace' to handle partial multi-byte sequences.
        The GUI poll loop handles the display.
        """
        while self._running and self.channel:
            try:
                if self.channel.recv_ready():
                    data = self.channel.recv(4096)
                    if data:
                        text = data.decode("utf-8", errors="replace")
                        self.output_queue.put(text)
                elif self.channel.exit_status_ready():
                    # Channel closed by remote
                    self.output_queue.put("\r\n*** SSH session closed by remote host ***\r\n")
                    self._running = False
                    self.connected = False
                    break
                else:
                    time.sleep(0.02)  # small sleep to avoid busy-waiting
            except Exception:
                self._running = False
                self.connected = False
                break

    def send(self, data: str):
        """Send raw bytes/characters to the SSH shell (for interactive typing).

        CRITICAL FIX: Must encode as UTF-8 bytes, not send as a string.
        paramiko's channel.send() expects bytes. If you pass a string,
        on some Python/paramiko versions it silently corrupts or sends
        wrong bytes — which is why typed characters show as unknown symbols.

        Also: the Tk Text widget's event.char gives us a Unicode string.
        We must convert it to bytes before sending to the SSH channel.
        """
        if self.channel and self.connected:
            try:
                # Convert string to bytes — this is the critical fix
                if isinstance(data, str):
                    self.channel.send(data.encode("utf-8"))
                else:
                    self.channel.send(data)
            except Exception:
                pass

    def send_command(self, command: str):
        """Send a command followed by Enter."""
        self.send(command + "\n")

    def resize(self, cols: int, rows: int, width_px: int = 0, height_px: int = 0):
        """Tell the remote pty the terminal size changed.

        Real PuTTY does this on every window resize so that full-screen
        programs (vim, top, menu-driven CLIs) redraw at the right
        dimensions instead of wrapping/garbling. Without this call the
        remote side keeps assuming its original invoke_shell() size
        (80x24) no matter how big the local window gets.
        """
        if self.channel and self.connected:
            try:
                self.channel.resize_pty(
                    width=max(1, cols), height=max(1, rows),
                    width_pixels=width_px, height_pixels=height_px,
                )
            except Exception:
                pass

    def get_output(self) -> str:
        """Drain all pending output from the queue. Called by the GUI poll loop."""
        chunks = []
        while True:
            try:
                chunks.append(self.output_queue.get_nowait())
            except queue.Empty:
                break
        return "".join(chunks)

    def close(self):
        """Close the SSH session cleanly."""
        self._running = False
        self.connected = False
        if self._reader_thread:
            self._reader_thread.join(timeout=1.0)
        try:
            if self.channel:
                self.channel.close()
        except Exception:
            pass
        try:
            if self.client:
                self.client.close()
        except Exception:
            pass
        self.channel = None
        self.client = None


class ConfigPushResult:
    """Result of pushing config commands to a single device."""

    def __init__(
        self,
        device_id: str,
        hostname: str,
        ip_address: str,
        success: bool,
        output: str = "",
        error: str = "",
        commands_pushed: List[str] = None,
        timestamp: str = "",
    ):
        self.device_id = device_id
        self.hostname = hostname
        self.ip_address = ip_address
        self.success = success
        self.output = output
        self.error = error
        self.commands_pushed = commands_pushed or []
        self.timestamp = timestamp or time.strftime("%Y-%m-%d %H:%M:%S")

    def to_dict(self):
        return {
            "device_id": self.device_id,
            "hostname": self.hostname,
            "ip_address": self.ip_address,
            "success": self.success,
            "output": self.output[:2000],  # truncate for storage
            "error": self.error,
            "commands_pushed": self.commands_pushed,
            "timestamp": self.timestamp,
        }


class ConfigPusher:
    """Pushes configuration commands to network devices via netmiko."""

    def __init__(self):
        pass

    def push_config(
        self,
        device: dict,
        commands: List[str],
        credentials: dict,
    ) -> ConfigPushResult:
        """Push config commands to a single device.

        Args:
            device: device dict with hostname, ip_address, vendor, port
            commands: list of config-mode commands (e.g. ["vlan 100", "name DATA"])
            credentials: dict with username, password, enable_password

        Returns:
            ConfigPushResult with success/failure and output
        """
        import time as _time
        timestamp = _time.strftime("%Y-%m-%d %H:%M:%S")

        hostname = device.get("hostname", "?")
        ip = device.get("ip_address", "?")
        device_id = device.get("id", "?")
        vendor_key = device.get("vendor", "cisco_ios")
        port = device.get("port", 22)

        username = credentials.get("username", "")
        password = credentials.get("password", "")
        enable_password = credentials.get("enable_password", "")

        if not username or not password:
            return ConfigPushResult(
                device_id=device_id, hostname=hostname, ip_address=ip,
                success=False, error="No credentials available for this device.",
                commands_pushed=commands, timestamp=timestamp,
            )

        if not commands:
            return ConfigPushResult(
                device_id=device_id, hostname=hostname, ip_address=ip,
                success=False, error="No commands to push.",
                commands_pushed=[], timestamp=timestamp,
            )

        try:
            from netmiko import ConnectHandler
        except ImportError:
            return ConfigPushResult(
                device_id=device_id, hostname=hostname, ip_address=ip,
                success=False, error="netmiko library not installed. Run: pip install netmiko",
                commands_pushed=commands, timestamp=timestamp,
            )

        # Determine netmiko device_type
        # For firewalls, vendor_key is the firewall vendor key (fortigate, checkpoint, etc.)
        # For routers/switches, vendor_key IS the netmiko device_type
        from vendors import get_vendor
        fw_vendor = get_vendor(vendor_key)
        if fw_vendor:
            netmiko_type = fw_vendor.netmiko_type
        else:
            netmiko_type = vendor_key

        device_params = {
            "device_type": netmiko_type,
            "host": ip,
            "port": port,
            "username": username,
            "password": password,
            "timeout": 30,
            "conn_timeout": 15,
        }
        if enable_password and "cisco" in netmiko_type:
            device_params["secret"] = enable_password

        try:
            connection = ConnectHandler(**device_params)
            try:
                # Enter enable mode if needed
                if enable_password and "cisco" in netmiko_type:
                    try:
                        connection.enable()
                    except Exception:
                        pass

                # Send the config commands
                output = connection.send_config_set(commands, read_timeout=60)

                # Save config for Cisco devices
                if "cisco" in netmiko_type:
                    try:
                        connection.save()
                    except Exception:
                        pass

                return ConfigPushResult(
                    device_id=device_id, hostname=hostname, ip_address=ip,
                    success=True, output=output,
                    commands_pushed=commands, timestamp=timestamp,
                )
            finally:
                try:
                    connection.disconnect()
                except Exception:
                    pass

        except Exception as e:
            error_msg = str(e)
            if "Authentication" in error_msg:
                error_msg = f"Authentication failed for {username}@{ip}"
            elif "timed out" in error_msg.lower():
                error_msg = f"SSH connection timed out to {ip}:{port}"
            return ConfigPushResult(
                device_id=device_id, hostname=hostname, ip_address=ip,
                success=False, error=error_msg,
                commands_pushed=commands, timestamp=timestamp,
            )

    def fetch_running_config(
        self,
        device: dict,
        credentials: dict,
    ) -> str:
        """Fetch the running-config from a device. Returns the config text
        or raises an exception on failure."""
        from netmiko import ConnectHandler
        from vendors import get_vendor

        ip = device.get("ip_address", "?")
        port = device.get("port", 22)
        vendor_key = device.get("vendor", "cisco_ios")
        username = credentials.get("username", "")
        password = credentials.get("password", "")
        enable_password = credentials.get("enable_password", "")

        fw_vendor = get_vendor(vendor_key)
        netmiko_type = fw_vendor.netmiko_type if fw_vendor else vendor_key

        # Determine the backup command based on device type
        from vendor_templates import get_template
        template = get_template(vendor_key)
        if template and template.backup_commands:
            backup_cmd = template.backup_commands[0]
        elif "cisco" in netmiko_type:
            backup_cmd = "show running-config"
        elif "junos" in netmiko_type:
            backup_cmd = "show configuration | display set"
        elif "huawei" in netmiko_type:
            backup_cmd = "display current-configuration"
        else:
            backup_cmd = "show running-config"

        device_params = {
            "device_type": netmiko_type,
            "host": ip,
            "port": port,
            "username": username,
            "password": password,
            "timeout": 30,
            "conn_timeout": 15,
        }
        if enable_password and "cisco" in netmiko_type:
            device_params["secret"] = enable_password

        connection = ConnectHandler(**device_params)
        try:
            if enable_password and "cisco" in netmiko_type:
                try:
                    connection.enable()
                except Exception:
                    pass
            output = connection.send_command(backup_cmd, read_timeout=60)
            return output
        finally:
            try:
                connection.disconnect()
            except Exception:
                pass

    def run_diagnostic(
        self,
        device: dict,
        credentials: dict,
        command: str,
    ) -> str:
        """Run a single show command on a device and return the output."""
        from netmiko import ConnectHandler
        from vendors import get_vendor

        ip = device.get("ip_address", "?")
        port = device.get("port", 22)
        vendor_key = device.get("vendor", "cisco_ios")
        username = credentials.get("username", "")
        password = credentials.get("password", "")
        enable_password = credentials.get("enable_password", "")

        fw_vendor = get_vendor(vendor_key)
        netmiko_type = fw_vendor.netmiko_type if fw_vendor else vendor_key

        device_params = {
            "device_type": netmiko_type,
            "host": ip,
            "port": port,
            "username": username,
            "password": password,
            "timeout": 30,
            "conn_timeout": 15,
        }
        if enable_password and "cisco" in netmiko_type:
            device_params["secret"] = enable_password

        connection = ConnectHandler(**device_params)
        try:
            if enable_password and "cisco" in netmiko_type:
                try:
                    connection.enable()
                except Exception:
                    pass
            output = connection.send_command(command, read_timeout=30)
            return output
        finally:
            try:
                connection.disconnect()
            except Exception:
                pass
