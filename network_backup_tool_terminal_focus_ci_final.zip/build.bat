@echo off
setlocal
REM Network Backup Tool - Windows PyInstaller build

echo Building Network Backup Tool executable...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install pyinstaller

python -m PyInstaller --noconfirm --clean NetworkBackupTool.spec

if errorlevel 1 (
    echo Build FAILED.
    exit /b 1
)

echo Build complete: dist\NetworkBackupTool.exe
endlocal
