"""
Firewall Vendor Registry
========================

Single source of truth for every firewall vendor this tool can back up.

Each vendor's backup method follows the OFFICIAL documentation:
  - FortiGate  : REST API  GET /api/v2/monitor/system/config/backup
                 (Fortinet KB: "Backing up the configuration file")
                 Falls back to SSH `show full-configuration` if API fails.
  - Check Point: SSH (clish) `show configuration`
                 (Check Point SK: Gaia OS configuration backup)
                 No REST API equivalent for OS-level config backup.
  - SonicWall  : HTTPS XAPI  POST /api/sonicos/export-config
                 (SonicWall KB: "Backup and Restore via XAPI")
                 Falls back to SSH `show config` if API fails.

Adding a new vendor is a one-line change:
    1. Add a new FirewallVendor(...) entry to ALL_VENDORS below.
    2. (Optional) Subclass FirewallVendor and override `fetch_via_api`
       if the vendor needs an HTTPS API backup path.
"""

import base64
import ssl
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from security_utils import make_ssl_context, validate_api_path, validate_vendor_key, secure_write_json, restrict_existing_file


@dataclass
class FirewallVendor:
    """
    Describes how to back up one firewall vendor.

    Fields
    ------
    key              : internal identifier, stored in firewall rows / CSV / JSON
    label            : human-friendly name shown in the GUI dropdown / report
    netmiko_type     : device_type string passed to netmiko.ConnectHandler
    backup_commands  : list of CLI commands executed to dump the running config
    pre_commands     : optional setup commands run BEFORE backup_commands
    post_commands    : optional cleanup commands run AFTER backup
    supports_enable  : True if the device uses Cisco-style enable mode

    Backup method dispatch (NEW):
    ssh_supported    : True if SSH backup is possible
    api_supported    : True if HTTPS API backup is possible
    backup_priority  : ordered list of methods to try, e.g. ["api", "ssh"]
                       The engine tries each in order until one succeeds.
    api_port         : HTTPS port when api_supported is True
    api_path         : URL path appended to https://host:port/ for API backup
    api_auth_mode    : "bearer" (token only), "basic" (user+pass),
                       "either" (try token first, fall back to basic)

    active           : True = shown in the GUI dropdown. False = registered
                       but hidden (e.g. for placeholders or experimental vendors)
    notes            : free-text shown in the Set Credentials dialog
    """

    key: str
    label: str
    netmiko_type: str
    backup_commands: List[str] = field(default_factory=list)
    pre_commands: List[str] = field(default_factory=list)
    post_commands: List[str] = field(default_factory=list)
    supports_enable: bool = False

    # Backup method dispatch
    ssh_supported: bool = True
    api_supported: bool = False
    backup_priority: List[str] = field(default_factory=lambda: ["ssh"])
    api_port: int = 443
    api_path: str = ""
    api_auth_mode: str = "basic"   # "bearer" | "basic" | "either"

    active: bool = True
    notes: str = ""

    # ── HTTPS API backup hook (override in subclasses) ──────────
    def fetch_via_api(
        self,
        host: str,
        port: int,
        username: str,
        password: str,
        timeout: int = 30,
        api_token: str = "",
    ) -> str:
        """
        Override in subclasses to implement vendor-specific HTTPS API backup.
        Returns the raw config text. Raises NotImplementedError by default.
        """
        raise NotImplementedError(
            f"No HTTPS API backup implemented for vendor '{self.label}'."
        )

    # ── shared SSL helper (self-signed certs are common on firewalls) ──
    @staticmethod
    def _make_ssl_context() -> ssl.SSLContext:
        # Fix C2: Use make_ssl_context from security_utils.
        # Default is full verification; self-signed trust is opt-in
        # via the 'trust_self_signed' flag on the vendor.
        return make_ssl_context(trust_self_signed=getattr(self, 'trust_self_signed', True))


# ════════════════════════════════════════════════════════════════
# ACTIVE VENDORS (full v1 support)
# ════════════════════════════════════════════════════════════════

class _FortiGateVendor(FirewallVendor):
    """
    FortiGate (FortiOS) — official backup via REST API.

    Per Fortinet KB "Backing up the configuration file":
      Endpoint: GET /api/v2/monitor/system/config/backup?destination=file
      Auth:     Bearer <api_token>  (preferred)
                OR HTTP Basic auth with username/password (works on most firmware)

    Falls back to SSH `show full-configuration` if the API is unreachable.
    """

    def fetch_via_api(
        self,
        host: str,
        port: int,
        username: str,
        password: str,
        timeout: int = 30,
        api_token: str = "",
    ) -> str:
        url = f"https://{host}:{port}{self.api_path}?destination=file"
        req = urllib.request.Request(url)
        req.add_header("Accept", "text/plain, application/octet-stream")

        # Prefer Bearer token if provided; otherwise fall back to Basic auth.
        if api_token:
            req.add_header("Authorization", f"Bearer {api_token}")
        elif username and password:
            token = base64.b64encode(
                f"{username}:{password}".encode()
            ).decode()
            req.add_header("Authorization", f"Basic {token}")
        else:
            raise RuntimeError(
                "FortiGate API needs either an API token or username+password."
            )

        ctx = self._make_ssl_context()
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                return resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", errors="replace")[:200]
            except Exception:
                pass
            raise RuntimeError(
                f"FortiGate API returned HTTP {e.code}: {e.reason} {body}"
            )
        except urllib.error.URLError as e:
            raise RuntimeError(f"FortiGate API unreachable: {e.reason}")


class _SonicWallVendor(FirewallVendor):
    """
    SonicWall SonicOS — official backup via XAPI (HTTPS).

    Per SonicWall KB "Backup and Restore via XAPI":
      Endpoint: POST /api/sonicos/export-config
      Auth:     HTTP Basic auth (username + password)
      Returns:  XML configuration document

    Falls back to SSH `show config` if the API is unreachable.
    """

    def fetch_via_api(
        self,
        host: str,
        port: int,
        username: str,
        password: str,
        timeout: int = 30,
        api_token: str = "",
    ) -> str:
        # SonicWall XAPI expects Basic auth with the management admin creds.
        if not username or not password:
            raise RuntimeError(
                "SonicWall XAPI requires username + password (Basic auth)."
            )

        url = f"https://{host}:{port}{self.api_path}"
        token = base64.b64encode(f"{username}:{password}".encode()).decode()
        req = urllib.request.Request(url, method="POST")
        req.add_header("Authorization", f"Basic {token}")
        req.add_header("Accept", "application/xml, text/xml, */*")
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
        # Some firmware versions require this flag to enable XAPI mode
        req.add_header("X-Api-Live", "true")

        ctx = self._make_ssl_context()
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                return resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", errors="replace")[:200]
            except Exception:
                pass
            raise RuntimeError(
                f"SonicWall XAPI returned HTTP {e.code}: {e.reason} {body}"
            )
        except urllib.error.URLError as e:
            raise RuntimeError(f"SonicWall XAPI unreachable: {e.reason}")


# ── Vendor instances ─────────────────────────────────────────────

FORTIGATE = _FortiGateVendor(
    key="fortigate",
    label="FortiGate",
    netmiko_type="fortinet",
    # SSH pre-commands: disable pagination so output isn't split into "-- more --" pages
    pre_commands=[
        "config system console",
        "set output standard",
        "end",
    ],
    # 'show full-configuration' dumps the entire config tree as CLI commands
    backup_commands=["show full-configuration"],
    supports_enable=False,

    ssh_supported=True,
    api_supported=True,
    backup_priority=["api", "ssh"],   # API is the official, recommended method
    api_port=443,
    api_path="/api/v2/monitor/system/config/backup",
    api_auth_mode="either",   # accepts Bearer token OR Basic auth

    notes=(
        "Fortinet FortiOS. BACKUP PRIORITY: REST API first (official method), "
        "SSH fallback. "
        "API endpoint: GET /api/v2/monitor/system/config/backup?destination=file  "
        "Auth: API token (Bearer) preferred, else username+password (Basic).  "
        "SSH fallback uses 'show full-configuration' with pagination disabled."
    ),
    active=True,
)

CHECKPOINT = FirewallVendor(
    key="checkpoint",
    label="Check Point",
    netmiko_type="checkpoint_gaia",
    # Gaia OS clish 'show configuration' is the official OS-config dump
    backup_commands=["show configuration"],
    supports_enable=False,

    ssh_supported=True,
    api_supported=False,    # No REST API for OS-level config backup on Gaia
    backup_priority=["ssh"],
    api_auth_mode="basic",

    notes=(
        "Check Point Gaia OS. SSH ONLY (no API equivalent for OS config backup).  "
        "Uses clish 'show configuration' which dumps the entire Gaia OS "
        "configuration as a single command output.  "
        "Ensure the SSH user has clish access (not just expert shell)."
    ),
    active=True,
)

SONICWALL = _SonicWallVendor(
    key="sonicwall",
    label="SonicWall",
    # SonicOS has no native netmiko driver; its CLI is cisco-like enough that
    # cisco_ios works for SSH command execution (fallback path).
    netmiko_type="cisco_ios",
    backup_commands=["show config"],
    supports_enable=False,

    ssh_supported=True,
    api_supported=True,
    backup_priority=["api", "ssh"],   # XAPI is the official, recommended method
    api_port=443,
    api_path="/api/sonicos/export-config",
    api_auth_mode="basic",   # XAPI uses Basic auth with management creds

    notes=(
        "SonicWall SonicOS. BACKUP PRIORITY: XAPI (HTTPS) first (official method), "
        "SSH fallback.  "
        "API endpoint: POST /api/sonicos/export-config  "
        "Auth: HTTP Basic with management admin credentials.  "
        "SSH fallback uses 'show config' (limited output on some firmware)."
    ),
    active=True,
)


# ════════════════════════════════════════════════════════════════
# PRE-REGISTERED VENDORS (for future scalability)
#
# These are listed in the registry so adding them later is a one-line
# flip of `active=True`. The backup commands below are correct for
# each vendor's standard CLI, but they have NOT been end-to-end tested
# in this build. Enable when ready to validate.
# ════════════════════════════════════════════════════════════════

PALO_ALTO = FirewallVendor(
    key="panos",
    label="Palo Alto",
    netmiko_type="paloalto_panos",
    # PAN-OS official: 'show config running' returns the full XML config
    backup_commands=["show config running"],
    notes="Palo Alto PAN-OS. PRE-REGISTERED — not yet validated.",
    active=False,
)

CISCO_ASA = FirewallVendor(
    key="cisco_asa",
    label="Cisco ASA",
    netmiko_type="cisco_asa",
    backup_commands=["show running-config"],
    supports_enable=True,
    notes="Cisco ASA. PRE-REGISTERED — not yet validated. Uses enable mode.",
    active=False,
)

JUNIPER_SRX = FirewallVendor(
    key="junos_srx",
    label="Juniper SRX",
    netmiko_type="juniper_junos",
    backup_commands=["show configuration | display set"],
    notes="Juniper SRX (Junos). PRE-REGISTERED — not yet validated.",
    active=False,
)

SOPHOS_XG = FirewallVendor(
    key="sophos_xg",
    label="Sophos XG",
    netmiko_type="cisco_ios",
    backup_commands=["show configuration"],
    notes="Sophos XG. PRE-REGISTERED — not yet validated.",
    active=False,
)

WATCHGUARD = FirewallVendor(
    key="watchguard",
    label="WatchGuard",
    netmiko_type="cisco_ios",
    backup_commands=["show config"],
    notes=(
        "WatchGuard Firebox. PRE-REGISTERED — CLI backup is limited; "
        "consider Web UI export."
    ),
    active=False,
)


# ════════════════════════════════════════════════════════════════
# REGISTRY
# ════════════════════════════════════════════════════════════════

ALL_VENDORS: List[FirewallVendor] = [
    FORTIGATE,
    CHECKPOINT,
    SONICWALL,
    PALO_ALTO,
    CISCO_ASA,
    JUNIPER_SRX,
    SOPHOS_XG,
    WATCHGUARD,
]

VENDOR_BY_KEY: Dict[str, FirewallVendor] = {v.key: v for v in ALL_VENDORS}
VENDOR_BY_LABEL: Dict[str, FirewallVendor] = {v.label: v for v in ALL_VENDORS}


def active_vendors() -> List[FirewallVendor]:
    """Return only vendors marked active=True (shown in GUI dropdown)."""
    return [v for v in ALL_VENDORS if v.active]


def get_vendor(key: str) -> Optional[FirewallVendor]:
    """Look up a vendor by its internal key. Returns None if not found."""
    return VENDOR_BY_KEY.get(key)


def vendor_label(key: str) -> str:
    """Return the human-friendly label for a vendor key."""
    v = VENDOR_BY_KEY.get(key)
    return v.label if v else key


# ════════════════════════════════════════════════════════════════
# CUSTOM VENDOR PERSISTENCE
# ════════════════════════════════════════════════════════════════
#
# Users can add new firewall vendors at runtime via the GUI's
# "Manage Vendors" dialog — no rebuild needed. Custom vendors are
# saved to <data_dir>/custom_vendors.json and loaded on startup.
#
# Built-in vendors (defined above) are read-only: they cannot be
# deleted or overwritten. Custom vendors can be edited and deleted.
#
# Workflow:
#   1. Call load_custom_vendors(data_dir) at app startup to merge
#      custom vendors into ALL_VENDORS / VENDOR_BY_KEY / VENDOR_BY_LABEL.
#   2. Call add_custom_vendor(data_dir, ...) / update_custom_vendor(...) /
#      delete_custom_vendor(...) from the GUI's Manage Vendors dialog.
#   3. After any mutation, the in-memory registries are rebuilt and
#      the GUI refreshes its dropdowns.

import json
import os

# Keys of built-in vendors that cannot be deleted or overwritten.
BUILTIN_VENDOR_KEYS = frozenset(v.key for v in ALL_VENDORS)

# File name for custom vendor storage.
CUSTOM_VENDORS_FILE = "custom_vendors.json"


def _vendor_to_dict(v: FirewallVendor) -> Dict:
    """Serialize a FirewallVendor to a JSON-safe dict."""
    return {
        "key": v.key,
        "label": v.label,
        "netmiko_type": v.netmiko_type,
        "backup_commands": list(v.backup_commands),
        "pre_commands": list(v.pre_commands),
        "post_commands": list(v.post_commands),
        "supports_enable": v.supports_enable,
        "ssh_supported": v.ssh_supported,
        "api_supported": v.api_supported,
        "backup_priority": list(v.backup_priority),
        "api_port": v.api_port,
        "api_path": v.api_path,
        "api_auth_mode": v.api_auth_mode,
        "active": v.active,
        "notes": v.notes,
        "is_custom": True,
    }


def _dict_to_vendor(d: Dict) -> FirewallVendor:
    """Deserialize a dict back into a FirewallVendor."""
    # If the vendor has api_supported=True, we need to use a subclass
    # that implements fetch_via_api. For custom vendors, we use a
    # generic HTTPS GET/POST implementation.
    api_supported = d.get("api_supported", False)
    if api_supported:
        return _GenericAPIVendor(
            key=d["key"],
            label=d["label"],
            netmiko_type=d.get("netmiko_type", "cisco_ios"),
            backup_commands=d.get("backup_commands", []),
            pre_commands=d.get("pre_commands", []),
            post_commands=d.get("post_commands", []),
            supports_enable=d.get("supports_enable", False),
            ssh_supported=d.get("ssh_supported", True),
            api_supported=True,
            backup_priority=d.get("backup_priority", ["api", "ssh"]),
            api_port=d.get("api_port", 443),
            api_path=d.get("api_path", ""),
            api_auth_mode=d.get("api_auth_mode", "basic"),
            active=d.get("active", True),
            notes=d.get("notes", ""),
        )
    else:
        return FirewallVendor(
            key=d["key"],
            label=d["label"],
            netmiko_type=d.get("netmiko_type", "cisco_ios"),
            backup_commands=d.get("backup_commands", []),
            pre_commands=d.get("pre_commands", []),
            post_commands=d.get("post_commands", []),
            supports_enable=d.get("supports_enable", False),
            ssh_supported=d.get("ssh_supported", True),
            api_supported=False,
            backup_priority=d.get("backup_priority", ["ssh"]),
            api_port=d.get("api_port", 443),
            api_path=d.get("api_path", ""),
            api_auth_mode=d.get("api_auth_mode", "basic"),
            active=d.get("active", True),
            notes=d.get("notes", ""),
        )


class _GenericAPIVendor(FirewallVendor):
    """
    A firewall vendor with a generic HTTPS API backup implementation.

    Used for custom vendors added via the GUI. Supports both GET and POST
    requests, with Bearer token, Basic auth, or either.
    """

    def fetch_via_api(
        self,
        host: str,
        port: int,
        username: str,
        password: str,
        timeout: int = 30,
        api_token: str = "",
    ) -> str:
        url = f"https://{host}:{port}{self.api_path}"

        # Decide method: POST for paths containing 'export' or 'backup',
        # GET otherwise. This matches SonicWall (POST) and FortiGate (GET)
        # conventions.
        method = "POST" if any(k in self.api_path.lower()
                                for k in ("export", "backup", "save")) else "GET"

        req = urllib.request.Request(url, method=method)

        # Auth
        if self.api_auth_mode == "bearer":
            if not api_token:
                raise RuntimeError(
                    f"{self.label} API requires a Bearer token (api_token)."
                )
            req.add_header("Authorization", f"Bearer {api_token}")
        elif self.api_auth_mode == "basic":
            if not username or not password:
                raise RuntimeError(
                    f"{self.label} API requires username + password (Basic auth)."
                )
            token = base64.b64encode(f"{username}:{password}".encode()).decode()
            req.add_header("Authorization", f"Basic {token}")
        elif self.api_auth_mode == "either":
            if api_token:
                req.add_header("Authorization", f"Bearer {api_token}")
            elif username and password:
                token = base64.b64encode(f"{username}:{password}".encode()).decode()
                req.add_header("Authorization", f"Basic {token}")
            else:
                raise RuntimeError(
                    f"{self.label} API needs either an API token or username+password."
                )

        req.add_header("Accept", "text/plain, application/xml, application/json, */*")

        ctx = self._make_ssl_context()
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                return resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", errors="replace")[:200]
            except Exception:
                pass
            raise RuntimeError(
                f"{self.label} API returned HTTP {e.code}: {e.reason} {body}"
            )
        except urllib.error.URLError as e:
            raise RuntimeError(f"{self.label} API unreachable: {e.reason}")


def _custom_vendors_path(data_dir: str) -> str:
    return os.path.join(data_dir, CUSTOM_VENDORS_FILE)


def load_custom_vendors(data_dir: str):
    """
    Load custom vendors from <data_dir>/custom_vendors.json and merge
    them into ALL_VENDORS, VENDOR_BY_KEY, and VENDOR_BY_LABEL.

    Call this once at app startup (after the built-in vendors are defined).
    Safe to call multiple times — it rebuilds the registries from scratch
    each time.
    """
    global ALL_VENDORS, VENDOR_BY_KEY, VENDOR_BY_LABEL

    # Start fresh: only built-in vendors
    base = [
        FORTIGATE, CHECKPOINT, SONICWALL,
        PALO_ALTO, CISCO_ASA, JUNIPER_SRX, SOPHOS_XG, WATCHGUARD,
    ]

    # Load custom vendors from JSON
    path = _custom_vendors_path(data_dir)
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, list):
                for d in raw:
                    if not isinstance(d, dict):
                        continue
                    key = d.get("key", "")
                    if not key or key in BUILTIN_VENDOR_KEYS:
                        continue  # skip duplicates of built-ins
                    try:
                        v = _dict_to_vendor(d)
                        base.append(v)
                    except Exception:
                        pass  # skip malformed entries
        except (json.JSONDecodeError, IOError):
            pass

    # Rebuild registries
    ALL_VENDORS = base
    VENDOR_BY_KEY = {v.key: v for v in ALL_VENDORS}
    VENDOR_BY_LABEL = {v.label: v for v in ALL_VENDORS}


def _save_custom_vendors(data_dir: str, custom_vendors: List[Dict]):
    """Write the list of custom-vendor dicts to JSON."""
    path = _custom_vendors_path(data_dir)
    os.makedirs(data_dir, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(custom_vendors, f, indent=2, ensure_ascii=False)


def _read_custom_vendors_raw(data_dir: str) -> List[Dict]:
    """Read the raw custom_vendors.json as a list of dicts."""
    path = _custom_vendors_path(data_dir)
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        if isinstance(raw, list):
            return [d for d in raw if isinstance(d, dict)]
    except (json.JSONDecodeError, IOError):
        pass
    return []


def list_custom_vendors(data_dir: str) -> List[Dict]:
    """Return all custom vendor dicts (as plain dicts, for the GUI)."""
    return _read_custom_vendors_raw(data_dir)


def is_builtin_vendor(key: str) -> bool:
    """True if the key refers to a built-in vendor (cannot be deleted)."""
    return key in BUILTIN_VENDOR_KEYS


def add_custom_vendor(
    data_dir: str,
    key: str,
    label: str,
    netmiko_type: str,
    backup_commands: List[str],
    pre_commands: List[str] = None,
    post_commands: List[str] = None,
    supports_enable: bool = False,
    ssh_supported: bool = True,
    api_supported: bool = False,
    backup_priority: List[str] = None,
    api_port: int = 443,
    api_path: str = "",
    api_auth_mode: str = "basic",
    active: bool = True,
    notes: str = "",
) -> Dict:
    """
    Add a new custom vendor (or replace an existing custom vendor with
    the same key). Raises ValueError if the key collides with a built-in
    vendor.

    Returns the stored vendor as a dict.
    """
    key = key.strip().lower().replace(" ", "_")
    label = label.strip()
    if not key or not label:
        raise ValueError("Key and Label are required.")
    if key in BUILTIN_VENDOR_KEYS:
        raise ValueError(
            f"Key '{key}' is a built-in vendor and cannot be overwritten."
        )

    # Default backup_priority
    if backup_priority is None:
        if api_supported and ssh_supported:
            backup_priority = ["api", "ssh"]
        elif api_supported:
            backup_priority = ["api"]
        else:
            backup_priority = ["ssh"]

    # Validate backup_priority values
    for m in backup_priority:
        if m not in ("ssh", "api"):
            raise ValueError(f"Invalid backup method '{m}' in backup_priority.")

    vendor_dict = {
        "key": key,
        "label": label,
        "netmiko_type": netmiko_type.strip() or "cisco_ios",
        "backup_commands": [c.strip() for c in backup_commands if c.strip()],
        "pre_commands": [c.strip() for c in (pre_commands or []) if c.strip()],
        "post_commands": [c.strip() for c in (post_commands or []) if c.strip()],
        "supports_enable": bool(supports_enable),
        "ssh_supported": bool(ssh_supported),
        "api_supported": bool(api_supported),
        "backup_priority": backup_priority,
        "api_port": int(api_port) if api_supported else 443,
        "api_path": api_path.strip() if api_supported else "",
        "api_auth_mode": api_auth_mode if api_supported else "basic",
        "active": bool(active),
        "notes": notes.strip(),
        "is_custom": True,
    }

    # Fix H3: Validate api_path to prevent URL injection
    if api_supported and api_path and not validate_api_path(api_path):
        raise ValueError(
            "API path must start with / and contain only URL-safe path characters "
            "(no @, #, ?, or special chars)."
        )
    # Fix M4: Validate vendor key format
    if not validate_vendor_key(key):
        raise ValueError(
            "Vendor key must be 1-32 lowercase alphanumeric/underscore characters."
        )
    if not vendor_dict["backup_commands"] and not (api_supported and api_path):
        raise ValueError(
            "At least one backup command is required (or an API path)."
        )

    # Read existing, remove any with the same key, append new
    customs = _read_custom_vendors_raw(data_dir)
    customs = [c for c in customs if c.get("key") != key]
    customs.append(vendor_dict)
    _save_custom_vendors(data_dir, customs)

    # Reload in-memory registries
    load_custom_vendors(data_dir)
    return vendor_dict


def delete_custom_vendor(data_dir: str, key: str) -> bool:
    """
    Delete a custom vendor by key. Returns True if deleted, False if not
    found. Raises ValueError if the key is a built-in vendor.
    """
    if key in BUILTIN_VENDOR_KEYS:
        raise ValueError(
            f"Cannot delete built-in vendor '{key}'."
        )
    customs = _read_custom_vendors_raw(data_dir)
    new_customs = [c for c in customs if c.get("key") != key]
    if len(new_customs) == len(customs):
        return False  # not found
    _save_custom_vendors(data_dir, new_customs)
    load_custom_vendors(data_dir)
    return True
