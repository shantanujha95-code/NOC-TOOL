"""
        if y < 30:
            y = 30
Network Backup Tool - Main GUI Application
==========================================

Unified tkinter-based interface for backing up:
  - Routers      (SSH backup, shared SSH credentials)
  - Switches     (SSH backup, shared SSH credentials)
  - Firewalls    (vendor-specific: FortiGate API, SonicWall XAPI, Check Point SSH,
                 with API-first / SSH-fallback dispatch and per-vendor credentials)

Features:
  - Checkbox multi-select for batch operations
  - Two credential dialogs:
      * Set SSH Credentials (shared, for Router/Switch)
      * Set Firewall Credentials (per-vendor tabs, for Firewall)
  - Config diff viewer (compare latest vs previous backup)
  - IP-based backup filenames: backups/{Location}/{Type}/{ip}_{ts}.txt
"""

import os
import sys
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
from typing import List, Dict, Optional

from device_manager import DeviceManager
from backup_engine import UnifiedBackupEngine, BackupResult
from report_generator import UnifiedReportGenerator
from vendors import (
    active_vendors, get_vendor, vendor_label as fw_vendor_label,
    VENDOR_BY_LABEL as FW_VENDOR_BY_LABEL,
    load_custom_vendors, list_custom_vendors, add_custom_vendor,
    delete_custom_vendor, is_builtin_vendor,
)


# ── UI constants ────────────────────────────────────────────────
CHECK_OFF = "\u2610"   # ☐  empty checkbox
CHECK_ON  = "\u2612"   # ☒  checked checkbox

# Router/Switch vendor dropdown (netmiko device types)
ROUTER_SWITCH_VENDORS = [
    ("Cisco IOS",         "cisco_ios"),
    ("Cisco IOS-XE",      "cisco_xe"),
    ("Cisco IOS-XR",      "cisco_xr"),
    ("Cisco NX-OS",       "cisco_nxos"),
    ("Juniper JunOS",     "juniper_junos"),
    ("Huawei VRP",        "huawei"),
    ("Huawei VRPv8",      "huawei_vrpv8"),
    ("Arista EOS",        "arista_eos"),
    ("MikroTik RouterOS", "mikrotik_routeros"),
    ("HP Comware",        "hp_comware"),
    ("Ruckus FastIron",   "ruckus_fastiron"),
    ("Extreme EXOS",      "extreme_exos"),
    ("Dell OS6",          "dell_os6"),
    ("Dell OS10",         "dell_os10"),
]
RS_VENDOR_NAME_TO_KEY = {name: key for name, key in ROUTER_SWITCH_VENDORS}
RS_VENDOR_KEY_TO_NAME = {key: name for name, key in ROUTER_SWITCH_VENDORS}

DEVICE_TYPE_CHOICES = ["Router", "Switch", "Firewall"]

COLORS = {
    "bg_dark":       "#1a3a5f",
    "bg_medium":     "#29629b",
    "bg_light":      "#dce8f5",
    "bg_white":      "#ffffff",
    "text_dark":     "#1a3a5f",
    "text_light":    "#ffffff",
    "text_gray":     "#666666",
    "success":       "#228b22",
    "fail":          "#c82828",
    "warning":       "#d27814",
    "row_alt":       "#f0f5fa",
    "btn_primary":   "#29629b",
    "btn_danger":    "#c82828",
    "btn_success":   "#228b22",
    "btn_warning":   "#d27814",
}


# ════════════════════════════════════════════════════════════════
# ADD DEVICE DIALOG
# ════════════════════════════════════════════════════════════════

class AddDeviceDialog(tk.Toplevel):
    """Dialog window for adding / editing a device (Router/Switch/Firewall)."""

    def __init__(self, parent, existing_locations: List[str] = None, edit_device: Dict = None):
        super().__init__(parent)
        self.result = None
        self.existing_locations = existing_locations or []

        self.title("Edit Device" if edit_device else "Add New Device")
        self.configure(bg=COLORS["bg_white"])
        self.resizable(True, True)
        self.transient(parent)
        self.grab_set()

        self.geometry("480x560")
        self.minsize(480, 480)
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - 480) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 560) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        self._build_ui(edit_device)
        self.protocol("WM_DELETE_WINDOW", self._on_cancel)

        if edit_device:
            self._populate(edit_device)
        else:
            # Show vendor rows appropriate to the default device type
            self._on_device_type_change()

    def _build_ui(self, edit_device):
        pad = {"padx": 15, "pady": 4}

        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header, text="Edit Device" if edit_device else "Add New Device",
            bg=COLORS["bg_dark"], fg=COLORS["text_light"],
            font=("Segoe UI", 14, "bold"),
        ).pack(expand=True)

        form = tk.Frame(self, bg=COLORS["bg_white"])
        form.pack(fill="both", expand=True, padx=20, pady=15)

        # Hostname
        tk.Label(form, text="Hostname *", bg=COLORS["bg_white"], font=("Segoe UI", 10)).grid(
            row=0, column=0, sticky="w", **pad
        )
        self.hostname_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.hostname_var, width=28).grid(
            row=0, column=1, columnspan=2, sticky="ew", **pad
        )

        # IP Address
        tk.Label(form, text="IP Address *", bg=COLORS["bg_white"], font=("Segoe UI", 10)).grid(
            row=1, column=0, sticky="w", **pad
        )
        self.ip_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.ip_var, width=28).grid(
            row=1, column=1, columnspan=2, sticky="ew", **pad
        )

        # Device Type
        tk.Label(form, text="Device Type *", bg=COLORS["bg_white"], font=("Segoe UI", 10)).grid(
            row=2, column=0, sticky="w", **pad
        )
        self.type_var = tk.StringVar(value="Router")
        type_combo = ttk.Combobox(
            form, textvariable=self.type_var,
            values=DEVICE_TYPE_CHOICES, state="readonly", width=25,
        )
        type_combo.grid(row=2, column=1, columnspan=2, sticky="ew", **pad)
        type_combo.bind("<<ComboboxSelected>>", lambda e: self._on_device_type_change())

        # Vendor (router/switch dropdown — hidden when device_type=Firewall)
        self.rs_vendor_label = tk.Label(
            form, text="Vendor", bg=COLORS["bg_white"], font=("Segoe UI", 10)
        )
        self.rs_vendor_label.grid(row=3, column=0, sticky="w", **pad)
        self.rs_vendor_var = tk.StringVar(value="Cisco IOS")
        rs_vendor_names = [name for name, _ in ROUTER_SWITCH_VENDORS]
        self.rs_vendor_combo = ttk.Combobox(
            form, textvariable=self.rs_vendor_var,
            values=rs_vendor_names, state="readonly", width=25,
        )
        self.rs_vendor_combo.grid(row=3, column=1, columnspan=2, sticky="ew", **pad)
        self.rs_vendor_combo.bind("<<ComboboxSelected>>", lambda e: self._update_command_preview())

        # Backup command preview (read-only, auto-filled from template)
        self.cmd_preview_label = tk.Label(
            form, text="Backup Command:", bg=COLORS["bg_white"],
            font=("Segoe UI", 9, "bold"),
        )
        self.cmd_preview_label.grid(row=3, column=0, sticky="w", padx=15, pady=(8, 0))
        # Remove it from default position — it will be shown via _on_device_type_change
        self.cmd_preview_label.grid_remove()

        self.cmd_preview_var = tk.StringVar(value="")
        self.cmd_preview_entry = ttk.Entry(
            form, textvariable=self.cmd_preview_var, state="readonly", width=25,
        )
        self.cmd_preview_entry.grid(row=3, column=1, columnspan=2, sticky="ew", padx=15, pady=(8, 0))
        self.cmd_preview_entry.grid_remove()

        # Firewall vendor (separate dropdown — hidden when device_type != Firewall)
        self.fw_vendor_label = tk.Label(
            form, text="Firewall Vendor", bg=COLORS["bg_white"], font=("Segoe UI", 10)
        )
        self.fw_vendor_var = tk.StringVar(value="FortiGate")
        fw_vendor_names = [v.label for v in active_vendors()]
        self.fw_vendor_combo = ttk.Combobox(
            form, textvariable=self.fw_vendor_var,
            values=fw_vendor_names, state="readonly", width=25,
        )

        # Location
        tk.Label(form, text="Location *", bg=COLORS["bg_white"], font=("Segoe UI", 10)).grid(
            row=4, column=0, sticky="w", **pad
        )
        self.location_var = tk.StringVar()
        loc_combo = ttk.Combobox(
            form, textvariable=self.location_var,
            values=self.existing_locations, width=25,
        )
        loc_combo.grid(row=4, column=1, columnspan=2, sticky="ew", **pad)

        # SSH Port
        tk.Label(form, text="SSH Port", bg=COLORS["bg_white"], font=("Segoe UI", 10)).grid(
            row=5, column=0, sticky="w", **pad
        )
        self.port_var = tk.StringVar(value="22")
        ttk.Entry(form, textvariable=self.port_var, width=28).grid(
            row=5, column=1, columnspan=2, sticky="ew", **pad
        )

        # ── Per-device credentials (optional override) ─────────
        # Row 6: checkbox to enable per-device creds
        # Row 7-9: username / password / enable fields (hidden until checked)
        self.use_device_creds_var = tk.BooleanVar(value=False)
        dev_cred_cb = tk.Checkbutton(
            form,
            text="Use device-specific credentials (override shared/per-vendor)",
            variable=self.use_device_creds_var,
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9, "bold"),
            activebackground=COLORS["bg_white"],
            command=self._toggle_device_creds,
        )
        dev_cred_cb.grid(row=6, column=0, columnspan=3, sticky="w", pady=(8, 2), padx=15)

        # Device-specific credential fields (hidden by default)
        self.dev_user_label = tk.Label(form, text="Device Username", bg=COLORS["bg_white"],
                                       font=("Segoe UI", 9))
        self.dev_user_var = tk.StringVar()
        self.dev_user_entry = ttk.Entry(form, textvariable=self.dev_user_var, width=28)

        self.dev_pass_label = tk.Label(form, text="Device Password", bg=COLORS["bg_white"],
                                       font=("Segoe UI", 9))
        self.dev_pass_var = tk.StringVar()
        self.dev_pass_entry = ttk.Entry(form, textvariable=self.dev_pass_var, show="*", width=28)

        self.dev_enable_label = tk.Label(form, text="Device Enable Pwd", bg=COLORS["bg_white"],
                                         font=("Segoe UI", 9))
        self.dev_enable_var = tk.StringVar()
        self.dev_enable_entry = ttk.Entry(form, textvariable=self.dev_enable_var, show="*", width=28)

        # Hint label
        self.dev_cred_hint = tk.Label(
            form,
            text="(for devices with local credentials different from the rest of the fleet)",
            bg=COLORS["bg_white"], fg=COLORS["text_gray"],
            font=("Segoe UI", 8),
        )

        # Initially hidden
        self._toggle_device_creds()

        form.columnconfigure(1, weight=1)

        # Buttons
        btn_frame = tk.Frame(self, bg=COLORS["bg_white"])
        btn_frame.pack(fill="x", padx=20, pady=(0, 15))

        ttk.Button(btn_frame, text="Cancel", command=self._on_cancel, width=12).pack(side="right", padx=(10, 0))
        save_btn = tk.Button(
            btn_frame, text="Save Device",
            command=self._on_save,
            bg=COLORS["btn_primary"], fg="white",
            font=("Segoe UI", 10, "bold"),
            relief="flat", padx=20, pady=4, cursor="hand2",
        )
        save_btn.pack(side="right")

    def _on_device_type_change(self):
        """Show/hide the appropriate vendor dropdown based on device type."""
        dtype = self.type_var.get()
        if dtype == "Firewall":
            # Hide router/switch vendor + command preview, show firewall vendor
            self.rs_vendor_label.grid_remove()
            self.rs_vendor_combo.grid_remove()
            self.cmd_preview_label.grid_remove()
            self.cmd_preview_entry.grid_remove()
            self.fw_vendor_label.grid(row=3, column=0, sticky="w", padx=15, pady=4)
            self.fw_vendor_combo.grid(row=3, column=1, columnspan=2, sticky="ew", padx=15, pady=4)
        else:
            # Hide firewall vendor, show router/switch vendor + command preview
            self.fw_vendor_label.grid_remove()
            self.fw_vendor_combo.grid_remove()
            self.rs_vendor_label.grid(row=3, column=0, sticky="w", padx=15, pady=4)
            self.rs_vendor_combo.grid(row=3, column=1, columnspan=2, sticky="ew", padx=15, pady=4)
            # Show the backup command preview on its own row (row=10, below
            # all the standard fields) to avoid overlapping with the Location
            # label which is on row=4.
            self.cmd_preview_label.grid(row=10, column=0, sticky="w", padx=15, pady=(12, 4))
            self.cmd_preview_entry.grid(row=10, column=1, columnspan=2, sticky="ew", padx=15, pady=(12, 4))
            self._update_command_preview()

    def _update_command_preview(self):
        """Auto-fill the backup command preview based on the selected vendor.

        Looks up the vendor in vendor_templates.py and shows the official
        backup command. For firewalls the preview is hidden (commands are
        managed via the Manage Vendors dialog).
        """
        dtype = self.type_var.get()
        if dtype == "Firewall":
            self.cmd_preview_var.set("")
            return
        vendor_name = self.rs_vendor_var.get()
        vendor_key = RS_VENDOR_NAME_TO_KEY.get(vendor_name, "")
        if not vendor_key:
            self.cmd_preview_var.set("")
            return
        from vendor_templates import get_template
        t = get_template(vendor_key)
        if t and t.backup_commands:
            self.cmd_preview_var.set(t.backup_commands[0])
        else:
            self.cmd_preview_var.set("")

    def _toggle_device_creds(self):
        """Show/hide the per-device credential fields based on the checkbox."""
        if self.use_device_creds_var.get():
            # Show the device-specific credential fields.
            # Each field gets its own row; the hint text goes on a
            # separate row below Enable Password to avoid overlapping
            # with the entry field (which spans columns 1-2).
            self.dev_user_label.grid(row=7, column=0, sticky="w", padx=15, pady=2)
            self.dev_user_entry.grid(row=7, column=1, columnspan=2, sticky="ew", padx=15, pady=2)
            self.dev_pass_label.grid(row=8, column=0, sticky="w", padx=15, pady=2)
            self.dev_pass_entry.grid(row=8, column=1, columnspan=2, sticky="ew", padx=15, pady=2)
            self.dev_enable_label.grid(row=9, column=0, sticky="w", padx=15, pady=2)
            self.dev_enable_entry.grid(row=9, column=1, columnspan=2, sticky="ew", padx=15, pady=2)
            # Hint on its own row, spanning all columns, so it doesn't
            # overlap with the entry field above it.
            self.dev_cred_hint.grid(row=10, column=0, columnspan=3, sticky="w", padx=15, pady=(0, 4))
            # Push the backup command preview down to row 11 so it
            # doesn't collide with the hint text.
            if self.cmd_preview_label.winfo_ismapped():
                self.cmd_preview_label.grid(row=11, column=0, sticky="w", padx=15, pady=(8, 4))
                self.cmd_preview_entry.grid(row=11, column=1, columnspan=2, sticky="ew", padx=15, pady=(8, 4))
        else:
            # Hide the device-specific credential fields
            self.dev_user_label.grid_remove()
            self.dev_user_entry.grid_remove()
            self.dev_pass_label.grid_remove()
            self.dev_pass_entry.grid_remove()
            self.dev_enable_label.grid_remove()
            self.dev_enable_entry.grid_remove()
            self.dev_cred_hint.grid_remove()
            # Restore the backup command preview to row 10 when the
            # per-device fields are hidden.
            if hasattr(self, 'cmd_preview_label') and self.cmd_preview_label.winfo_ismapped():
                self.cmd_preview_label.grid(row=10, column=0, sticky="w", padx=15, pady=(12, 4))
                self.cmd_preview_entry.grid(row=10, column=1, columnspan=2, sticky="ew", padx=15, pady=(12, 4))

    def _populate(self, device: Dict):
        self.hostname_var.set(device["hostname"])
        self.ip_var.set(device["ip_address"])
        dtype = device["device_type"].title()
        self.type_var.set(dtype)
        self._on_device_type_change()
        self.location_var.set(device.get("location", ""))
        self.port_var.set(str(device.get("port", 22)))

        vendor_key = device.get("vendor", "cisco_ios")
        if dtype == "Firewall":
            v = get_vendor(vendor_key)
            self.fw_vendor_var.set(v.label if v else vendor_key)
        else:
            self.rs_vendor_var.set(RS_VENDOR_KEY_TO_NAME.get(vendor_key, "Cisco IOS"))

        # Populate per-device credentials if they exist
        self.use_device_creds_var.set(device.get("use_device_creds", False))
        self.dev_user_var.set(device.get("device_username", ""))
        self.dev_pass_var.set(device.get("device_password", ""))
        self.dev_enable_var.set(device.get("device_enable_password", ""))
        self._toggle_device_creds()

    def _on_save(self):
        hostname = self.hostname_var.get().strip()
        ip = self.ip_var.get().strip()
        dtype = self.type_var.get().strip()
        location = self.location_var.get().strip()
        port_str = self.port_var.get().strip()

        if not hostname:
            messagebox.showwarning("Validation", "Hostname is required.", parent=self)
            return
        if not ip:
            messagebox.showwarning("Validation", "IP Address is required.", parent=self)
            return
        if not location:
            messagebox.showwarning("Validation", "Location is required.", parent=self)
            return

        # Resolve vendor key based on device type
        if dtype == "Firewall":
            vendor_label_str = self.fw_vendor_var.get().strip()
            vendor_obj = FW_VENDOR_BY_LABEL.get(vendor_label_str)
            if not vendor_obj:
                messagebox.showwarning("Validation", f"Unknown firewall vendor: {vendor_label_str}", parent=self)
                return
            vendor_key = vendor_obj.key
        else:
            vendor_name = self.rs_vendor_var.get().strip()
            vendor_key = RS_VENDOR_NAME_TO_KEY.get(vendor_name, "cisco_ios")

        try:
            port = int(port_str)
            if not 1 <= port <= 65535:
                raise ValueError
        except ValueError:
            messagebox.showwarning("Validation", "Port must be between 1 and 65535.", parent=self)
            return

        # Validate per-device creds if enabled
        use_dev_creds = self.use_device_creds_var.get()
        dev_user = self.dev_user_var.get().strip()
        dev_pass = self.dev_pass_var.get()
        dev_enable = self.dev_enable_var.get().strip()
        if use_dev_creds:
            if not dev_user or not dev_pass:
                messagebox.showwarning(
                    "Validation",
                    "Device-specific credentials are enabled — Username and Password are required.",
                    parent=self,
                )
                return

        self.result = {
            "hostname": hostname,
            "ip_address": ip,
            "device_type": dtype.lower(),
            "vendor": vendor_key,
            "location": location,
            "port": port,
            # Per-device credential override
            "use_device_creds": use_dev_creds,
            "device_username": dev_user,
            "device_password": dev_pass,
            "device_enable_password": dev_enable,
        }
        self.destroy()

    def _on_cancel(self):
        self.result = None
        self.destroy()


# ════════════════════════════════════════════════════════════════
# SHARED SSH CREDENTIALS DIALOG (for Router/Switch)
# ════════════════════════════════════════════════════════════════

class SharedCredentialsDialog(tk.Toplevel):
    """Dialog to set the shared SSH credentials used for Router/Switch backups.

    Also includes a checkbox for "single credential mode" — when enabled,
    these credentials apply to ALL devices (routers, switches, AND firewalls),
    so users with one common credential across their whole fleet don't need
    to enter it per-vendor. Per-vendor overrides still take precedence if set.
    """

    def __init__(self, parent, manager: DeviceManager):
        super().__init__(parent)
        self.result = None
        self.manager = manager

        self.title("Shared SSH Credentials (Router / Switch)")
        self.configure(bg=COLORS["bg_white"])
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.geometry("460x420")
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - 460) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 420) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_cancel)

    def _build_ui(self):
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header, text="  Shared SSH Credentials",
            bg=COLORS["bg_dark"], fg=COLORS["text_light"],
            font=("Segoe UI", 13, "bold"), anchor="w",
        ).pack(side="left", padx=10)

        intro = tk.Frame(self, bg=COLORS["bg_light"])
        intro.pack(fill="x")
        tk.Label(
            intro,
            text=(
                "  Default credentials for every Router and Switch backup.\n"
                "  Tick the box below to also use these for Firewalls (overridable per-vendor)."
            ),
            bg=COLORS["bg_light"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9), justify="left",
        ).pack(anchor="w", padx=10, pady=8)

        form = tk.Frame(self, bg=COLORS["bg_white"])
        form.pack(fill="both", expand=True, padx=20, pady=10)

        existing = self.manager.get_shared_credentials()
        self.user_var = tk.StringVar(value=existing.get("username", ""))
        self.pass_var = tk.StringVar(value=existing.get("password", ""))
        self.enable_var = tk.StringVar(value=existing.get("enable_password", ""))
        self.single_cred_var = tk.BooleanVar(value=existing.get("use_single_credential", False))

        pad = {"padx": 10, "pady": 6}
        tk.Label(form, text="Username *", bg=COLORS["bg_white"],
                 font=("Segoe UI", 10)).grid(row=0, column=0, sticky="w", **pad)
        ttk.Entry(form, textvariable=self.user_var, width=28).grid(
            row=0, column=1, sticky="ew", **pad
        )

        tk.Label(form, text="Password *", bg=COLORS["bg_white"],
                 font=("Segoe UI", 10)).grid(row=1, column=0, sticky="w", **pad)
        ttk.Entry(form, textvariable=self.pass_var, show="*", width=28).grid(
            row=1, column=1, sticky="ew", **pad
        )

        tk.Label(form, text="Enable Password", bg=COLORS["bg_white"],
                 font=("Segoe UI", 10)).grid(row=2, column=0, sticky="w", **pad)
        ttk.Entry(form, textvariable=self.enable_var, show="*", width=28).grid(
            row=2, column=1, sticky="ew", **pad
        )
        tk.Label(form, text="(Cisco enable secret, leave blank if not needed)",
                 bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                 font=("Segoe UI", 8)).grid(row=3, column=1, sticky="w", padx=10)

        # ── Single credential mode checkbox ────────────────────
        single_frame = tk.Frame(form, bg="#f0f5fa", bd=1, relief="solid")
        single_frame.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(12, 4), padx=2)

        tk.Checkbutton(
            single_frame,
            text="Use these credentials for ALL devices (Routers, Switches, AND Firewalls)",
            variable=self.single_cred_var,
            bg="#f0f5fa", fg=COLORS["text_dark"],
            font=("Segoe UI", 9, "bold"),
            activebackground="#f0f5fa",
        ).pack(anchor="w", padx=8, pady=(8, 4))

        tk.Label(
            single_frame,
            text=(
                "  When checked, these credentials are automatically applied to every\n"
                "  firewall vendor that doesn't have its own per-vendor override.\n"
                "  Use 'Set Firewall Creds (per vendor)' to override specific vendors\n"
                "  that need different credentials (e.g. a FortiGate with its own admin)."
            ),
            bg="#f0f5fa", fg=COLORS["text_dark"],
            font=("Segoe UI", 8), justify="left",
        ).pack(anchor="w", padx=8, pady=(0, 8))

        form.columnconfigure(1, weight=1)

        # Buttons (bottom-first pack pattern)
        btn_frame = tk.Frame(self, bg=COLORS["bg_white"])
        btn_frame.pack(fill="x", side="bottom", padx=20, pady=(0, 12))

        ttk.Button(btn_frame, text="Cancel", command=self._on_cancel, width=12).pack(side="right", padx=(10, 0))
        tk.Button(
            btn_frame, text="Save",
            command=self._on_ok,
            bg=COLORS["btn_primary"], fg="white",
            font=("Segoe UI", 10, "bold"),
            relief="flat", padx=20, pady=4, cursor="hand2",
        ).pack(side="right")

    def _on_ok(self):
        user = self.user_var.get().strip()
        pwd = self.pass_var.get()
        enable = self.enable_var.get().strip()
        if not user or not pwd:
            messagebox.showwarning("Validation", "Username and password are required.", parent=self)
            return
        self.result = {
            "username": user,
            "password": pwd,
            "enable_password": enable,
            "use_single_credential": self.single_cred_var.get(),
        }
        self.destroy()

    def _on_cancel(self):
        self.result = None
        self.destroy()


# ════════════════════════════════════════════════════════════════
# PER-VENDOR FIREWALL CREDENTIALS DIALOG
# ════════════════════════════════════════════════════════════════

class FirewallCredentialsDialog(tk.Toplevel):
    """Dialog to set per-vendor firewall credentials (tabbed, scrollable)."""

    def __init__(self, parent, manager: DeviceManager):
        super().__init__(parent)
        self.result: Dict[str, Dict[str, str]] = {}
        self.manager = manager

        self.title("Per-Vendor Firewall Credentials")
        self.configure(bg=COLORS["bg_white"])
        self.resizable(True, True)
        self.transient(parent)
        self.grab_set()

        self.geometry("640x680")
        self.minsize(560, 520)
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - 640) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 680) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_cancel)

    def _build_ui(self):
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)
        tk.Label(
            header, text="  Per-Vendor Firewall Credentials",
            bg=COLORS["bg_dark"], fg=COLORS["text_light"],
            font=("Segoe UI", 13, "bold"), anchor="w",
        ).pack(side="left", padx=10)
        tk.Label(
            header, text="One tab per vendor  •  API-first / SSH-fallback  ",
            bg=COLORS["bg_dark"], fg="#b8d4f0",
            font=("Segoe UI", 9), anchor="e",
        ).pack(side="right", padx=10)

        intro = tk.Frame(self, bg=COLORS["bg_light"])
        intro.pack(fill="x", side="top")
        tk.Label(
            intro,
            text=(
                "  Each firewall vendor can use SSH credentials, API credentials, or both.\n"
                "  The engine tries each method in the vendor's priority order "
                "(e.g. API first, SSH fallback).\n"
                "  Fill only the fields you actually need for that vendor."
            ),
            bg=COLORS["bg_light"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9), justify="left",
        ).pack(anchor="w", padx=10, pady=8)

        # ── Single-credential mode banner (shown only when active) ──
        if self.manager.is_single_credential_mode() and self.manager.has_shared_credentials():
            shared = self.manager.get_shared_credentials()
            banner = tk.Frame(self, bg="#fff3cd", bd=1, relief="solid")
            banner.pack(fill="x", side="top", padx=15, pady=(0, 4))
            tk.Label(
                banner,
                text=(
                    f"  ℹ  Single-credential mode is ON — shared SSH credentials "
                    f"(user: {shared.get('username', '')}) are automatically\n"
                    f"  applied to every firewall vendor that doesn't have an explicit "
                    f"override below.\n"
                    f"  Fields you fill here act as OVERRIDES for specific vendors "
                    f"that need different credentials."
                ),
                bg="#fff3cd", fg="#664d03",
                font=("Segoe UI", 9), justify="left",
            ).pack(anchor="w", padx=8, pady=8)

        # Buttons (pack bottom FIRST so notebook doesn't eat their space)
        btn_frame = tk.Frame(self, bg=COLORS["bg_white"])
        btn_frame.pack(fill="x", side="bottom", padx=15, pady=(8, 12))
        ttk.Button(
            btn_frame, text="Cancel", command=self._on_cancel, width=12,
        ).pack(side="right", padx=(10, 0))
        tk.Button(
            btn_frame, text="Save All",
            command=self._on_ok,
            bg=COLORS["btn_primary"], fg="white",
            font=("Segoe UI", 10, "bold"),
            relief="flat", padx=20, pady=4, cursor="hand2",
        ).pack(side="right")

        nb_frame = tk.Frame(self, bg=COLORS["bg_white"])
        nb_frame.pack(fill="both", expand=True, padx=15, side="top")
        self.notebook = ttk.Notebook(nb_frame)
        self.notebook.pack(fill="both", expand=True)

        self._vendor_entries: Dict[str, Dict[str, tk.StringVar]] = {}
        for vendor in active_vendors():
            self._build_vendor_tab(vendor)

    def _build_vendor_tab(self, vendor):
        """Build one scrollable Notebook tab for a single firewall vendor."""
        tab = tk.Frame(self.notebook, bg=COLORS["bg_white"])
        self.notebook.add(tab, text=vendor.label)

        # Scrollable container
        canvas = tk.Canvas(
            tab, bg=COLORS["bg_white"], highlightthickness=0, borderwidth=0,
        )
        scrollbar = ttk.Scrollbar(tab, orient="vertical", command=canvas.yview)
        content = tk.Frame(canvas, bg=COLORS["bg_white"])

        def _on_content_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
        content.bind("<Configure>", _on_content_configure)

        canvas_window = canvas.create_window((0, 0), window=content, anchor="nw")

        def _on_canvas_configure(event):
            canvas.itemconfig(canvas_window, width=event.width)
        canvas.bind("<Configure>", _on_canvas_configure)

        def _on_mousewheel(event):
            if sys.platform == "win32":
                canvas.yview_scroll(int(-event.delta / 120), "units")
            else:
                canvas.yview_scroll(int(-event.delta), "units")

        def _on_linux_scroll_up(event):
            canvas.yview_scroll(-1, "units")

        def _on_linux_scroll_down(event):
            canvas.yview_scroll(1, "units")

        canvas.bind("<Enter>", lambda e: (
            canvas.bind_all("<MouseWheel>", _on_mousewheel),
            canvas.bind_all("<Button-4>", _on_linux_scroll_up),
            canvas.bind_all("<Button-5>", _on_linux_scroll_down),
        ))
        canvas.bind("<Leave>", lambda e: (
            canvas.unbind_all("<MouseWheel>"),
            canvas.unbind_all("<Button-4>"),
            canvas.unbind_all("<Button-5>"),
        ))

        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        content.configure(padx=15, pady=12)

        # ── Notes ─────────────────────────────────────────────
        if vendor.notes:
            notes_frame = tk.Frame(content, bg="#f0f5fa", bd=1, relief="solid")
            notes_frame.pack(fill="x", pady=(0, 12))
            tk.Label(
                notes_frame, text="  " + vendor.notes,
                bg="#f0f5fa", fg=COLORS["text_dark"],
                font=("Segoe UI", 9), justify="left",
                wraplength=520, anchor="w",
            ).pack(anchor="w", padx=8, pady=8)

        # ── Backup priority ───────────────────────────────────
        method_summary = " → ".join(m.upper() for m in vendor.backup_priority)
        tk.Label(
            content,
            text=f"Backup priority: {method_summary}",
            bg=COLORS["bg_white"], fg=COLORS["btn_primary"],
            font=("Segoe UI", 10, "bold"), anchor="w",
        ).pack(fill="x", pady=(0, 8))

        # ── Load existing creds ───────────────────────────────
        existing = self.manager.get_fw_credentials(vendor.key) or {}
        user_var = tk.StringVar(value=existing.get("username", ""))
        pass_var = tk.StringVar(value=existing.get("password", ""))
        enable_var = tk.StringVar(value=existing.get("enable_password", ""))
        token_var = tk.StringVar(value=existing.get("api_token", ""))

        self._vendor_entries[vendor.key] = {
            "username": user_var,
            "password": pass_var,
            "enable_password": enable_var,
            "api_token": token_var,
        }

        # ── SSH credentials section ───────────────────────────
        ssh_frame = tk.LabelFrame(
            content, text="  SSH / CLI Credentials  ",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 10, "bold"),
            padx=12, pady=10, bd=1, relief="solid",
        )
        ssh_frame.pack(fill="x", pady=(0, 10))
        ssh_frame.columnconfigure(1, weight=1)

        tk.Label(ssh_frame, text="Username",
                 bg=COLORS["bg_white"], font=("Segoe UI", 9),
                 ).grid(row=0, column=0, sticky="w", pady=3)
        ttk.Entry(ssh_frame, textvariable=user_var, width=32).grid(
            row=0, column=1, sticky="ew", pady=3, padx=(10, 0)
        )

        tk.Label(ssh_frame, text="Password",
                 bg=COLORS["bg_white"], font=("Segoe UI", 9),
                 ).grid(row=1, column=0, sticky="w", pady=3)
        ttk.Entry(ssh_frame, textvariable=pass_var, show="*", width=32).grid(
            row=1, column=1, sticky="ew", pady=3, padx=(10, 0)
        )

        if vendor.supports_enable:
            tk.Label(ssh_frame, text="Enable Password",
                     bg=COLORS["bg_white"], font=("Segoe UI", 9),
                     ).grid(row=2, column=0, sticky="w", pady=3)
            ttk.Entry(ssh_frame, textvariable=enable_var, show="*", width=32).grid(
                row=2, column=1, sticky="ew", pady=3, padx=(10, 0)
            )

        if vendor.ssh_supported:
            tk.Label(
                ssh_frame,
                text=f"(Used when SSH is in the priority list. Port from the firewall row, "
                     f"netmiko driver: {vendor.netmiko_type})",
                bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                font=("Segoe UI", 8), wraplength=450, justify="left",
            ).grid(row=3 if vendor.supports_enable else 2, column=0,
                   columnspan=2, sticky="w", pady=(4, 0))

        # ── API credentials section ───────────────────────────
        if vendor.api_supported:
            api_frame = tk.LabelFrame(
                content, text=f"  API Credentials  ({vendor.api_auth_mode.upper()})  ",
                bg=COLORS["bg_white"], fg=COLORS["text_dark"],
                font=("Segoe UI", 10, "bold"),
                padx=12, pady=10, bd=1, relief="solid",
            )
            api_frame.pack(fill="x", pady=(0, 6))
            api_frame.columnconfigure(1, weight=1)

            tk.Label(api_frame, text="API Token",
                     bg=COLORS["bg_white"], font=("Segoe UI", 9),
                     ).grid(row=0, column=0, sticky="w", pady=3)
            ttk.Entry(api_frame, textvariable=token_var, show="*", width=32).grid(
                row=0, column=1, sticky="ew", pady=3, padx=(10, 0)
            )

            hint = f"API endpoint: https://<host>:{vendor.api_port}{vendor.api_path}"
            if vendor.api_auth_mode == "either":
                hint += (
                    "\nAuth: Bearer token if provided, else HTTP Basic with the SSH username+password above."
                )
            elif vendor.api_auth_mode == "bearer":
                hint += "\nAuth: Bearer token only (API token is required)."
            elif vendor.api_auth_mode == "basic":
                hint += (
                    "\nAuth: HTTP Basic with the SSH username+password above "
                    "(token field is ignored on this vendor)."
                )
            tk.Label(
                api_frame, text=hint,
                bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                font=("Segoe UI", 8), wraplength=450, justify="left",
            ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))

    def _on_ok(self):
        for vkey, vars_dict in self._vendor_entries.items():
            user = vars_dict["username"].get().strip()
            pwd = vars_dict["password"].get()
            enable = vars_dict["enable_password"].get().strip()
            token = vars_dict["api_token"].get().strip()
            if user or pwd or enable or token:
                self.result[vkey] = {
                    "username": user,
                    "password": pwd,
                    "enable_password": enable,
                    "api_token": token,
                }
        self.destroy()

    def _on_cancel(self):
        self.result = {}
        self.destroy()


# ════════════════════════════════════════════════════════════════
# DIFF VIEWER DIALOG
# ════════════════════════════════════════════════════════════════

class DiffViewerDialog(tk.Toplevel):
    """Shows the config diff for a single BackupResult."""

    def __init__(self, parent, result: BackupResult):
        super().__init__(parent)
        self.title(f"Config Diff — {result.hostname} ({result.ip_address})")
        self.configure(bg=COLORS["bg_white"])
        self.geometry("800x600")
        self.transient(parent)

        x = parent.winfo_x() + (parent.winfo_width() - 800) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 600) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header,
            text=f"Config Diff: {result.hostname} ({result.ip_address}) — {result.device_type.title()}",
            bg=COLORS["bg_dark"], fg=COLORS["text_light"],
            font=("Segoe UI", 12, "bold"),
        ).pack(expand=True)

        summary_bar = tk.Frame(self, bg=COLORS["bg_light"])
        summary_bar.pack(fill="x")
        tk.Label(
            summary_bar,
            text=f"  Method: {result.backup_method.upper()}   |   "
                 f"Changes: {result.diff_summary}",
            bg=COLORS["bg_light"], fg=COLORS["text_dark"],
            font=("Segoe UI", 10, "bold"),
        ).pack(side="left", padx=10, pady=6)

        diff_frame = tk.Frame(self, bg=COLORS["bg_white"])
        diff_frame.pack(fill="both", expand=True, padx=10, pady=8)

        self.diff_text = tk.Text(
            diff_frame, wrap="none", font=("Consolas", 9),
            bg="#1e1e1e", fg="#d4d4d4",
            relief="flat", state="disabled",
        )
        scroll_y = ttk.Scrollbar(diff_frame, orient="vertical", command=self.diff_text.yview)
        scroll_x = ttk.Scrollbar(diff_frame, orient="horizontal", command=self.diff_text.xview)
        self.diff_text.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        self.diff_text.pack(side="left", fill="both", expand=True)
        scroll_y.pack(side="right", fill="y")
        scroll_x.pack(side="bottom", fill="x")

        self.diff_text.tag_configure("added", foreground="#4ec9b0")
        self.diff_text.tag_configure("removed", foreground="#f44747")
        self.diff_text.tag_configure("header", foreground="#569cd6")
        self.diff_text.tag_configure("hunk", foreground="#ce9178")

        if result.diff_text:
            self._populate_diff(result.diff_text)
        else:
            self._populate_diff("(no diff available — first backup or no changes)")

        btn_frame = tk.Frame(self, bg=COLORS["bg_white"])
        btn_frame.pack(fill="x", padx=10, pady=(0, 10))
        tk.Button(
            btn_frame, text="Close", command=self.destroy,
            bg=COLORS["btn_primary"], fg="white",
            font=("Segoe UI", 10, "bold"),
            relief="flat", padx=20, pady=4, cursor="hand2",
        ).pack(side="right")

    def _populate_diff(self, text):
        self.diff_text.configure(state="normal")
        self.diff_text.delete("1.0", "end")
        for line in text.splitlines():
            if line.startswith("+++") or line.startswith("---"):
                self.diff_text.insert("end", line + "\n", "header")
            elif line.startswith("@@"):
                self.diff_text.insert("end", line + "\n", "hunk")
            elif line.startswith("+"):
                self.diff_text.insert("end", line + "\n", "added")
            elif line.startswith("-"):
                self.diff_text.insert("end", line + "\n", "removed")
            else:
                self.diff_text.insert("end", line + "\n")
        self.diff_text.configure(state="disabled")


# ════════════════════════════════════════════════════════════════
# MANAGE VENDORS DIALOG
# ════════════════════════════════════════════════════════════════

class ManageVendorsDialog(tk.Toplevel):
    """
    Redesigned Manage Vendors dialog.

    Three-pane layout:
      LEFT  : Vendor Template Gallery — click a template to auto-fill the
              form with the vendor's official backup commands (sourced from
              vendor_templates.py). Templates are grouped by category:
              Firewall / Router-Switch.
      MIDDLE: Saved Vendors List — shows all currently registered vendors
              (built-in + custom). Click to edit; custom vendors can be deleted.
      RIGHT : Edit Form — all fields are editable. When a template is picked
              the form auto-populates and the user can tweak before saving.
    """

    def __init__(self, parent, data_dir: str):
        super().__init__(parent)
        self.data_dir = data_dir
        self.parent = parent
        self.vendors_changed = False

        self.title("Manage Vendors — Add from Templates or Custom")
        self.configure(bg=COLORS["bg_white"])
        self.resizable(True, True)
        self.transient(parent)
        self.grab_set()

        self.geometry("1180x700")
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - 1180) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 700) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ── color helpers for the template cards ──────────────────
    TEMPLATE_CARD_BG = "#f4f8fc"
    TEMPLATE_CARD_BG_HOVER = "#e1ecf4"
    TEMPLATE_CARD_BG_SELECTED = "#29629b"
    TEMPLATE_CARD_FG = "#1a3a5f"
    TEMPLATE_CARD_FG_SELECTED = "#ffffff"

    def _build_ui(self):
        # ── Header ─────────────────────────────────────────────
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=55)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)
        tk.Label(
            header, text="  Manage Vendors",
            bg=COLORS["bg_dark"], fg=COLORS["text_light"],
            font=("Segoe UI", 14, "bold"), anchor="w",
        ).pack(side="left", padx=10)
        tk.Label(
            header,
            text="Pick a vendor template → auto-fill official backup commands → edit if needed → Save  ",
            bg=COLORS["bg_dark"], fg="#b8d4f0",
            font=("Segoe UI", 9), anchor="e",
        ).pack(side="right", padx=10)

        # ── Bottom button bar (pack FIRST with side="bottom") ──
        btn_frame = tk.Frame(self, bg=COLORS["bg_white"])
        btn_frame.pack(fill="x", side="bottom", padx=15, pady=(8, 12))
        tk.Button(
            btn_frame, text="Close",
            command=self._on_close,
            bg=COLORS["btn_primary"], fg="white",
            font=("Segoe UI", 10, "bold"),
            relief="flat", padx=20, pady=4, cursor="hand2",
        ).pack(side="right")

        # ── Main 3-pane content ────────────────────────────────
        content = tk.Frame(self, bg=COLORS["bg_white"])
        content.pack(fill="both", expand=True, padx=15, pady=(0, 8))

        # LEFT: template gallery
        self._build_template_gallery(content)

        # MIDDLE: saved vendors list
        self._build_saved_vendors_list(content)

        # RIGHT: edit form
        self._build_edit_form_pane(content)

        # Populate the saved vendors list
        self._refresh_vendor_list()

    # ══════════════════════════════════════════════════════════
    # LEFT PANE: TEMPLATE GALLERY
    # ══════════════════════════════════════════════════════════
    def _build_template_gallery(self, parent):
        from vendor_templates import FIREWALL_TEMPLATES, ROUTER_SWITCH_TEMPLATES

        gallery_frame = tk.LabelFrame(
            parent, text="  Vendor Templates (click to auto-fill)  ",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 10, "bold"),
            padx=8, pady=8, bd=1, relief="solid",
        )
        gallery_frame.pack(side="left", fill="both", expand=True, padx=(0, 6))
        gallery_frame.configure(width=300)
        gallery_frame.pack_propagate(False)

        # Scrollable area for the template cards
        canvas = tk.Canvas(gallery_frame, bg=COLORS["bg_white"],
                           highlightthickness=0, borderwidth=0)
        vsb = ttk.Scrollbar(gallery_frame, orient="vertical", command=canvas.yview)
        self.template_inner = tk.Frame(canvas, bg=COLORS["bg_white"])

        self.template_inner.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        self._template_canvas_window = canvas.create_window((0, 0), window=self.template_inner, anchor="nw")

        def _on_canvas_configure(event):
            canvas.itemconfig(self._template_canvas_window, width=event.width)
        canvas.bind("<Configure>", _on_canvas_configure)

        # Mousewheel scrolling
        def _on_mousewheel(event):
            if sys.platform == "win32":
                canvas.yview_scroll(int(-event.delta / 120), "units")
            else:
                canvas.yview_scroll(int(-event.delta), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _on_mousewheel))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        # Build template cards, grouped by category
        self._template_cards = {}  # label -> (frame, is_selected)

        # Firewall section header
        self._add_section_header(self.template_inner, "  FIREWALL TEMPLATES", "#c82828")
        for t in FIREWALL_TEMPLATES:
            self._add_template_card(self.template_inner, t)

        # Router/Switch section header
        self._add_section_header(self.template_inner, "  ROUTER / SWITCH TEMPLATES", "#29629b")
        for t in ROUTER_SWITCH_TEMPLATES:
            self._add_template_card(self.template_inner, t)

    def _add_section_header(self, parent, text, color):
        tk.Label(
            parent, text=text,
            bg=COLORS["bg_white"], fg=color,
            font=("Segoe UI", 9, "bold"), anchor="w",
        ).pack(fill="x", pady=(10, 4), padx=2)

    def _add_template_card(self, parent, template):
        """Add a clickable card for one vendor template."""
        card = tk.Frame(
            parent, bg=self.TEMPLATE_CARD_BG,
            bd=1, relief="solid", cursor="hand2",
        )
        card.pack(fill="x", pady=2, padx=2)

        # Vendor name + method badge
        top = tk.Frame(card, bg=self.TEMPLATE_CARD_BG)
        top.pack(fill="x", padx=8, pady=(6, 2))

        tk.Label(
            top, text=template.label,
            bg=self.TEMPLATE_CARD_BG, fg=self.TEMPLATE_CARD_FG,
            font=("Segoe UI", 9, "bold"), anchor="w",
        ).pack(side="left")

        # Method badge (API+SSH or SSH)
        if template.api_supported:
            badge_text = "API+SSH"
            badge_bg = "#228b22"
        else:
            badge_text = "SSH"
            badge_bg = "#666666"
        tk.Label(
            top, text=f" {badge_text} ",
            bg=badge_bg, fg="white",
            font=("Segoe UI", 7, "bold"),
        ).pack(side="right")

        # Backup commands preview (first command)
        cmd_preview = template.backup_commands[0] if template.backup_commands else "(API only)"
        if len(cmd_preview) > 38:
            cmd_preview = cmd_preview[:35] + "..."
        tk.Label(
            card, text=f"  {cmd_preview}",
            bg=self.TEMPLATE_CARD_BG, fg="#555555",
            font=("Consolas", 8), anchor="w",
        ).pack(fill="x", padx=8, pady=(0, 6))

        # Bind click to auto-fill the form
        def on_click(e, t=template, c=card):
            self._select_template(t, c)
        for w in (card, top):
            w.bind("<Button-1>", on_click)
        for child in card.winfo_children():
            child.bind("<Button-1>", on_click)
            for grandchild in child.winfo_children():
                grandchild.bind("<Button-1>", on_click)

        self._template_cards[template.label] = [card, False]

    def _select_template(self, template, card):
        """Highlight the clicked card and auto-fill the form."""
        # Reset all cards to default bg
        for label, state in self._template_cards.items():
            state[0].configure(bg=self.TEMPLATE_CARD_BG)
            state[1] = False
            for child in state[0].winfo_children():
                try:
                    child.configure(bg=self.TEMPLATE_CARD_BG)
                    for gc in child.winfo_children():
                        gc.configure(bg=self.TEMPLATE_CARD_BG)
                except tk.TclError:
                    pass
            # Re-color labels
            for child in state[0].winfo_children():
                if isinstance(child, tk.Label) and " " not in child.cget("text")[:1]:
                    pass  # skip badge
                elif isinstance(child, tk.Frame):
                    for gc in child.winfo_children():
                        if isinstance(gc, tk.Label) and gc.cget("text") and gc.cget("font") and "bold" in str(gc.cget("font")):
                            gc.configure(fg=self.TEMPLATE_CARD_FG)

        # Highlight selected card
        card.configure(bg=self.TEMPLATE_CARD_BG_SELECTED)
        self._template_cards[template.label][1] = True
        for child in card.winfo_children():
            try:
                child.configure(bg=self.TEMPLATE_CARD_BG_SELECTED)
                for gc in child.winfo_children():
                    # Don't change the badge color
                    if not (isinstance(gc, tk.Label) and gc.cget("text") in (" API+SSH ", " SSH ")):
                        gc.configure(bg=self.TEMPLATE_CARD_BG_SELECTED, fg=self.TEMPLATE_CARD_FG_SELECTED)
            except tk.TclError:
                pass

        # Auto-fill the form
        self._fill_form_from_template(template)

    def _fill_form_from_template(self, t):
        """Populate the edit form using a vendor template."""
        # Re-enable all form fields first (in case a built-in was selected before)
        self._set_form_readonly(False)
        self.f_key_entry.configure(state="normal")

        self.f_key.set(t.suggested_key or t.key)
        self.f_label.set(t.label)
        self.f_netmiko.set(t.netmiko_type)
        self.f_commands.delete("1.0", "end")
        self.f_commands.insert("1.0", "\n".join(t.backup_commands))
        self.f_pre_commands.delete("1.0", "end")
        self.f_pre_commands.insert("1.0", "\n".join(t.pre_commands))
        self.f_ssh.set(t.ssh_supported)
        self.f_enable.set(t.supports_enable)
        self.f_api.set(t.api_supported)
        self.f_api_path.set(t.api_path or "")
        self.f_api_port.set(str(t.api_port))
        self.f_api_auth.set(t.api_auth_mode)
        self.f_active.set(True)
        self.f_notes.delete("1.0", "end")
        self.f_notes.insert("1.0", t.description or "")

        self._toggle_api_fields()

        # Update the doc reference label
        self.doc_ref_label.configure(text=f"📚 {t.doc_reference}" if t.doc_reference else "")

        # Deselect any saved-vendor list selection
        if hasattr(self, "vendor_tree"):
            self.vendor_tree.selection_remove(self.vendor_tree.selection())
        self.edit_btn.configure(state="disabled")
        self.delete_btn.configure(state="disabled")

    # ══════════════════════════════════════════════════════════
    # MIDDLE PANE: SAVED VENDORS LIST
    # ══════════════════════════════════════════════════════════
    def _build_saved_vendors_list(self, parent):
        list_frame = tk.LabelFrame(
            parent, text="  Saved Vendors  ",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 10, "bold"),
            padx=8, pady=8, bd=1, relief="solid",
        )
        list_frame.pack(side="left", fill="both", expand=True, padx=6)
        list_frame.configure(width=300)
        list_frame.pack_propagate(False)

        list_cols = ("label", "key", "methods", "status")
        self.vendor_tree = ttk.Treeview(
            list_frame, columns=list_cols, show="headings",
            selectmode="browse", height=14,
        )
        self.vendor_tree.heading("label", text="Vendor")
        self.vendor_tree.heading("key", text="Key")
        self.vendor_tree.heading("methods", text="Methods")
        self.vendor_tree.heading("status", text="Status")

        self.vendor_tree.column("label", width=110, minwidth=80)
        self.vendor_tree.column("key", width=90, minwidth=60)
        self.vendor_tree.column("methods", width=80, minwidth=60)
        self.vendor_tree.column("status", width=55, minwidth=45)

        vsb = ttk.Scrollbar(list_frame, orient="vertical",
                            command=self.vendor_tree.yview)
        self.vendor_tree.configure(yscrollcommand=vsb.set)
        self.vendor_tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.vendor_tree.tag_configure("builtin", foreground=COLORS["text_gray"])
        self.vendor_tree.tag_configure("custom", foreground=COLORS["btn_primary"])
        self.vendor_tree.tag_configure("inactive", foreground=COLORS["fail"])
        self.vendor_tree.bind("<<TreeviewSelect>>", self._on_vendor_select)

        # Action buttons under the list
        action_frame = tk.Frame(list_frame, bg=COLORS["bg_white"])
        action_frame.pack(fill="x", pady=(8, 0))
        self.edit_btn = tk.Button(
            action_frame, text="Edit",
            command=self._edit_selected,
            bg=COLORS["bg_medium"], fg="white",
            font=("Segoe UI", 9, "bold"),
            relief="flat", padx=10, pady=2, cursor="hand2", state="disabled",
        )
        self.edit_btn.pack(side="left", padx=(0, 4))
        self.delete_btn = tk.Button(
            action_frame, text="Delete",
            command=self._delete_selected,
            bg=COLORS["btn_danger"], fg="white",
            font=("Segoe UI", 9, "bold"),
            relief="flat", padx=10, pady=2, cursor="hand2", state="disabled",
        )
        self.delete_btn.pack(side="left")

    def _refresh_vendor_list(self):
        for item in self.vendor_tree.get_children():
            self.vendor_tree.delete(item)
        from vendors import ALL_VENDORS
        for v in ALL_VENDORS:
            methods = " → ".join(m.upper() for m in v.backup_priority) if v.backup_priority else "—"
            status = "Active" if v.active else "Off"
            is_builtin = is_builtin_vendor(v.key)
            tag = "builtin" if is_builtin else "custom"
            if not v.active:
                tag = "inactive"
            self.vendor_tree.insert("", "end", values=(
                v.label, v.key, methods, status
            ), tags=(tag,), iid=v.key)

    def _on_vendor_select(self, event):
        sel = self.vendor_tree.selection()
        if not sel:
            self.edit_btn.configure(state="disabled")
            self.delete_btn.configure(state="disabled")
            return
        key = sel[0]
        is_builtin = is_builtin_vendor(key)
        self.edit_btn.configure(state="normal")
        self.delete_btn.configure(state="disabled" if is_builtin else "normal")
        v = get_vendor(key)
        if v:
            self._populate_form(v, readonly=is_builtin)

    def _edit_selected(self):
        sel = self.vendor_tree.selection()
        if not sel:
            return
        key = sel[0]
        v = get_vendor(key)
        if v:
            is_builtin = is_builtin_vendor(key)
            self._populate_form(v, readonly=is_builtin)
            if is_builtin:
                messagebox.showinfo(
                    "Built-in Vendor",
                    f"'{v.label}' is a built-in vendor and cannot be modified.\n"
                    "The form is shown in read-only mode.\n\n"
                    "To create a custom variant, pick a template from the left "
                    "and save it with a new key.",
                    parent=self,
                )

    def _delete_selected(self):
        sel = self.vendor_tree.selection()
        if not sel:
            return
        key = sel[0]
        if is_builtin_vendor(key):
            messagebox.showwarning("Cannot Delete",
                f"'{key}' is a built-in vendor and cannot be deleted.",
                parent=self)
            return
        v = get_vendor(key)
        if not v:
            return
        if not messagebox.askyesno(
            "Confirm Delete",
            f"Delete custom vendor '{v.label}' ({key})?\n\n"
            "Existing devices using this vendor will need to be re-assigned.",
            parent=self,
        ):
            return
        try:
            ok = delete_custom_vendor(self.data_dir, key)
            if ok:
                self._log(f"Deleted custom vendor: {v.label}", "success")
                self.vendors_changed = True
                self._refresh_vendor_list()
                self._clear_form()
        except ValueError as e:
            messagebox.showerror("Error", str(e), parent=self)

    # ══════════════════════════════════════════════════════════
    # RIGHT PANE: EDIT FORM
    # ══════════════════════════════════════════════════════════
    def _build_edit_form_pane(self, parent):
        form_outer = tk.LabelFrame(
            parent, text="  Vendor Details (editable)  ",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 10, "bold"),
            padx=10, pady=10, bd=1, relief="solid",
        )
        form_outer.pack(side="left", fill="both", expand=True)
        form_outer.configure(width=420)
        form_outer.pack_propagate(False)

        # Scrollable form
        canvas = tk.Canvas(form_outer, bg=COLORS["bg_white"],
                           highlightthickness=0, borderwidth=0)
        vsb = ttk.Scrollbar(form_outer, orient="vertical", command=canvas.yview)
        self.form_frame = tk.Frame(canvas, bg=COLORS["bg_white"])

        self.form_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        self._form_canvas_window = canvas.create_window((0, 0), window=self.form_frame, anchor="nw")

        def _on_form_canvas_configure(event):
            canvas.itemconfig(self._form_canvas_window, width=event.width)
        canvas.bind("<Configure>", _on_form_canvas_configure)

        def _on_form_mousewheel(event):
            if sys.platform == "win32":
                canvas.yview_scroll(int(-event.delta / 120), "units")
            else:
                canvas.yview_scroll(int(-event.delta), "units")
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _on_form_mousewheel))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        self._build_form_fields()

    def _build_form_fields(self):
        f = self.form_frame
        f.configure(padx=8, pady=8)

        # ── Doc reference banner ──────────────────────────────
        self.doc_ref_label = tk.Label(
            f, text="",
            bg="#f0f5fa", fg=COLORS["text_dark"],
            font=("Segoe UI", 8, "italic"), anchor="w",
            justify="left", wraplength=380,
            bd=1, relief="solid", padx=6, pady=4,
        )
        self.doc_ref_label.pack(fill="x", pady=(0, 8))

        # ── Key + Label row (side by side) ────────────────────
        top_row = tk.Frame(f, bg=COLORS["bg_white"])
        top_row.pack(fill="x", pady=2)
        top_row.columnconfigure(1, weight=1)
        top_row.columnconfigure(3, weight=1)

        tk.Label(top_row, text="Key *", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w", padx=(0, 4))
        self.f_key = tk.StringVar()
        self.f_key_entry = ttk.Entry(top_row, textvariable=self.f_key, width=14)
        self.f_key_entry.grid(row=0, column=1, sticky="ew", padx=(0, 8))

        tk.Label(top_row, text="Label *", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).grid(row=0, column=2, sticky="w", padx=(0, 4))
        self.f_label = tk.StringVar()
        ttk.Entry(top_row, textvariable=self.f_label, width=18).grid(
            row=0, column=3, sticky="ew")

        tk.Label(f, text="(key: unique, lowercase, no spaces)",
                 bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                 font=("Segoe UI", 8)).pack(anchor="w", pady=(0, 4))

        # ── Netmiko type ──────────────────────────────────────
        netmiko_row = tk.Frame(f, bg=COLORS["bg_white"])
        netmiko_row.pack(fill="x", pady=2)
        netmiko_row.columnconfigure(1, weight=1)

        tk.Label(netmiko_row, text="Netmiko Type *", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w", padx=(0, 4))
        self.f_netmiko = tk.StringVar(value="cisco_ios")
        ttk.Combobox(netmiko_row, textvariable=self.f_netmiko,
            values=["cisco_ios", "cisco_xe", "cisco_xr", "cisco_nxos",
                    "cisco_asa", "cisco_ftd", "fortinet", "checkpoint_gaia",
                    "juniper_junos", "paloalto_panos", "arista_eos",
                    "hp_comware", "huawei", "huawei_vrpv8",
                    "mikrotik_routeros", "dell_os6", "dell_os10",
                    "extreme_exos", "ruckus_fastiron", "linux"],
        ).grid(row=0, column=1, sticky="ew")

        # ── Backup commands ───────────────────────────────────
        tk.Label(f, text="Backup Commands *", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(6, 2))
        self.f_commands = tk.Text(f, height=3, font=("Consolas", 9),
                                  bg="#fafafa", relief="solid", bd=1,
                                  wrap="none")
        self.f_commands.pack(fill="x", pady=2)
        tk.Label(f, text="(auto-filled from template — one command per line, editable)",
                 bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                 font=("Segoe UI", 8)).pack(anchor="w", pady=(0, 4))

        # ── Pre-commands ──────────────────────────────────────
        tk.Label(f, text="Pre-Commands (optional)", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(4, 2))
        self.f_pre_commands = tk.Text(f, height=2, font=("Consolas", 9),
                                      bg="#fafafa", relief="solid", bd=1,
                                      wrap="none")
        self.f_pre_commands.pack(fill="x", pady=2)

        # ── Options row (SSH / Enable / API / Active) ─────────
        opts_row = tk.Frame(f, bg=COLORS["bg_white"])
        opts_row.pack(fill="x", pady=(8, 4))

        self.f_ssh = tk.BooleanVar(value=True)
        tk.Checkbutton(opts_row, text="SSH", variable=self.f_ssh,
                       bg=COLORS["bg_white"], font=("Segoe UI", 9, "bold"),
                       activebackground=COLORS["bg_white"],
                       ).pack(side="left", padx=(0, 10))

        self.f_enable = tk.BooleanVar(value=False)
        tk.Checkbutton(opts_row, text="Enable Mode", variable=self.f_enable,
                       bg=COLORS["bg_white"], font=("Segoe UI", 9),
                       activebackground=COLORS["bg_white"],
                       ).pack(side="left", padx=(0, 10))

        self.f_api = tk.BooleanVar(value=False)
        tk.Checkbutton(opts_row, text="API (HTTPS)", variable=self.f_api,
                       bg=COLORS["bg_white"], font=("Segoe UI", 9, "bold"),
                       activebackground=COLORS["bg_white"],
                       command=self._toggle_api_fields,
                       ).pack(side="left", padx=(0, 10))

        self.f_active = tk.BooleanVar(value=True)
        tk.Checkbutton(opts_row, text="Active", variable=self.f_active,
                       bg=COLORS["bg_white"], font=("Segoe UI", 9, "bold"),
                       activebackground=COLORS["bg_white"],
                       ).pack(side="left")

        # ── API section (conditionally shown) ─────────────────
        self.api_frame = tk.Frame(f, bg="#f0f5fa", bd=1, relief="solid")
        # Pack it but hide via _toggle_api_fields
        self.api_frame.pack(fill="x", pady=4)

        api_inner = tk.Frame(self.api_frame, bg="#f0f5fa")
        api_inner.pack(fill="x", padx=8, pady=8)
        api_inner.columnconfigure(1, weight=1)

        tk.Label(api_inner, text="API Path", bg="#f0f5fa",
                 font=("Segoe UI", 9)).grid(row=0, column=0, sticky="w", pady=2)
        self.f_api_path = tk.StringVar()
        self.f_api_path_entry = ttk.Entry(api_inner, textvariable=self.f_api_path)
        self.f_api_path_entry.grid(row=0, column=1, sticky="ew", pady=2, padx=(8, 0))

        tk.Label(api_inner, text="API Port", bg="#f0f5fa",
                 font=("Segoe UI", 9)).grid(row=1, column=0, sticky="w", pady=2)
        self.f_api_port = tk.StringVar(value="443")
        self.f_api_port_entry = ttk.Entry(api_inner, textvariable=self.f_api_port, width=10)
        self.f_api_port_entry.grid(row=1, column=1, sticky="w", pady=2, padx=(8, 0))

        tk.Label(api_inner, text="API Auth", bg="#f0f5fa",
                 font=("Segoe UI", 9)).grid(row=2, column=0, sticky="w", pady=2)
        self.f_api_auth = tk.StringVar(value="basic")
        ttk.Combobox(api_inner, textvariable=self.f_api_auth, state="readonly",
            values=["basic", "bearer", "either"], width=10,
        ).grid(row=2, column=1, sticky="w", pady=2, padx=(8, 0))

        # ── Notes ─────────────────────────────────────────────
        tk.Label(f, text="Notes / Description", bg=COLORS["bg_white"],
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(8, 2))
        self.f_notes = tk.Text(f, height=3, font=("Segoe UI", 9),
                               bg="#fafafa", relief="solid", bd=1,
                               wrap="word")
        self.f_notes.pack(fill="x", pady=2)

        # ── Action buttons ────────────────────────────────────
        btn_row = tk.Frame(f, bg=COLORS["bg_white"])
        btn_row.pack(fill="x", pady=(10, 0))

        self.save_btn = tk.Button(
            btn_row, text="  ✓  Save Vendor",
            command=self._save_vendor,
            bg=COLORS["btn_success"], fg="white",
            font=("Segoe UI", 10, "bold"),
            relief="flat", padx=15, pady=6, cursor="hand2",
        )
        self.save_btn.pack(side="left", fill="x", expand=True, padx=(0, 4))

        self.clear_btn = tk.Button(
            btn_row, text="Clear",
            command=self._clear_form,
            bg=COLORS["text_gray"], fg="white",
            font=("Segoe UI", 9, "bold"),
            relief="flat", padx=15, pady=6, cursor="hand2",
        )
        self.clear_btn.pack(side="left")

        # Initially hide API fields
        self._toggle_api_fields()

    def _toggle_api_fields(self):
        if self.f_api.get():
            self.api_frame.pack(fill="x", pady=4, before=self._find_widget_before(self.api_frame))
        else:
            self.api_frame.pack_forget()

    def _find_widget_before(self, target):
        """Helper: find the widget that should come right before the API frame."""
        # Not used — we just re-pack the API frame at the right position
        return None

    def _populate_form(self, vendor, readonly: bool = False):
        self._set_form_readonly(readonly)
        self.f_key.set(vendor.key)
        self.f_label.set(vendor.label)
        self.f_netmiko.set(vendor.netmiko_type)
        self.f_commands.delete("1.0", "end")
        self.f_commands.insert("1.0", "\n".join(vendor.backup_commands))
        self.f_pre_commands.delete("1.0", "end")
        self.f_pre_commands.insert("1.0", "\n".join(vendor.pre_commands))
        self.f_ssh.set(vendor.ssh_supported)
        self.f_enable.set(vendor.supports_enable)
        self.f_api.set(vendor.api_supported)
        self.f_api_path.set(vendor.api_path or "")
        self.f_api_port.set(str(vendor.api_port))
        self.f_api_auth.set(vendor.api_auth_mode)
        self.f_active.set(vendor.active)
        self.f_notes.delete("1.0", "end")
        self.f_notes.insert("1.0", vendor.notes or "")
        self._toggle_api_fields()

        # Show doc reference if this vendor matches a template
        from vendor_templates import get_template
        t = get_template(vendor.key)
        if t:
            self.doc_ref_label.configure(text=f"📚 {t.doc_reference}")
        else:
            self.doc_ref_label.configure(text="(custom vendor — no template reference)")

    def _set_form_readonly(self, readonly: bool):
        state = "disabled" if readonly else "normal"
        self.f_key_entry.configure(state=state)
        for child in self.form_frame.winfo_children():
            self._set_widget_state_recursive(child, state)
        # Re-enable Save/Clear buttons (they're inside the form)
        self.save_btn.configure(state="disabled" if readonly else "normal")
        self.clear_btn.configure(state="disabled" if readonly else "normal")

    def _set_widget_state_recursive(self, widget, state):
        try:
            if isinstance(widget, (tk.Entry, ttk.Entry, tk.Text, ttk.Combobox,
                                  tk.Checkbutton, tk.Button)):
                widget.configure(state=state)
            elif isinstance(widget, (tk.Frame, tk.LabelFrame)):
                for child in widget.winfo_children():
                    self._set_widget_state_recursive(child, state)
        except tk.TclError:
            pass

    def _clear_form(self):
        self._set_form_readonly(False)
        self.f_key.set("")
        self.f_label.set("")
        self.f_netmiko.set("cisco_ios")
        self.f_commands.delete("1.0", "end")
        self.f_pre_commands.delete("1.0", "end")
        self.f_ssh.set(True)
        self.f_enable.set(False)
        self.f_api.set(False)
        self.f_api_path.set("")
        self.f_api_port.set("443")
        self.f_api_auth.set("basic")
        self.f_active.set(True)
        self.f_notes.delete("1.0", "end")
        self.doc_ref_label.configure(text="")
        self._toggle_api_fields()
        # Deselect template cards
        for label, state in self._template_cards.items():
            state[0].configure(bg=self.TEMPLATE_CARD_BG)
            state[1] = False
            for child in state[0].winfo_children():
                try:
                    child.configure(bg=self.TEMPLATE_CARD_BG)
                    for gc in child.winfo_children():
                        if not (isinstance(gc, tk.Label) and gc.cget("text") in (" API+SSH ", " SSH ")):
                            gc.configure(bg=self.TEMPLATE_CARD_BG, fg=self.TEMPLATE_CARD_FG)
                except tk.TclError:
                    pass
        # Deselect saved vendor list
        if hasattr(self, "vendor_tree"):
            self.vendor_tree.selection_remove(self.vendor_tree.selection())
        self.edit_btn.configure(state="disabled")
        self.delete_btn.configure(state="disabled")
        self.f_key_entry.focus_set()

    def _save_vendor(self):
        key = self.f_key.get().strip()
        label = self.f_label.get().strip()
        netmiko_type = self.f_netmiko.get().strip()
        commands_text = self.f_commands.get("1.0", "end").strip()
        pre_commands_text = self.f_pre_commands.get("1.0", "end").strip()
        notes = self.f_notes.get("1.0", "end").strip()

        if not key or not label:
            messagebox.showwarning("Validation", "Key and Label are required.", parent=self)
            return
        if not commands_text and not (self.f_api.get() and self.f_api_path.get().strip()):
            messagebox.showwarning("Validation",
                "At least one backup command is required (or an API path).",
                parent=self)
            return
        try:
            api_port = int(self.f_api_port.get().strip() or "443")
        except ValueError:
            messagebox.showwarning("Validation", "API port must be a number.", parent=self)
            return

        try:
            add_custom_vendor(
                data_dir=self.data_dir,
                key=key,
                label=label,
                netmiko_type=netmiko_type,
                backup_commands=commands_text.splitlines(),
                pre_commands=pre_commands_text.splitlines() if pre_commands_text else [],
                supports_enable=self.f_enable.get(),
                ssh_supported=self.f_ssh.get(),
                api_supported=self.f_api.get(),
                api_port=api_port,
                api_path=self.f_api_path.get().strip(),
                api_auth_mode=self.f_api_auth.get(),
                active=self.f_active.get(),
                notes=notes,
            )
        except ValueError as e:
            messagebox.showerror("Validation Error", str(e), parent=self)
            return

        self._log(f"Saved custom vendor: {label} ({key})", "success")
        self.vendors_changed = True
        self._refresh_vendor_list()
        self._clear_form()

    def _log(self, message, tag="info"):
        if hasattr(self.parent, "_log"):
            self.parent._log(message, tag)

    def _on_close(self):
        self.destroy()


# ════════════════════════════════════════════════════════════════
# DEVICE CREDENTIALS DIALOG (per-device override)
# ════════════════════════════════════════════════════════════════

class DeviceCredentialsDialog(tk.Toplevel):
    """Dialog to set per-device credentials for one or more selected devices.

    Lets the user override the shared/per-vendor credentials for specific
    devices that use local credentials (e.g. a router with a different
    admin password than the rest of the fleet).
    """

    def __init__(self, parent, manager: DeviceManager, devices: List[Dict]):
        super().__init__(parent)
        self.result = None
        self.manager = manager
        self.devices = devices

        self.title("Set Device-Specific Credentials")
        self.configure(bg=COLORS["bg_white"])
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.geometry("460x440")
        self.update_idletasks()
        x = parent.winfo_x() + (parent.winfo_width() - 460) // 2
        y = parent.winfo_y() + (parent.winfo_height() - 440) // 2
        if y < 30:
            y = 30
        self.geometry(f"+{x}+{y}")

        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_cancel)

    def _build_ui(self):
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=50)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header, text="  Device-Specific Credentials",
            bg=COLORS["bg_dark"], fg=COLORS["text_light"],
            font=("Segoe UI", 13, "bold"), anchor="w",
        ).pack(side="left", padx=10)

        intro = tk.Frame(self, bg=COLORS["bg_light"])
        intro.pack(fill="x")
        if len(self.devices) == 1:
            d = self.devices[0]
            label = f"  Device: {d['hostname']} ({d['ip_address']}) — {d['device_type'].title()}"
        else:
            label = f"  {len(self.devices)} device(s) selected — same credentials will be applied to all."
        tk.Label(
            intro, text=label,
            bg=COLORS["bg_light"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9, "bold"), justify="left",
        ).pack(anchor="w", padx=10, pady=8)

        form = tk.Frame(self, bg=COLORS["bg_white"])
        form.pack(fill="both", expand=True, padx=20, pady=10)

        # Pre-fill from the first device if it has existing per-device creds
        existing = self.manager.get_device_credentials(self.devices[0]["id"]) or {}
        self.use_var = tk.BooleanVar(value=existing.get("use_device_creds", False))
        self.user_var = tk.StringVar(value=existing.get("username", ""))
        self.pass_var = tk.StringVar(value=existing.get("password", ""))
        self.enable_var = tk.StringVar(value=existing.get("enable_password", ""))

        pad = {"padx": 10, "pady": 6}

        # Checkbox
        tk.Checkbutton(
            form, text="Use device-specific credentials (override shared/per-vendor)",
            variable=self.use_var,
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9, "bold"),
            activebackground=COLORS["bg_white"],
        ).grid(row=0, column=0, columnspan=2, sticky="w", **pad)

        tk.Label(
            form,
            text="For devices with local credentials different from the rest of the fleet.",
            bg=COLORS["bg_white"], fg=COLORS["text_gray"],
            font=("Segoe UI", 8),
        ).grid(row=1, column=0, columnspan=2, sticky="w", padx=10)

        # Username
        tk.Label(form, text="Username *", bg=COLORS["bg_white"],
                 font=("Segoe UI", 10)).grid(row=2, column=0, sticky="w", **pad)
        ttk.Entry(form, textvariable=self.user_var, width=28).grid(
            row=2, column=1, sticky="ew", **pad
        )

        # Password
        tk.Label(form, text="Password *", bg=COLORS["bg_white"],
                 font=("Segoe UI", 10)).grid(row=3, column=0, sticky="w", **pad)
        ttk.Entry(form, textvariable=self.pass_var, show="*", width=28).grid(
            row=3, column=1, sticky="ew", **pad
        )

        # Enable Password
        tk.Label(form, text="Enable Password", bg=COLORS["bg_white"],
                 font=("Segoe UI", 10)).grid(row=4, column=0, sticky="w", **pad)
        ttk.Entry(form, textvariable=self.enable_var, show="*", width=28).grid(
            row=4, column=1, sticky="ew", **pad
        )
        tk.Label(form, text="(Cisco enable secret, leave blank if not needed)",
                 bg=COLORS["bg_white"], fg=COLORS["text_gray"],
                 font=("Segoe UI", 8)).grid(row=5, column=1, sticky="w", padx=10)

        form.columnconfigure(1, weight=1)

        # Buttons
        btn_frame = tk.Frame(self, bg=COLORS["bg_white"])
        btn_frame.pack(fill="x", side="bottom", padx=20, pady=(0, 12))

        # "Clear Override" button (left side)
        tk.Button(
            btn_frame, text="Clear Override",
            command=self._clear_override,
            bg=COLORS["text_gray"], fg="white",
            font=("Segoe UI", 9),
            relief="flat", padx=15, pady=4, cursor="hand2",
        ).pack(side="left")

        ttk.Button(btn_frame, text="Cancel", command=self._on_cancel, width=12).pack(side="right", padx=(10, 0))
        tk.Button(
            btn_frame, text="Save",
            command=self._on_ok,
            bg=COLORS["btn_primary"], fg="white",
            font=("Segoe UI", 10, "bold"),
            relief="flat", padx=20, pady=4, cursor="hand2",
        ).pack(side="right")

    def _on_ok(self):
        use = self.use_var.get()
        user = self.user_var.get().strip()
        pwd = self.pass_var.get()
        enable = self.enable_var.get().strip()
        if use and (not user or not pwd):
            messagebox.showwarning("Validation",
                "Username and password are required when device-specific creds are enabled.",
                parent=self)
            return
        self.result = {
            "use_device_creds": use,
            "username": user,
            "password": pwd,
            "enable_password": enable,
        }
        self.destroy()

    def _clear_override(self):
        """Clear the per-device override so the device falls back to shared/per-vendor creds."""
        self.result = {
            "use_device_creds": False,
            "username": "",
            "password": "",
            "enable_password": "",
        }
        self.destroy()

    def _on_cancel(self):
        self.result = None
        self.destroy()


# ════════════════════════════════════════════════════════════════
# MAIN APPLICATION
# ════════════════════════════════════════════════════════════════

class NetworkBackupTool(tk.Tk):
    """Main application window."""

    def __init__(self):
        super().__init__()
        self.title("Network Backup Tool")
        self.geometry("1240x740")
        self.minsize(1050, 620)
        self.configure(bg=COLORS["bg_light"])

        # ── state ───────────────────────────────────────────────
        self.data_dir = os.path.dirname(os.path.abspath(sys.argv[0])) if getattr(sys, "frozen", False) else os.getcwd()
        self.backup_dir = os.path.join(self.data_dir, "backups")
        self.reports_dir = os.path.join(self.data_dir, "reports")

        # Load custom vendors from custom_vendors.json BEFORE building the UI
        # so the dropdowns are populated correctly.
        load_custom_vendors(self.data_dir)

        self.manager = DeviceManager(self.data_dir)
        self.engine = UnifiedBackupEngine(self.backup_dir)
        self.report_gen = UnifiedReportGenerator(self.reports_dir)

        # Push saved credentials into the engine
        self._sync_engine_credentials()

        self._backup_results: List[BackupResult] = []
        self._backup_running = False
        self._current_filter = "all"

        # ── build UI ────────────────────────────────────────────
        self._setup_styles()
        self._build_ui()
        self._refresh_tree()

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _sync_engine_credentials(self):
        """Push saved credentials (shared + per-vendor) into the engine.

        When single-credential mode is on, the shared SSH creds are also
        pushed into every firewall vendor slot that doesn't already have
        an explicit per-vendor override. This lets users with one common
        credential across their whole fleet avoid entering it N times.
        """
        shared = self.manager.get_shared_credentials()
        self.engine.set_shared_credentials_dict(shared)

        fw_creds = {}
        single_mode = self.manager.is_single_credential_mode()
        for v in active_vendors():
            c = self.manager.get_fw_credentials(v.key)
            if c and (c.get("username") or c.get("api_token")):
                # Explicit per-vendor override — use it
                fw_creds[v.key] = c
            elif single_mode and shared.get("username") and shared.get("password"):
                # Single-credential mode: fall back to shared creds for
                # this firewall vendor. Map shared fields to the firewall
                # cred schema (username / password / enable_password / api_token).
                # Note: api_token is intentionally left empty — single-credential
                # mode covers Basic-auth / SSH scenarios. For Bearer-token-only
                # vendors the user must still use the per-vendor dialog.
                fw_creds[v.key] = {
                    "username": shared.get("username", ""),
                    "password": shared.get("password", ""),
                    "enable_password": shared.get("enable_password", ""),
                    "api_token": "",  # don't auto-fill tokens from shared creds
                }
        self.engine.set_all_fw_credentials(fw_creds)

    # ════════════════════════════════════════════════════════════
    # STYLES
    # ════════════════════════════════════════════════════════════
    def _setup_styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview",
            background=COLORS["bg_white"],
            foreground=COLORS["text_dark"],
            fieldbackground=COLORS["bg_white"],
            rowheight=28,
            font=("Segoe UI", 9),
        )
        style.configure("Treeview.Heading",
            background=COLORS["bg_dark"],
            foreground=COLORS["text_light"],
            font=("Segoe UI", 10, "bold"),
            relief="flat",
        )
        style.configure("Green.Horizontal.TProgressbar",
            troughcolor=COLORS["bg_light"],
            background=COLORS["success"],
            thickness=20,
        )

    # ════════════════════════════════════════════════════════════
    # UI BUILD
    # ════════════════════════════════════════════════════════════
    def _build_ui(self):
        # ── Top header ──────────────────────────────────────────
        header = tk.Frame(self, bg=COLORS["bg_dark"], height=55)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header, text="  Network Backup Tool",
            bg=COLORS["bg_dark"], fg=COLORS["text_light"],
            font=("Segoe UI", 16, "bold"), anchor="w",
        ).pack(side="left", padx=10)
        self.cred_label = tk.Label(
            header, text="  No credentials set",
            bg=COLORS["bg_dark"], fg="#ff9999",
            font=("Segoe UI", 9), anchor="e",
        )
        self.cred_label.pack(side="right", padx=15)

        # ── Toolbar ─────────────────────────────────────────────
        toolbar = tk.Frame(self, bg=COLORS["bg_white"], height=45)
        toolbar.pack(fill="x")
        toolbar.pack_propagate(False)

        tk.Button(toolbar, text="+ Add Device", command=self._add_device,
            bg=COLORS["btn_primary"], fg="white", font=("Segoe UI", 9, "bold"),
            relief="flat", padx=14, pady=3, cursor="hand2",
        ).pack(side="left", padx=(10, 5), pady=6)

        tk.Button(toolbar, text="Edit", command=self._edit_device,
            bg=COLORS["bg_medium"], fg="white", font=("Segoe UI", 9),
            relief="flat", padx=14, pady=3, cursor="hand2",
        ).pack(side="left", padx=3, pady=6)

        tk.Button(toolbar, text="Remove", command=self._remove_device,
            bg=COLORS["btn_danger"], fg="white", font=("Segoe UI", 9),
            relief="flat", padx=14, pady=3, cursor="hand2",
        ).pack(side="left", padx=3, pady=6)

        tk.Button(toolbar, text="Set Device Creds",
            command=self._set_device_credentials,
            bg=COLORS["bg_medium"], fg="white", font=("Segoe UI", 9),
            relief="flat", padx=14, pady=3, cursor="hand2",
        ).pack(side="left", padx=3, pady=6)

        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=10, pady=8)

        # Two credential buttons: shared (router/switch) + per-vendor (firewall)
        tk.Button(toolbar, text="Set SSH Creds (Router/Switch)",
            command=self._set_shared_credentials,
            bg=COLORS["btn_warning"], fg="white", font=("Segoe UI", 9),
            relief="flat", padx=14, pady=3, cursor="hand2",
        ).pack(side="left", padx=3, pady=6)

        tk.Button(toolbar, text="Set Firewall Creds (per vendor)",
            command=self._set_fw_credentials,
            bg=COLORS["btn_warning"], fg="white", font=("Segoe UI", 9),
            relief="flat", padx=14, pady=3, cursor="hand2",
        ).pack(side="left", padx=3, pady=6)

        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=10, pady=8)

        tk.Button(toolbar, text="Import CSV", command=self._import_csv,
            bg=COLORS["text_gray"], fg="white", font=("Segoe UI", 9),
            relief="flat", padx=14, pady=3, cursor="hand2",
        ).pack(side="left", padx=3, pady=6)

        tk.Button(toolbar, text="Export CSV", command=self._export_csv,
            bg=COLORS["text_gray"], fg="white", font=("Segoe UI", 9),
            relief="flat", padx=14, pady=3, cursor="hand2",
        ).pack(side="left", padx=3, pady=6)

        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=10, pady=8)

        tk.Button(toolbar, text="Manage Vendors",
            command=self._manage_vendors,
            bg=COLORS["btn_warning"], fg="white", font=("Segoe UI", 9, "bold"),
            relief="flat", padx=14, pady=3, cursor="hand2",
        ).pack(side="left", padx=3, pady=6)

        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=10, pady=8)

        tk.Button(toolbar, text="Launch Operations",
            command=self._launch_operations,
            bg=COLORS["btn_success"], fg="white", font=("Segoe UI", 9, "bold"),
            relief="flat", padx=14, pady=3, cursor="hand2",
        ).pack(side="left", padx=3, pady=6)

        self.count_label = tk.Label(
            toolbar, text="0 devices", bg=COLORS["bg_white"],
            fg=COLORS["text_gray"], font=("Segoe UI", 9),
        )
        self.count_label.pack(side="right", padx=15)

        # ── Main content ────────────────────────────────────────
        # Pack the right panel FIRST (side="right") so the left panel's
        # expand=True doesn't steal all the horizontal space. This is the
        # standard tkinter side-anchoring pattern.
        content = tk.Frame(self, bg=COLORS["bg_light"])
        content.pack(fill="both", expand=True, padx=10, pady=5)

        # Right panel (fixed width, packed first)
        right_panel = tk.Frame(content, bg=COLORS["bg_white"], width=340)
        right_panel.pack(side="right", fill="y")
        right_panel.pack_propagate(False)

        # Left panel (fills remaining space, packed second)
        left_panel = tk.Frame(content, bg=COLORS["bg_white"], bd=0)
        left_panel.pack(side="left", fill="both", expand=True, padx=(0, 5))

        # Filter buttons row
        filter_frame = tk.Frame(left_panel, bg=COLORS["bg_white"])
        filter_frame.pack(fill="x", padx=10, pady=(8, 4))

        self.filter_buttons = {}
        filter_defs = [
            ("All", "all"),
            ("Routers", "router"),
            ("Switches", "switch"),
            ("Firewalls", "firewall"),
            ("Failed", "failed"),
        ]
        for label, fkey in filter_defs:
            btn = tk.Button(
                filter_frame, text=label,
                command=lambda k=fkey: self._set_filter(k),
                bg=COLORS["bg_medium"] if fkey == "all" else COLORS["bg_light"],
                fg="white" if fkey == "all" else COLORS["text_dark"],
                font=("Segoe UI", 9, "bold"),
                relief="flat", padx=12, pady=2, cursor="hand2",
            )
            btn.pack(side="left", padx=(0, 4))
            self.filter_buttons[fkey] = btn

        # Checkbox controls row
        check_frame = tk.Frame(left_panel, bg=COLORS["bg_white"])
        check_frame.pack(fill="x", padx=10, pady=(2, 4))
        tk.Button(check_frame, text="Select All", command=self._select_all,
            bg=COLORS["btn_primary"], fg="white", font=("Segoe UI", 9, "bold"),
            relief="flat", padx=12, pady=2, cursor="hand2",
        ).pack(side="left", padx=(0, 4))
        tk.Button(check_frame, text="Clear Selection", command=self._clear_selection,
            bg=COLORS["text_gray"], fg="white", font=("Segoe UI", 9),
            relief="flat", padx=12, pady=2, cursor="hand2",
        ).pack(side="left", padx=4)
        self.selected_count_label = tk.Label(
            check_frame, text="0 selected", bg=COLORS["bg_white"],
            fg=COLORS["text_dark"], font=("Segoe UI", 9, "bold"),
        )
        self.selected_count_label.pack(side="left", padx=12)

        # ── Search & filter bar ─────────────────────────────────
        # Provides live filtering across hostname, IP, device type,
        # vendor, location, and last status. The search is case-
        # insensitive substring match; the dropdowns are exact match.
        # All filters are AND-combined on top of the active filter
        # button (All / Routers / Switches / Firewalls / Failed).
        search_frame = tk.Frame(left_panel, bg=COLORS["bg_white"])
        search_frame.pack(fill="x", padx=10, pady=(2, 4))

        # Search entry (hostname / IP substring)
        tk.Label(search_frame, text="Search:",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9, "bold"),
        ).pack(side="left", padx=(0, 4))
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *a: self._apply_search_filter())
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=22)
        search_entry.pack(side="left", padx=(0, 8))
        # Placeholder-style hint via tooltip-like label
        tk.Label(search_frame, text="(hostname or IP)",
            bg=COLORS["bg_white"], fg=COLORS["text_gray"],
            font=("Segoe UI", 8),
        ).pack(side="left", padx=(0, 12))

        # Device Type dropdown
        tk.Label(search_frame, text="Type:",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9),
        ).pack(side="left", padx=(0, 2))
        self.search_type_var = tk.StringVar(value="Any")
        type_combo = ttk.Combobox(search_frame, textvariable=self.search_type_var,
            values=["Any", "Router", "Switch", "Firewall"],
            state="readonly", width=9)
        type_combo.pack(side="left", padx=(0, 8))
        type_combo.bind("<<ComboboxSelected>>", lambda e: self._apply_search_filter())

        # Vendor dropdown
        tk.Label(search_frame, text="Vendor:",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9),
        ).pack(side="left", padx=(0, 2))
        self.search_vendor_var = tk.StringVar(value="Any")
        # Vendor dropdown is populated dynamically in _refresh_vendor_filter_options
        self.search_vendor_combo = ttk.Combobox(search_frame, textvariable=self.search_vendor_var,
            values=["Any"], state="readonly", width=14)
        self.search_vendor_combo.pack(side="left", padx=(0, 8))
        self.search_vendor_combo.bind("<<ComboboxSelected>>", lambda e: self._apply_search_filter())

        # Location dropdown
        tk.Label(search_frame, text="Location:",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9),
        ).pack(side="left", padx=(0, 2))
        self.search_location_var = tk.StringVar(value="Any")
        self.search_location_combo = ttk.Combobox(search_frame, textvariable=self.search_location_var,
            values=["Any"], state="readonly", width=12)
        self.search_location_combo.pack(side="left", padx=(0, 8))
        self.search_location_combo.bind("<<ComboboxSelected>>", lambda e: self._apply_search_filter())

        # Status dropdown
        tk.Label(search_frame, text="Status:",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 9),
        ).pack(side="left", padx=(0, 2))
        self.search_status_var = tk.StringVar(value="Any")
        status_combo = ttk.Combobox(search_frame, textvariable=self.search_status_var,
            values=["Any", "Success", "Failed", "Never"],
            state="readonly", width=9)
        status_combo.pack(side="left", padx=(0, 8))
        status_combo.bind("<<ComboboxSelected>>", lambda e: self._apply_search_filter())

        # Clear-filters button
        tk.Button(search_frame, text="Clear Filters",
            command=self._clear_search_filters,
            bg=COLORS["text_gray"], fg="white", font=("Segoe UI", 8, "bold"),
            relief="flat", padx=8, pady=2, cursor="hand2",
        ).pack(side="left", padx=(4, 0))

        # Result-count label (shows how many rows match the current filters)
        self.search_result_label = tk.Label(
            search_frame, text="", bg=COLORS["bg_white"],
            fg=COLORS["text_gray"], font=("Segoe UI", 8, "italic"),
        )
        self.search_result_label.pack(side="right", padx=(8, 0))

        # Treeview
        tree_frame = tk.Frame(left_panel, bg=COLORS["bg_white"])
        tree_frame.pack(fill="both", expand=True, padx=10, pady=4)

        columns = ("select", "hostname", "ip", "type", "vendor", "location", "port", "status", "last_backup")
        self.tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="none")

        self.tree.heading("select", text="Select")
        self.tree.heading("hostname", text="Hostname")
        self.tree.heading("ip", text="IP Address")
        self.tree.heading("type", text="Type")
        self.tree.heading("vendor", text="Vendor")
        self.tree.heading("location", text="Location")
        self.tree.heading("port", text="Port")
        self.tree.heading("status", text="Last Status")
        self.tree.heading("last_backup", text="Last Backup Time")

        self.tree.column("select", width=50, minwidth=40, anchor="center", stretch=False)
        self.tree.column("hostname", width=130, minwidth=100)
        self.tree.column("ip", width=120, minwidth=100)
        self.tree.column("type", width=70, minwidth=50, anchor="center")
        self.tree.column("vendor", width=100, minwidth=70)
        self.tree.column("location", width=110, minwidth=80)
        self.tree.column("port", width=50, minwidth=40, anchor="center", stretch=False)
        self.tree.column("status", width=80, minwidth=70, anchor="center")
        self.tree.column("last_backup", width=140, minwidth=120)

        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.tree.tag_configure("success", foreground=COLORS["success"])
        self.tree.tag_configure("failed", foreground=COLORS["fail"])
        self.tree.tag_configure("pending", foreground=COLORS["text_gray"])
        self.tree.tag_configure("alt", background=COLORS["row_alt"])
        self.tree.tag_configure("checked", foreground=COLORS["btn_primary"])

        self._item_to_device: Dict[str, Dict] = {}
        self._checked_items: set = set()

        self.tree.bind("<Button-1>", self._on_tree_click)
        self.tree.bind("<Double-1>", self._on_tree_double_click)

        # ── Right panel content (right_panel was created earlier) ──
        # Buttons use fill="x" (no explicit width=) so they stretch to
        # fit the panel — avoids the 1x1 collapse bug that happens when
        # width=N (char-based) conflicts with padx and pack_propagate.

        tk.Label(
            right_panel, text="Backup Actions",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 12, "bold"),
        ).pack(pady=(15, 8), padx=15, anchor="w")

        tk.Button(right_panel, text="Backup All Devices",
            command=self._backup_all,
            bg=COLORS["btn_success"], fg="white",
            font=("Segoe UI", 11, "bold"), relief="flat",
            padx=20, pady=8, cursor="hand2",
        ).pack(fill="x", padx=15, pady=4)

        tk.Button(right_panel, text="Backup Selected (one-tap multi)",
            command=self._backup_selected,
            bg=COLORS["btn_primary"], fg="white",
            font=("Segoe UI", 10), relief="flat",
            padx=20, pady=6, cursor="hand2",
        ).pack(fill="x", padx=15, pady=4)

        tk.Button(right_panel, text="Retry Failed",
            command=self._retry_failed,
            bg=COLORS["btn_warning"], fg="white",
            font=("Segoe UI", 10), relief="flat",
            padx=20, pady=6, cursor="hand2",
        ).pack(fill="x", padx=15, pady=4)

        ttk.Separator(right_panel, orient="horizontal").pack(fill="x", padx=15, pady=12)

        tk.Button(right_panel, text="View Last Diff",
            command=self._view_last_diff,
            bg=COLORS["bg_dark"], fg="white",
            font=("Segoe UI", 10), relief="flat",
            padx=20, pady=6, cursor="hand2",
        ).pack(fill="x", padx=15, pady=4)

        tk.Button(right_panel, text="Generate PDF Report",
            command=self._generate_report,
            bg=COLORS["bg_dark"], fg="white",
            font=("Segoe UI", 10), relief="flat",
            padx=20, pady=6, cursor="hand2",
        ).pack(fill="x", padx=15, pady=4)

        tk.Button(right_panel, text="Open Backup Folder",
            command=self._open_backup_folder,
            bg=COLORS["text_gray"], fg="white",
            font=("Segoe UI", 9), relief="flat",
            padx=20, pady=4, cursor="hand2",
        ).pack(fill="x", padx=15, pady=4)

        tk.Button(right_panel, text="Open Reports Folder",
            command=self._open_reports_folder,
            bg=COLORS["text_gray"], fg="white",
            font=("Segoe UI", 9), relief="flat",
            padx=20, pady=4, cursor="hand2",
        ).pack(fill="x", padx=15, pady=4)

        ttk.Separator(right_panel, orient="horizontal").pack(fill="x", padx=15, pady=12)

        self.progress_label = tk.Label(
            right_panel, text="Ready",
            bg=COLORS["bg_white"], fg=COLORS["text_gray"],
            font=("Segoe UI", 9),
        )
        self.progress_label.pack(padx=15, anchor="w")

        self.progress_bar = ttk.Progressbar(
            right_panel, mode="determinate",
            style="Green.Horizontal.TProgressbar",
        )
        self.progress_bar.pack(fill="x", padx=15, pady=(4, 10))

        tk.Label(
            right_panel, text="Activity Log",
            bg=COLORS["bg_white"], fg=COLORS["text_dark"],
            font=("Segoe UI", 10, "bold"),
        ).pack(padx=15, anchor="w", pady=(0, 4))

        log_frame = tk.Frame(right_panel, bg=COLORS["bg_white"])
        log_frame.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        self.log_text = tk.Text(
            log_frame, wrap="word", font=("Consolas", 8),
            bg="#f8f8f8", fg=COLORS["text_dark"],
            relief="flat", state="disabled",
        )
        log_scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scroll.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        log_scroll.pack(side="right", fill="y")

        self.log_text.tag_configure("success", foreground=COLORS["success"])
        self.log_text.tag_configure("error", foreground=COLORS["fail"])
        self.log_text.tag_configure("info", foreground=COLORS["bg_medium"])
        self.log_text.tag_configure("warning", foreground=COLORS["btn_warning"])
        self.log_text.tag_configure("diff", foreground="#8b008b")

        self.status_bar = tk.Label(
            self, text="Ready | Configure credentials before backup",
            bg=COLORS["bg_dark"], fg=COLORS["text_light"],
            font=("Segoe UI", 9), anchor="w", padx=10,
        )
        self.status_bar.pack(fill="x", side="bottom")

        self._update_credential_indicator()

    # ════════════════════════════════════════════════════════════
    # LOGGING
    # ════════════════════════════════════════════════════════════
    def _log(self, message: str, tag: str = "info"):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.configure(state="normal")
        self.log_text.insert("end", f"[{timestamp}] {message}\n", tag)
        self.log_text.see("end")
        # Fix M1: Truncate log to last 5000 lines to prevent unbounded memory growth
        line_count = int(self.log_text.index("end-1c").split(".")[0])
        if line_count > 5000:
            self.log_text.delete("1.0", f"{line_count - 5000}.0")
        self.log_text.configure(state="disabled")

    def _update_status(self, text: str):
        self.status_bar.configure(text=text)

    def _update_credential_indicator(self):
        parts = []
        if self.manager.has_shared_credentials():
            parts.append("SSH: ✓")
        else:
            parts.append("SSH: ✗")

        # Show single-credential mode status
        if self.manager.is_single_credential_mode() and self.manager.has_shared_credentials():
            parts.append("Single-cred: ON")

        fw_configured = self.manager.list_configured_fw_vendors()
        if fw_configured:
            parts.append(f"Firewall: {len(fw_configured)} override(s)")
        elif self.manager.is_single_credential_mode() and self.manager.has_shared_credentials():
            parts.append("Firewall: via shared")
        else:
            parts.append("Firewall: ✗")

        text = "  " + "  |  ".join(parts)
        if self.manager.has_shared_credentials() or fw_configured:
            self.cred_label.configure(text=text, fg="#99ff99")
        else:
            self.cred_label.configure(text=text, fg="#ff9999")

    # ════════════════════════════════════════════════════════════
    # DEVICE CRUD
    # ════════════════════════════════════════════════════════════
    def _add_device(self):
        dialog = AddDeviceDialog(
            self, existing_locations=self.manager.get_locations(),
        )
        self.wait_window(dialog)
        if dialog.result:
            self.manager.add_device(**dialog.result)
            r = dialog.result
            self._log(
                f"Added device: {r['hostname']} ({r['ip_address']}) — "
                f"{r['device_type'].title()} / {r['vendor']}",
                "success",
            )
            self._refresh_tree()

    def _edit_device(self):
        device = self._get_single_selected()
        if not device:
            messagebox.showinfo("Info", "Please check one device (Select column) to edit.", parent=self)
            return
        if len(self._checked_items) > 1:
            messagebox.showinfo("Info", "Please check only ONE device to edit.", parent=self)
            return

        dialog = AddDeviceDialog(
            self, existing_locations=self.manager.get_locations(),
            edit_device=device,
        )
        self.wait_window(dialog)
        if dialog.result:
            self.manager.update_device(device["id"], **dialog.result)
            self._log(f"Updated device: {dialog.result['hostname']}", "info")
            self._refresh_tree()

    def _remove_device(self):
        selected = self._get_selected_devices()
        if not selected:
            messagebox.showinfo("Info", "Please check one or more devices to remove.", parent=self)
            return
        if not messagebox.askyesno(
            "Confirm Removal",
            f"Remove {len(selected)} device(s)? This cannot be undone.",
            parent=self,
        ):
            return
        for d in selected:
            self.manager.remove_device(d["id"])
            self._log(f"Removed device: {d['hostname']} ({d['ip_address']})", "warning")
        self._checked_items.clear()
        self._refresh_tree()

    # ════════════════════════════════════════════════════════════
    # CREDENTIALS
    # ════════════════════════════════════════════════════════════
    def _set_shared_credentials(self):
        dialog = SharedCredentialsDialog(self, self.manager)
        self.wait_window(dialog)
        if dialog.result:
            self.manager.set_shared_credentials(**dialog.result)
            single_mode = dialog.result.get("use_single_credential", False)
            if single_mode:
                self._log(
                    f"Shared SSH credentials saved (user: {dialog.result['username']}) — "
                    f"single-credential mode ON (applies to all devices)",
                    "success",
                )
            else:
                self._log(
                    f"Shared SSH credentials saved (user: {dialog.result['username']}) — "
                    f"routers/switches only",
                    "success",
                )
            self._sync_engine_credentials()
            self._update_credential_indicator()
            self._update_status("Shared SSH credentials updated")

    def _set_fw_credentials(self):
        dialog = FirewallCredentialsDialog(self, self.manager)
        self.wait_window(dialog)
        if dialog.result:
            for vkey, creds_dict in dialog.result.items():
                self.manager.set_fw_credentials_dict(vkey, creds_dict)
                self._log(
                    f"Firewall credentials saved for {fw_vendor_label(vkey)} "
                    f"(user={creds_dict['username'] or '-'}, "
                    f"api_token={'yes' if creds_dict['api_token'] else 'no'})",
                    "success",
                )
            self._sync_engine_credentials()
            self._update_credential_indicator()
            self._update_status("Per-vendor firewall credentials updated")

    def _set_device_credentials(self):
        """Open the Device Credentials dialog for the selected device(s)."""
        devices = self._get_selected_devices()
        if not devices:
            messagebox.showinfo(
                "Info",
                "Please check one or more devices (Select column) to set device-specific credentials.",
                parent=self,
            )
            return
        dialog = DeviceCredentialsDialog(self, self.manager, devices)
        self.wait_window(dialog)
        if dialog.result:
            use = dialog.result["use_device_creds"]
            user = dialog.result["username"]
            pwd = dialog.result["password"]
            enable = dialog.result["enable_password"]
            for d in devices:
                self.manager.set_device_credentials(
                    d["id"], user, pwd, enable, use_device_creds=use,
                )
            if use:
                if len(devices) == 1:
                    self._log(
                        f"Device-specific credentials set for {devices[0]['hostname']} "
                        f"(user: {user})",
                        "success",
                    )
                else:
                    self._log(
                        f"Device-specific credentials set for {len(devices)} device(s) "
                        f"(user: {user})",
                        "success",
                    )
            else:
                if len(devices) == 1:
                    self._log(
                        f"Cleared device-specific override for {devices[0]['hostname']} "
                        f"— will use shared/per-vendor creds",
                        "info",
                    )
                else:
                    self._log(
                        f"Cleared device-specific override for {len(devices)} device(s)",
                        "info",
                    )
            self._refresh_tree()

    # ════════════════════════════════════════════════════════════
    # FILTER + TREE
    # ════════════════════════════════════════════════════════════
    def _set_filter(self, filter_type: str):
        self._current_filter = filter_type
        self._refresh_tree()
        for fkey, btn in self.filter_buttons.items():
            if fkey == filter_type:
                btn.configure(bg=COLORS["bg_medium"], fg="white")
            else:
                btn.configure(bg=COLORS["bg_light"], fg=COLORS["text_dark"])

    def _refresh_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        if self._current_filter == "failed":
            devices = [d for d in self.manager.get_all_devices() if d.get("last_status") == "failed"]
        elif self._current_filter == "all":
            devices = self.manager.get_all_devices()
        else:
            devices = self.manager.get_by_type(self._current_filter)

        # Refresh the dynamic vendor/location dropdown options so the user
        # can only pick values that actually exist in the current dataset.
        self._refresh_search_filter_options(devices)

        # Apply the search/filter bar on top of the active filter button.
        # This narrows the list further by hostname/IP substring + the
        # Type/Vendor/Location/Status dropdowns.
        filtered = self._filter_devices_by_search(devices)

        self._item_to_device.clear()
        previously_checked = set()
        for item_id in self._checked_items:
            d = self._item_to_device.get(item_id)
            if d:
                previously_checked.add((d["hostname"], d["ip_address"]))
        self._checked_items.clear()

        for i, device in enumerate(filtered):
            status = device.get("last_status")
            if status == "success":
                status_text = "SUCCESS"
                tag = ("success",)
            elif status == "failed":
                status_text = "FAILED"
                tag = ("failed",)
            else:
                status_text = "Never"
                tag = ("pending",)
            row_tag = tag + (("alt",) if i % 2 == 1 else ())

            is_checked = (device["hostname"], device["ip_address"]) in previously_checked
            check_symbol = CHECK_ON if is_checked else CHECK_OFF
            if is_checked:
                row_tag = row_tag + ("checked",)

            # Vendor display: firewall uses vendor_label, router/switch uses netmiko name
            dtype = device["device_type"]
            vendor_key = device.get("vendor", "")
            if dtype == "firewall":
                vendor_display = fw_vendor_label(vendor_key)
            else:
                vendor_display = RS_VENDOR_KEY_TO_NAME.get(vendor_key, vendor_key)

            last_backup = device.get("last_backup") or "—"
            if last_backup and last_backup != "—" and "T" in last_backup:
                try:
                    last_backup = last_backup.replace("T", " ").split(".")[0]
                except Exception:
                    pass

            item_id = self.tree.insert("", "end", values=(
                check_symbol,
                device["hostname"],
                device["ip_address"],
                dtype.title(),
                vendor_display,
                device.get("location", "N/A"),
                device.get("port", 22),
                status_text,
                last_backup,
            ), tags=row_tag)
            self._item_to_device[item_id] = device
            if is_checked:
                self._checked_items.add(item_id)

        total = self.manager.device_count()
        routers = len(self.manager.get_routers())
        switches = len(self.manager.get_switches())
        firewalls = len(self.manager.get_firewalls())
        self.count_label.configure(
            text=f"{total} devices ({routers}R / {switches}S / {firewalls}F)"
        )

        # Update the "showing N of M" result-count label
        if hasattr(self, "search_result_label"):
            shown = len(filtered)
            total_in_filter = len(devices)
            if shown == total_in_filter:
                self.search_result_label.configure(text=f"showing {shown}")
            else:
                self.search_result_label.configure(
                    text=f"showing {shown} of {total_in_filter}"
                )

        self._update_selected_count()

    # ── search/filter helpers ──────────────────────────────────
    def _refresh_search_filter_options(self, devices: List[Dict]):
        """Populate the Vendor and Location dropdowns with values that
        actually appear in the current device list. Keeps the dropdowns
        short and relevant."""
        if not hasattr(self, "search_vendor_combo"):
            return  # UI not built yet (called during __init__)

        # Build vendor display names present in the dataset
        vendor_names = set()
        for d in devices:
            dtype = d["device_type"]
            vkey = d.get("vendor", "")
            if dtype == "firewall":
                vendor_names.add(fw_vendor_label(vkey))
            else:
                vendor_names.add(RS_VENDOR_KEY_TO_NAME.get(vkey, vkey))

        # Build location names present in the dataset
        locations = set()
        for d in devices:
            loc = d.get("location", "")
            if loc:
                locations.add(loc)

        # Preserve the current selection (or fall back to "Any")
        current_vendor = self.search_vendor_var.get()
        current_location = self.search_location_var.get()

        vendor_values = ["Any"] + sorted(vendor_names)
        location_values = ["Any"] + sorted(locations)

        self.search_vendor_combo.configure(values=vendor_values)
        self.search_location_combo.configure(values=location_values)

        # If the current selection is no longer in the list, reset to "Any"
        if current_vendor not in vendor_values:
            self.search_vendor_var.set("Any")
        if current_location not in location_values:
            self.search_location_var.set("Any")

    def _filter_devices_by_search(self, devices: List[Dict]) -> List[Dict]:
        """Apply the search bar + dropdown filters to a device list.

        Combines (AND):
          - substring match on hostname OR IP (case-insensitive)
          - exact match on device type (if dropdown != "Any")
          - exact match on vendor display name (if dropdown != "Any")
          - exact match on location (if dropdown != "Any")
          - exact match on last status (if dropdown != "Any")
        """
        # During initial UI construction the attributes don't exist yet.
        if not hasattr(self, "search_var"):
            return devices

        query = self.search_var.get().strip().lower()
        type_filter = self.search_type_var.get()
        vendor_filter = self.search_vendor_var.get()
        location_filter = self.search_location_var.get()
        status_filter = self.search_status_var.get()

        out = []
        for d in devices:
            # Hostname / IP substring match
            if query:
                hostname = d.get("hostname", "").lower()
                ip = d.get("ip_address", "").lower()
                if query not in hostname and query not in ip:
                    continue

            # Device type
            if type_filter and type_filter != "Any":
                if d["device_type"] != type_filter.lower():
                    continue

            # Vendor (compare display name)
            if vendor_filter and vendor_filter != "Any":
                dtype = d["device_type"]
                vkey = d.get("vendor", "")
                if dtype == "firewall":
                    v_display = fw_vendor_label(vkey)
                else:
                    v_display = RS_VENDOR_KEY_TO_NAME.get(vkey, vkey)
                if v_display != vendor_filter:
                    continue

            # Location
            if location_filter and location_filter != "Any":
                if d.get("location", "") != location_filter:
                    continue

            # Last status
            if status_filter and status_filter != "Any":
                actual = d.get("last_status")
                if status_filter == "Success" and actual != "success":
                    continue
                if status_filter == "Failed" and actual != "failed":
                    continue
                if status_filter == "Never" and actual not in (None, ""):
                    continue

            out.append(d)
        return out

    def _apply_search_filter(self):
        """Re-render the tree with the current search/filter values."""
        # Guard against being called before the tree is built
        if not hasattr(self, "tree"):
            return
        self._refresh_tree()

    def _clear_search_filters(self):
        """Reset all search/filter widgets to their default (no filter)."""
        if hasattr(self, "search_var"):
            self.search_var.set("")
        if hasattr(self, "search_type_var"):
            self.search_type_var.set("Any")
        if hasattr(self, "search_vendor_var"):
            self.search_vendor_var.set("Any")
        if hasattr(self, "search_location_var"):
            self.search_location_var.set("Any")
        if hasattr(self, "search_status_var"):
            self.search_status_var.set("Any")
        self._apply_search_filter()

    # ── checkbox handlers ──────────────────────────────────────
    def _on_tree_click(self, event):
        if self.tree.identify("region", event.x, event.y) != "cell":
            return
        if self.tree.identify_column(event.x) != "#1":
            return
        item_id = self.tree.identify_row(event.y)
        if not item_id:
            return
        self._toggle_check(item_id)

    def _on_tree_double_click(self, event):
        item_id = self.tree.identify_row(event.y)
        if not item_id:
            return
        d = self._item_to_device.get(item_id)
        if not d:
            return
        for r in reversed(self._backup_results):
            if r.device_id == d["id"]:
                self._show_diff_dialog(r)
                return
        messagebox.showinfo(
            "No Backup Yet",
            f"No backup result available for {d['hostname']}.\n"
            "Run a backup first to view its diff.",
            parent=self,
        )

    def _toggle_check(self, item_id):
        if item_id in self._checked_items:
            self._checked_items.discard(item_id)
            new_symbol = CHECK_OFF
            current_tags = self.tree.item(item_id, "tags")
            new_tags = tuple(t for t in current_tags if t != "checked")
        else:
            self._checked_items.add(item_id)
            new_symbol = CHECK_ON
            current_tags = self.tree.item(item_id, "tags")
            new_tags = current_tags + ("checked",) if "checked" not in current_tags else current_tags
        values = list(self.tree.item(item_id, "values"))
        if values:
            values[0] = new_symbol
            self.tree.item(item_id, values=values, tags=new_tags)
        self._update_selected_count()

    def _select_all(self):
        for item_id in self.tree.get_children():
            if item_id not in self._checked_items:
                self._checked_items.add(item_id)
                values = list(self.tree.item(item_id, "values"))
                if values:
                    values[0] = CHECK_ON
                    current_tags = self.tree.item(item_id, "tags")
                    if "checked" not in current_tags:
                        current_tags = current_tags + ("checked",)
                    self.tree.item(item_id, values=values, tags=current_tags)
        self._update_selected_count()

    def _clear_selection(self):
        for item_id in list(self._checked_items):
            values = list(self.tree.item(item_id, "values"))
            if values:
                values[0] = CHECK_OFF
                current_tags = self.tree.item(item_id, "tags")
                new_tags = tuple(t for t in current_tags if t != "checked")
                self.tree.item(item_id, values=values, tags=new_tags)
        self._checked_items.clear()
        self._update_selected_count()

    def _update_selected_count(self):
        if hasattr(self, "selected_count_label"):
            n = len(self._checked_items)
            self.selected_count_label.configure(text=f"{n} selected")

    def _get_selected_devices(self) -> List[Dict]:
        out = []
        for item_id in self._checked_items:
            d = self._item_to_device.get(item_id)
            if d:
                out.append(d)
        return out

    def _get_single_selected(self) -> Optional[Dict]:
        for item_id in self._checked_items:
            return self._item_to_device.get(item_id)
        return None

    # ════════════════════════════════════════════════════════════
    # BACKUP OPERATIONS
    # ════════════════════════════════════════════════════════════
    def _check_credentials_for(self, devices: List[Dict]) -> bool:
        """Ensure every device has the right kind of credentials set.

        Credential resolution order (highest priority first):
          1. Per-device credentials (if use_device_creds=True)
          2. Per-vendor firewall credentials (for firewalls)
          3. Single-credential mode shared creds (if enabled)
          4. Shared SSH credentials (for routers/switches)

        When single-credential mode is on, firewalls without an explicit
        per-vendor override will use the shared SSH creds — so they pass
        the check as long as shared creds exist.
        """
        missing_shared = False
        missing_fw_vendors = set()
        single_mode = self.manager.is_single_credential_mode()
        has_shared = self.manager.has_shared_credentials()

        for d in devices:
            # Per-device creds override everything else
            if d.get("use_device_creds") and d.get("device_username") and d.get("device_password"):
                continue  # this device has its own creds, skip the check

            if d["device_type"] == "firewall":
                has_fw_override = self.manager.has_fw_credentials(d.get("vendor", ""))
                if not has_fw_override:
                    # No per-vendor override — is single-credential mode covering it?
                    if not (single_mode and has_shared):
                        missing_fw_vendors.add(d["vendor"])
            else:
                if not has_shared:
                    missing_shared = True

        messages = []
        if missing_shared:
            messages.append(
                "Router/Switch backups need shared SSH credentials. "
                "Use 'Set SSH Creds (Router/Switch)'."
            )
        if missing_fw_vendors:
            names = ", ".join(fw_vendor_label(k) for k in sorted(missing_fw_vendors))
            if single_mode and has_shared:
                # This shouldn't happen given the logic above, but just in case
                messages.append(
                    f"Firewall vendors need credentials: {names}. "
                    "Use 'Set Firewall Creds (per vendor)' to add overrides."
                )
            else:
                messages.append(
                    f"Firewall backups need credentials for: {names}.\n"
                    "Either:\n"
                    "  • Use 'Set SSH Creds (Router/Switch)' and tick "
                    "'Use for ALL devices', OR\n"
                    "  • Use 'Set Firewall Creds (per vendor)' to enter "
                    "credentials per vendor."
                )
        if messages:
            messagebox.showwarning(
                "Missing Credentials",
                "\n\n".join(messages),
                parent=self,
            )
            return False
        return True

    def _backup_all(self):
        if self._backup_running:
            messagebox.showinfo("Busy", "A backup is already in progress.", parent=self)
            return
        devices = self.manager.get_all_devices()
        if not devices:
            messagebox.showinfo("Info", "No devices added yet.", parent=self)
            return
        if not self._check_credentials_for(devices):
            return
        if not messagebox.askyesno(
            "Confirm Backup",
            f"Start backup for ALL {len(devices)} device(s)?",
            parent=self,
        ):
            return
        self._start_backup(devices)

    def _backup_selected(self):
        if self._backup_running:
            messagebox.showinfo("Busy", "A backup is already in progress.", parent=self)
            return
        devices = self._get_selected_devices()
        if not devices:
            messagebox.showinfo("Info", "Check one or more devices (Select column) to back up.", parent=self)
            return
        if not self._check_credentials_for(devices):
            return
        self._start_backup(devices)

    def _retry_failed(self):
        if self._backup_running:
            messagebox.showinfo("Busy", "A backup is already in progress.", parent=self)
            return
        failed = [d for d in self.manager.get_all_devices() if d.get("last_status") == "failed"]
        if not failed:
            messagebox.showinfo("Info", "No failed backups to retry.", parent=self)
            return
        if not self._check_credentials_for(failed):
            return
        if not messagebox.askyesno(
            "Retry Failed",
            f"Retry backup for {len(failed)} failed device(s)?",
            parent=self,
        ):
            return
        self._start_backup(failed)

    def _start_backup(self, devices: List[Dict]):
        self._backup_running = True
        self.progress_bar["value"] = 0
        self._log(f"Starting backup of {len(devices)} device(s)...", "info")
        thread = threading.Thread(target=self._run_backup, args=(devices,), daemon=True)
        thread.start()

    def _run_backup(self, devices: List[Dict]):
        # Fix C1: Wrap the entire backup in try/except/finally so the GUI
        # is never permanently stuck if an unexpected error occurs.
        self.after(0, lambda: self._update_status("Backup in progress..."))
        self.after(0, lambda: self._set_ui_state(False))

        try:
            results = self.engine.backup_all(
                devices, progress_callback=self._backup_progress_callback,
            )
            self._backup_results = (self._backup_results + results)[-200:]
            for r in results:
                self.manager.update_backup_status(r.device_id, r.success, r.timestamp)

            success = sum(1 for r in results if r.success)
            failed = sum(1 for r in results if not r.success)

            self.after(0, lambda: self._log(
                f"Backup complete: {success} succeeded, {failed} failed",
                "success" if failed == 0 else "warning",
            ))
            self.after(0, lambda: self._update_status(
                f"Backup complete: {success}/{len(results)} successful"
            ))
            self.after(0, lambda: self.progress_bar.configure(value=100))
            self.after(0, self._refresh_tree)
        except Exception as e:
            self.after(0, lambda: self._log(
                f"Backup error: {e}", "error"))
            self.after(0, lambda: self._update_status(
                f"Backup failed with error: {str(e)[:80]}"))
        finally:
            # Always re-enable the UI and reset the running flag
            self.after(0, lambda: self._set_ui_state(True))
            self._backup_running = False

    def _backup_progress_callback(self, current: int, total: int, result: BackupResult):
        pct = (current / total) * 100
        self.after(0, lambda: self.progress_bar.configure(value=pct))
        if result.success:
            msg = (
                f"[{current}/{total}] {result.hostname} ({result.ip_address}): "
                f"SUCCESS via {result.backup_method.upper()}"
            )
            tag = "success"
        else:
            msg = (
                f"[{current}/{total}] {result.hostname} ({result.ip_address}): "
                f"FAILED - {result.error_message}"
            )
            tag = "error"
        self.after(0, lambda: self._log(msg, tag))
        if result.success and result.diff_summary:
            self.after(0, lambda: self._log(
                f"   ↳ Diff: {result.diff_summary}", "diff",
            ))
        self.after(0, lambda: self.progress_label.configure(
            text=f"{current}/{total} - {result.hostname}"
        ))
        self.after(0, lambda: self._update_status(
            f"Backing up {current}/{total}: {result.hostname}..."
        ))

    def _set_ui_state(self, enabled: bool):
        state = "normal" if enabled else "disabled"
        for widget in self.winfo_children():
            self._set_widget_state(widget, state)

    def _set_widget_state(self, widget, state):
        try:
            if isinstance(widget, (tk.Button, ttk.Button)):
                widget.configure(state=state)
            elif isinstance(widget, (tk.Frame, ttk.Frame)):
                for child in widget.winfo_children():
                    self._set_widget_state(child, state)
        except tk.TclError:
            pass

    # ════════════════════════════════════════════════════════════
    # DIFF VIEWER
    # ════════════════════════════════════════════════════════════
    def _view_last_diff(self):
        selected = self._get_selected_devices()
        if not selected:
            messagebox.showinfo("Info", "Check a device to view its last diff.", parent=self)
            return
        if len(selected) > 1:
            messagebox.showinfo("Info", "Check only ONE device to view its diff.", parent=self)
            return
        d = selected[0]
        for r in reversed(self._backup_results):
            if r.device_id == d["id"]:
                self._show_diff_dialog(r)
                return
        messagebox.showinfo(
            "No Backup Yet",
            f"No backup result available for {d['hostname']}.",
            parent=self,
        )

    def _show_diff_dialog(self, result: BackupResult):
        DiffViewerDialog(self, result)

    # ════════════════════════════════════════════════════════════
    # REPORT
    # ════════════════════════════════════════════════════════════
    def _generate_report(self):
        devices = self.manager.get_all_devices()
        if not self._backup_results and not devices:
            messagebox.showinfo("Info", "No data to generate a report.", parent=self)
            return
        self._log("Generating PDF report...", "info")
        self._update_status("Generating PDF report...")
        try:
            filepath = self.report_gen.generate(
                results=self._backup_results, all_devices=devices,
            )
            self._log(f"Report saved: {filepath}", "success")
            self._update_status(f"Report generated: {os.path.basename(filepath)}")
            messagebox.showinfo(
                "Report Generated",
                f"PDF report saved to:\n\n{filepath}",
                parent=self,
            )
        except ImportError as e:
            messagebox.showerror("Missing Library",
                f"{str(e)}\n\nRun: pip install reportlab", parent=self)
            self._log(f"Report generation failed: {str(e)}", "error")
        except Exception as e:
            messagebox.showerror("Error",
                f"Failed to generate report:\n{str(e)}", parent=self)
            self._log(f"Report generation error: {str(e)}", "error")

    # ════════════════════════════════════════════════════════════
    # CSV IMPORT / EXPORT
    # ════════════════════════════════════════════════════════════
    def _import_csv(self):
        filepath = filedialog.askopenfilename(
            title="Import Devices from CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            parent=self,
        )
        if not filepath:
            return
        try:
            count = self.manager.import_devices_from_csv(filepath)
            self._log(f"Imported {count} device(s) from {os.path.basename(filepath)}", "success")
            self._refresh_tree()
            messagebox.showinfo("Import Complete",
                f"Successfully imported {count} device(s).", parent=self)
        except Exception as e:
            messagebox.showerror("Import Error", f"Failed to import:\n{str(e)}", parent=self)
            self._log(f"Import failed: {str(e)}", "error")

    def _export_csv(self):
        devices = self.manager.get_all_devices()
        if not devices:
            messagebox.showinfo("Info", "No devices to export.", parent=self)
            return
        filepath = filedialog.asksaveasfilename(
            title="Export Devices to CSV",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
            parent=self,
        )
        if not filepath:
            return
        try:
            self.manager.export_devices_to_csv(filepath)
            self._log(f"Exported {len(devices)} device(s) to {os.path.basename(filepath)}", "success")
            messagebox.showinfo("Export Complete",
                f"Devices exported to:\n{filepath}", parent=self)
        except Exception as e:
            messagebox.showerror("Export Error", f"Failed to export:\n{str(e)}", parent=self)

    # ════════════════════════════════════════════════════════════
    # MANAGE VENDORS
    # ════════════════════════════════════════════════════════════
    def _manage_vendors(self):
        """Open the Manage Vendors dialog. After it closes, refresh all
        dropdowns and the tree if any vendors were added/edited/deleted."""
        dialog = ManageVendorsDialog(self, self.data_dir)
        self.wait_window(dialog)
        if dialog.vendors_changed:
            # Reload custom vendors into the in-memory registry
            load_custom_vendors(self.data_dir)
            # Refresh the device tree (vendor display names may have changed)
            self._refresh_tree()
            # Re-sync engine credentials — if single-credential mode is on,
            # the new vendor will automatically inherit the shared creds.
            # Otherwise, remind the user to set credentials for the new vendor.
            self._sync_engine_credentials()
            self._update_credential_indicator()
            self._log("Vendor registry updated — dropdowns refreshed", "info")
            # If single-credential mode is off, remind the user to configure
            # credentials for any newly-added firewall vendors
            if not self.manager.is_single_credential_mode():
                from vendors import active_vendors
                unconfigured = [
                    v.label for v in active_vendors()
                    if not self.manager.has_fw_credentials(v.key)
                ]
                if unconfigured:
                    self._log(
                        f"New vendor(s) may need credentials: {', '.join(unconfigured[:5])}. "
                        f"Use 'Set Firewall Creds (per vendor)' or enable single-credential mode.",
                        "warning",
                    )

    # ════════════════════════════════════════════════════════════
    # LAUNCH NETWORK OPERATIONS
    # ════════════════════════════════════════════════════════════
    def _launch_operations(self):
        """Open the Network Operations window — SSH terminal, config push,
        compliance checks, diagnostics, and change history.

        Shares the same device list and credentials as the backup tool.
        """
        from ops_gui import NetworkOperationsWindow
        NetworkOperationsWindow(self, self.manager, self.data_dir)
        self._log("Network Operations window launched", "info")

    # ════════════════════════════════════════════════════════════
    # FOLDER OPEN
    # ════════════════════════════════════════════════════════════
    def _open_backup_folder(self):
        os.makedirs(self.backup_dir, exist_ok=True)
        self._open_in_explorer(self.backup_dir)

    def _open_reports_folder(self):
        os.makedirs(self.reports_dir, exist_ok=True)
        self._open_in_explorer(self.reports_dir)

    def _open_in_explorer(self, path: str):
        if sys.platform == "win32":
            os.startfile(path)
        elif sys.platform == "darwin":
            import subprocess
            subprocess.Popen(["open", path])
        else:
            import subprocess
            subprocess.Popen(["xdg-open", path])

    # ════════════════════════════════════════════════════════════
    # CLOSE
    # ════════════════════════════════════════════════════════════
    def _on_close(self):
        if self._backup_running:
            if not messagebox.askyesno(
                "Confirm Exit",
                "A backup is in progress. Are you sure you want to exit?",
                parent=self,
            ):
                return
        self.destroy()
