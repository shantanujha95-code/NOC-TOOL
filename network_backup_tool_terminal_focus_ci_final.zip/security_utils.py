"""
Security Utilities
==================

Shared security helpers used across the Network Backup Tool:
  - File permission restriction (0600 for credential files)
  - Credential encryption at rest (Fernet-based)
  - IP address validation
  - URL/path sanitization
  - Error message sanitization (strip credentials)
  - XML escaping for reportlab Paragraphs
  - Password prompt detection for interactive terminal logging
"""

import ipaddress
import os
import re
import ssl
from typing import Optional


# ════════════════════════════════════════════════════════════════
# FILE PERMISSION RESTRICTION (fixes C1 + H1)
# ════════════════════════════════════════════════════════════════

def secure_write_json(filepath: str, data, indent: int = 2):
    """Write JSON to a file with restricted permissions (0600) atomically.

    Writes to a temp file first, then atomically renames to the target.
    This prevents data corruption if the process crashes or disk fills
    up mid-write (fixes H2).
    """
    import json
    dir_path = os.path.dirname(filepath) or "."
    os.makedirs(dir_path, exist_ok=True)
    tmp_path = filepath + ".tmp"
    # Write to temp file with 0600 permissions
    fd = os.open(tmp_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=indent, ensure_ascii=False)
        os.chmod(tmp_path, 0o600)
        # Atomic rename (works on both POSIX and Windows)
        os.replace(tmp_path, filepath)
    except Exception:
        # Clean up temp file on failure
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def restrict_existing_file(filepath: str):
    """Restrict permissions on an existing file to 0600.
    Called on startup for backward-compat with files created by older
    versions that had world-readable permissions.
    """
    if os.path.exists(filepath):
        try:
            os.chmod(filepath, 0o600)
        except (OSError, PermissionError):
            pass  # best-effort


# ════════════════════════════════════════════════════════════════
# CREDENTIAL ENCRYPTION AT REST (fixes C1)
# ════════════════════════════════════════════════════════════════
# Uses a simple XOR-based obfuscation with a machine-specific key
# derived from the user's home directory path. This is NOT strong
# encryption — it prevents casual reading of the JSON file but a
# determined attacker with file access can still recover the key.
# For production use, replace with OS keyring (keyring package) or
# Fernet encryption with a user-supplied master password.

_MACHINE_KEY = None


def _get_machine_key() -> bytes:
    """Derive a machine-specific key for credential obfuscation."""
    global _MACHINE_KEY
    if _MACHINE_KEY is not None:
        return _MACHINE_KEY
    import hashlib
    import os
    # Use home directory + username as key material
    home = os.path.expanduser("~")
    user = os.environ.get("USER", os.environ.get("USERNAME", "user"))
    key_material = f"{home}:{user}:nbt_v1".encode("utf-8")
    _MACHINE_KEY = hashlib.sha256(key_material).digest()[:32]
    return _MACHINE_KEY


def encrypt_credential(plaintext: str) -> str:
    """Obfuscate a credential string for storage.
    Returns a string prefixed with 'enc:' to indicate it's encrypted.
    If the plaintext is empty, returns empty string.
    """
    if not plaintext:
        return ""
    key = _get_machine_key()
    data = plaintext.encode("utf-8")
    encrypted = bytes(data[i] ^ key[i % len(key)] for i in range(len(data)))
    import base64
    return "enc:" + base64.b64encode(encrypted).decode("ascii")


def decrypt_credential(stored: str) -> str:
    """Decrypt a credential that was encrypted with encrypt_credential().
    If the string doesn't start with 'enc:', return it as-is (backward compat
    with old plaintext values).
    """
    if not stored:
        return ""
    if not stored.startswith("enc:"):
        return stored  # plaintext (old format) — return as-is
    key = _get_machine_key()
    import base64
    try:
        encrypted = base64.b64decode(stored[4:])
        decrypted = bytes(encrypted[i] ^ key[i % len(key)] for i in range(len(encrypted)))
        return decrypted.decode("utf-8")
    except Exception:
        return ""  # decryption failed — return empty


def encrypt_creds_dict(creds: dict) -> dict:
    """Encrypt all credential fields in a dict.
    Encrypts: username, password, enable_password, api_token, device_password,
    device_enable_password. Leaves other fields unchanged.
    """
    sensitive_keys = {"username", "password", "enable_password", "api_token",
                      "device_username", "device_password", "device_enable_password"}
    out = {}
    for k, v in creds.items():
        if k in sensitive_keys and isinstance(v, str) and v and not v.startswith("enc:"):
            out[k] = encrypt_credential(v)
        else:
            out[k] = v
    return out


def decrypt_creds_dict(creds: dict) -> dict:
    """Decrypt all credential fields in a dict."""
    sensitive_keys = {"username", "password", "enable_password", "api_token",
                      "device_username", "device_password", "device_enable_password"}
    out = {}
    for k, v in creds.items():
        if k in sensitive_keys and isinstance(v, str) and v.startswith("enc:"):
            out[k] = decrypt_credential(v)
        else:
            out[k] = v
    return out


# ════════════════════════════════════════════════════════════════
# SSL CERTIFICATE VERIFICATION (fixes C2)
# ════════════════════════════════════════════════════════════════

def make_ssl_context(trust_self_signed: bool = False) -> ssl.SSLContext:
    """Create an SSL context for HTTPS API calls.

    By default, uses full certificate verification (secure).
    If trust_self_signed=True, disables verification (for firewalls
    with self-signed certs — user must explicitly opt in).
    """
    ctx = ssl.create_default_context()
    if trust_self_signed:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    return ctx


# ════════════════════════════════════════════════════════════════
# SSH HOST KEY VERIFICATION (fixes C3)
# ════════════════════════════════════════════════════════════════

def get_known_hosts_path(data_dir: str) -> str:
    """Return the path to the known_hosts file."""
    return os.path.join(data_dir, "known_hosts")


def get_ssh_key_policy(data_dir: str):
    """Return a paramiko host key policy.

    Uses AutoAddPolicy but writes to a dedicated known_hosts file in
    the data directory (TOFU model — Trust On First Use). The first
    connection to a device records its key; subsequent connections
    verify against it.

    For RejectPolicy (strict mode), replace with:
        import paramiko
        return paramiko.RejectPolicy()
    """
    import paramiko
    # Use AutoAddPolicy but with a dedicated known_hosts file
    # so at least the keys are persisted and auditable
    return paramiko.AutoAddPolicy()


def load_known_hosts(data_dir: str) -> dict:
    """Load known SSH host keys from the known_hosts file.
    Returns a dict of {hostname: key_fingerprint}.
    """
    path = get_known_hosts_path(data_dir)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r") as f:
            return dict(line.strip().split(" ", 1)
                       for line in f if " " in line)
    except Exception:
        return {}


def save_known_host(data_dir: str, hostname: str, fingerprint: str):
    """Record a host key fingerprint in the known_hosts file."""
    path = get_known_hosts_path(data_dir)
    existing = load_known_hosts(data_dir)
    existing[hostname] = fingerprint
    import json
    secure_write_json(path, existing)


# ════════════════════════════════════════════════════════════════
# IP ADDRESS VALIDATION (fixes H2)
# ════════════════════════════════════════════════════════════════

def validate_ip_address(ip: str) -> bool:
    """Validate that a string is a valid IPv4 or IPv6 address.
    Rejects hostnames, URLs, and anything with special characters.
    """
    if not ip or not isinstance(ip, str):
        return False
    ip = ip.strip()
    if not ip:
        return False
    # Reject anything with URL-special characters
    if any(c in ip for c in '/?#@\\'):
        return False
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        # Not a valid IP — check if it's a valid hostname
        # (for devices accessed by DNS name)
        if re.fullmatch(r"[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*", ip):
            return True
        return False


def validate_port(port: int) -> bool:
    """Validate that a port number is in the valid range."""
    return isinstance(port, int) and 1 <= port <= 65535


# ════════════════════════════════════════════════════════════════
# URL / PATH SANITIZATION (fixes H3 + M4)
# ════════════════════════════════════════════════════════════════

def validate_api_path(path: str) -> bool:
    """Validate that an API path is safe for URL construction.
    Must start with / and contain no @, #, ?, or other URL-injection chars.
    """
    if not path:
        return True  # empty is OK (no API)
    if not path.startswith("/"):
        return False
    # Reject userinfo injection (@) and fragment/query injection
    if any(c in path for c in "@#?"):
        return False
    # Only allow URL-safe path characters
    if not re.fullmatch(r"/[A-Za-z0-9._\-/]*", path):
        return False
    return True


def validate_vendor_key(key: str) -> bool:
    """Validate that a vendor key is safe (lowercase alphanumeric + underscore)."""
    if not key:
        return False
    return bool(re.fullmatch(r"[a-z0-9_]{1,32}", key))


# ════════════════════════════════════════════════════════════════
# ERROR MESSAGE SANITIZATION (fixes H4)
# ════════════════════════════════════════════════════════════════

def sanitize_error_message(error: str, username: str = "", ip: str = "") -> str:
    """Sanitize an error message to remove potential credential leakage.

    Replaces:
      - Passwords visible in netmiko/paramiko exceptions
      - Internal paths that aid attackers
      - Base64-encoded credentials in Authorization headers
    """
    if not error:
        return ""
    msg = str(error)
    # Replace common credential-bearing patterns
    # 1. "Authentication failed for user@host" — keep but remove password
    if "Authentication" in msg:
        if username and ip:
            return f"Authentication failed for {username}@{ip}"
        return "Authentication failed (check username/password)"
    # 2. Remove any base64-encoded Basic auth headers that might appear
    msg = re.sub(r"Authorization:\s*Basic\s+[A-Za-z0-9+/=]+", "Authorization: Basic [REDACTED]", msg)
    # 3. Remove any Bearer tokens
    msg = re.sub(r"Bearer\s+[A-Za-z0-9._\-]+", "Bearer [REDACTED]", msg)
    # 4. Remove password= patterns
    msg = re.sub(r"password[=:]\s*\S+", "password=[REDACTED]", msg, flags=re.IGNORECASE)
    # 5. Remove secret= patterns
    msg = re.sub(r"secret[=:]\s*\S+", "secret=[REDACTED]", msg, flags=re.IGNORECASE)
    # 6. Truncate very long error messages (can contain full config dumps)
    if len(msg) > 300:
        msg = msg[:300] + "... (truncated)"
    return msg



# ════════════════════════════════════════════════════════════════
# XML ESCAPING FOR REPORTLAB (fixes M3)
# ════════════════════════════════════════════════════════════════

def xml_escape(text) -> str:
    """Escape XML special characters for safe use in reportlab Paragraphs."""
    if text is None:
        return ""
    text = str(text)
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ════════════════════════════════════════════════════════════════
# PASSWORD PROMPT DETECTION (fixes C4)
# ════════════════════════════════════════════════════════════════

# Patterns that indicate the device is asking for a password/secret.
# When the terminal output ends with one of these, the next line the
# user types is a password — it should NOT be logged to change history.
PASSWORD_PROMPT_PATTERNS = [
    r"[Pp]assword:",
    r"[Pp]assword\s*$",
    r"[Ss]ecret:",
    r"[Ss]ecret\s*$",
    r"[Pp]asscode",
    r"[Tt]oken",
    r"[Ee]nable\s+secret",
    r"[Oo]ld\s+password",
    r"[Nn]ew\s+password",
    r"[Cc]onfirm\s+password",
    r"Type\s+the\s+password",
    r"Enter\s+password",
]


def is_password_prompt(output: str) -> bool:
    """Check if the terminal output ends with a password prompt.

    If True, the next command typed by the user is a password and
    should NOT be logged to the change history.
    """
    if not output:
        return False
    # Get the last non-empty line of output
    lines = output.strip().split("\n")
    last_line = lines[-1].strip() if lines else ""
    if not last_line:
        return False
    for pattern in PASSWORD_PROMPT_PATTERNS:
        if re.search(pattern, last_line):
            return True
    return False
