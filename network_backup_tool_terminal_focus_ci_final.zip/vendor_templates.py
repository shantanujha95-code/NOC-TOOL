"""
Vendor Backup Templates
=======================

Official backup commands and procedures for each supported vendor, sourced
from vendor documentation. Used to auto-fill the Manage Vendors form when
a user picks a vendor type, and to show a read-only preview in the Add
Device dialog.

Sources:
  - FortiGate:    Fortinet KB FD33882 "Backing up the configuration file"
                  API: GET /api/v2/monitor/system/config/backup?destination=file
                  SSH: execute show full-configuration (pagination must be off)
  - Check Point:  Check Point SK111312 "Gaia Configuration Backup"
                  SSH (clish): show configuration
  - SonicWall:    SonicWall KB 170505849812534 "Backup via XAPI"
                  API: POST /api/sonicos/export-config (Basic auth)
  - Palo Alto:    PAN-OS Admin Guide "Back up the device configuration"
                  SSH: show config running  (XML format)
  - Cisco ASA:    Cisco ASA Configuration Guide "Backup the Running Configuration"
                  SSH: show running-config  (enable mode required)
  - Juniper SRX:  Junos OS Admin Guide "Save and Load Configuration Files"
                  SSH: show configuration | display set
  - Cisco IOS:    Cisco IOS Configuration Guide "Copy Configuration Files"
                  SSH: show running-config  (enable mode)
  - Juniper JunOS: same as SRX
  - Dell OS10:    Dell SmartFabric OS10 User Guide "Configuration File Management"
                  SSH: show running-configuration
  - Arista EOS:   Arista EOS Manual "Configuration Management"
                  SSH: show running-config
  - HP Comware:   HPE Comware Configuration Guide "Configuration File Management"
                  SSH: display current-configuration
  - Huawei VRP:   Huawei VRP Configuration Guide "Configuration File Management"
                  SSH: display current-configuration
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class VendorTemplate:
    """
    A pre-built vendor template with official backup commands.

    When a user picks a vendor in the Manage Vendors dialog or Add Device
    dialog, the template auto-fills the backup commands (and for firewalls,
    the API path / netmiko type / pre-commands). The user can still edit
    everything before saving.
    """
    # Display info
    category: str            # "Firewall" or "Router/Switch"
    label: str               # Display name e.g. "Cisco IOS"
    key: str                 # Internal key e.g. "cisco_ios"

    # SSH backup
    netmiko_type: str        # netmiko device_type
    backup_commands: List[str] = field(default_factory=list)
    pre_commands: List[str] = field(default_factory=list)
    post_commands: List[str] = field(default_factory=list)
    supports_enable: bool = False
    ssh_supported: bool = True

    # API backup (firewalls only)
    api_supported: bool = False
    api_port: int = 443
    api_path: str = ""
    api_auth_mode: str = "basic"   # "basic" | "bearer" | "either"
    backup_priority: List[str] = field(default_factory=lambda: ["ssh"])

    # Docs / description
    description: str = ""
    doc_reference: str = ""

    # Suggested key for custom vendor (if user creates a new one from this template)
    suggested_key: str = ""


# ════════════════════════════════════════════════════════════════
# FIREWALL TEMPLATES (official backup procedures)
# ════════════════════════════════════════════════════════════════

FIREWALL_TEMPLATES: List[VendorTemplate] = [

    VendorTemplate(
        category="Firewall",
        label="FortiGate (FortiOS)",
        key="fortigate",
        netmiko_type="fortinet",
        pre_commands=[
            "config system console",
            "set output standard",
            "end",
        ],
        backup_commands=["show full-configuration"],
        supports_enable=False,
        api_supported=True,
        api_port=443,
        api_path="/api/v2/monitor/system/config/backup",
        api_auth_mode="either",
        backup_priority=["api", "ssh"],
        description=(
            "Fortinet FortiOS firewall. Official backup via REST API "
            "(GET /api/v2/monitor/system/config/backup?destination=file) "
            "with Bearer token or Basic auth. SSH fallback uses "
            "'show full-configuration' with pagination disabled."
        ),
        doc_reference="Fortinet KB FD33882 — Backing up the configuration file",
        suggested_key="fortigate",
    ),

    VendorTemplate(
        category="Firewall",
        label="Check Point (Gaia)",
        key="checkpoint",
        netmiko_type="checkpoint_gaia",
        backup_commands=["show configuration"],
        supports_enable=False,
        api_supported=False,
        backup_priority=["ssh"],
        description=(
            "Check Point Gaia OS firewall. SSH-only backup using clish "
            "'show configuration' which dumps the entire Gaia OS "
            "configuration. No REST API for OS-level config backup. "
            "Ensure the SSH user has clish access (not just expert shell)."
        ),
        doc_reference="Check Point SK111312 — Gaia Configuration Backup",
        suggested_key="checkpoint",
    ),

    VendorTemplate(
        category="Firewall",
        label="SonicWall (SonicOS)",
        key="sonicwall",
        netmiko_type="cisco_ios",
        backup_commands=["show config"],
        supports_enable=False,
        api_supported=True,
        api_port=443,
        api_path="/api/sonicos/export-config",
        api_auth_mode="basic",
        backup_priority=["api", "ssh"],
        description=(
            "SonicWall SonicOS firewall. Official backup via XAPI "
            "(POST /api/sonicos/export-config) with HTTP Basic auth. "
            "SSH fallback uses 'show config' (limited output on some firmware)."
        ),
        doc_reference="SonicWall KB 170505849812534 — Backup via XAPI",
        suggested_key="sonicwall",
    ),

    VendorTemplate(
        category="Firewall",
        label="Palo Alto (PAN-OS)",
        key="panos",
        netmiko_type="paloalto_panos",
        backup_commands=["show config running"],
        supports_enable=False,
        api_supported=False,
        backup_priority=["ssh"],
        description=(
            "Palo Alto PAN-OS firewall. SSH backup using "
            "'show config running' which returns the full configuration "
            "in XML format. Requires a Palo Alto admin account."
        ),
        doc_reference="PAN-OS Admin Guide — Back up the device configuration",
        suggested_key="panos",
    ),

    VendorTemplate(
        category="Firewall",
        label="Cisco ASA",
        key="cisco_asa",
        netmiko_type="cisco_asa",
        backup_commands=["show running-config"],
        supports_enable=True,
        api_supported=False,
        backup_priority=["ssh"],
        description=(
            "Cisco Adaptive Security Appliance (ASA). SSH backup using "
            "'show running-config' in enable mode. Requires enable secret."
        ),
        doc_reference="Cisco ASA Configuration Guide — Backup the Running Configuration",
        suggested_key="cisco_asa",
    ),

    VendorTemplate(
        category="Firewall",
        label="Juniper SRX",
        key="junos_srx",
        netmiko_type="juniper_junos",
        backup_commands=["show configuration | display set"],
        supports_enable=False,
        api_supported=False,
        backup_priority=["ssh"],
        description=(
            "Juniper SRX services gateway. SSH backup using "
            "'show configuration | display set' which returns the config "
            "as set commands."
        ),
        doc_reference="Junos OS Admin Guide — Save and Load Configuration Files",
        suggested_key="junos_srx",
    ),

    VendorTemplate(
        category="Firewall",
        label="Sophos XG",
        key="sophos_xg",
        netmiko_type="cisco_ios",
        backup_commands=["show configuration"],
        supports_enable=False,
        api_supported=False,
        backup_priority=["ssh"],
        description=(
            "Sophos XG firewall. SSH backup using 'show configuration'. "
            "Configuration export is also available via the Web Admin "
            "console under Backup & Export."
        ),
        doc_reference="Sophos XG Administrator Guide — Configuration Backup",
        suggested_key="sophos_xg",
    ),

    VendorTemplate(
        category="Firewall",
        label="WatchGuard Firebox",
        key="watchguard",
        netmiko_type="cisco_ios",
        backup_commands=["show config"],
        supports_enable=False,
        api_supported=False,
        backup_priority=["ssh"],
        description=(
            "WatchGuard Firebox firewall. SSH CLI backup is limited. "
            "Full configuration backup is recommended via Firebox Web UI "
            "(System > Configuration). Use this template for partial CLI backup."
        ),
        doc_reference="WatchGuard Firebox Help — Configuration Backup",
        suggested_key="watchguard",
    ),

    VendorTemplate(
        category="Firewall",
        label="Cisco Firepower (FTD)",
        key="cisco_ftd",
        netmiko_type="cisco_ftd",
        backup_commands=["show running-config"],
        supports_enable=True,
        api_supported=False,
        backup_priority=["ssh"],
        description=(
            "Cisco Firepower Threat Defense (FTD). SSH backup using "
            "'show running-config' in enable mode. For FMC-managed FTD, "
            "use the FMC API instead."
        ),
        doc_reference="Cisco Firepower Configuration Guide",
        suggested_key="cisco_ftd",
    ),

    VendorTemplate(
        category="Firewall",
        label="pfSense",
        key="pfsense",
        netmiko_type="linux",
        backup_commands=["cat /conf/config.xml"],
        supports_enable=False,
        api_supported=False,
        backup_priority=["ssh"],
        description=(
            "pfSense firewall. SSH backup reads the raw config.xml file "
            "directly. Alternatively use the web UI (Diagnostics > "
            "Backup & Restore) or the REST API (pfSense v2.5+)."
        ),
        doc_reference="pfSense Documentation — Configuration Backup",
        suggested_key="pfsense",
    ),
]


# ════════════════════════════════════════════════════════════════
# ROUTER / SWITCH TEMPLATES (official backup commands)
# ════════════════════════════════════════════════════════════════

ROUTER_SWITCH_TEMPLATES: List[VendorTemplate] = [

    VendorTemplate(
        category="Router/Switch",
        label="Cisco IOS",
        key="cisco_ios",
        netmiko_type="cisco_ios",
        backup_commands=["show running-config"],
        supports_enable=True,
        description=(
            "Cisco IOS routers and switches (Catalyst, ISR, ASR). "
            "SSH backup using 'show running-config' in enable mode. "
            "The most common Cisco platform."
        ),
        doc_reference="Cisco IOS Configuration Guide — Copy Configuration Files",
        suggested_key="cisco_ios",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="Cisco IOS-XE",
        key="cisco_xe",
        netmiko_type="cisco_xe",
        backup_commands=["show running-config"],
        supports_enable=True,
        description=(
            "Cisco IOS-XE (Catalyst 9000, ISR 4000, ASR 1000). "
            "SSH backup using 'show running-config' in enable mode."
        ),
        doc_reference="Cisco IOS-XE Configuration Guide",
        suggested_key="cisco_xe",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="Cisco IOS-XR",
        key="cisco_xr",
        netmiko_type="cisco_xr",
        backup_commands=["show running-config"],
        supports_enable=False,
        description=(
            "Cisco IOS-XR (ASR 9000, CRS, NCS). SSH backup using "
            "'show running-config'. No enable mode (uses commit model)."
        ),
        doc_reference="Cisco IOS-XR Configuration Guide",
        suggested_key="cisco_xr",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="Cisco NX-OS",
        key="cisco_nxos",
        netmiko_type="cisco_nxos",
        backup_commands=["show running-config"],
        supports_enable=False,
        description=(
            "Cisco NX-OS (Nexus 9000, 7000, 5000). SSH backup using "
            "'show running-config'."
        ),
        doc_reference="Cisco NX-OS Configuration Guide",
        suggested_key="cisco_nxos",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="Juniper JunOS",
        key="juniper_junos",
        netmiko_type="juniper_junos",
        backup_commands=["show configuration | display set"],
        supports_enable=False,
        description=(
            "Juniper JunOS (MX, EX, QFX, SRX). SSH backup using "
            "'show configuration | display set' which returns the config "
            "as set commands. For XML format use 'show configuration | display xml'."
        ),
        doc_reference="Junos OS Admin Guide — Configuration Files",
        suggested_key="juniper_junos",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="Dell OS10",
        key="dell_os10",
        netmiko_type="dell_os10",
        backup_commands=["show running-configuration"],
        supports_enable=False,
        description=(
            "Dell SmartFabric OS10 (N3248, N3240, S5232, S5224). "
            "SSH backup using 'show running-configuration'."
        ),
        doc_reference="Dell SmartFabric OS10 User Guide — Configuration File Management",
        suggested_key="dell_os10",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="Dell OS6",
        key="dell_os6",
        netmiko_type="dell_os6",
        backup_commands=["show running-config"],
        supports_enable=False,
        description=(
            "Dell Networking OS6 (N1100, N1500, N2000, N3000 series). "
            "SSH backup using 'show running-config'."
        ),
        doc_reference="Dell Networking OS6 CLI Reference Guide",
        suggested_key="dell_os6",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="Arista EOS",
        key="arista_eos",
        netmiko_type="arista_eos",
        backup_commands=["show running-config"],
        supports_enable=False,
        description=(
            "Arista EOS (7050, 7280, 7300, 7500 series). SSH backup "
            "using 'show running-config'."
        ),
        doc_reference="Arista EOS Manual — Configuration Management",
        suggested_key="arista_eos",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="HP Comware",
        key="hp_comware",
        netmiko_type="hp_comware",
        backup_commands=["display current-configuration"],
        supports_enable=False,
        description=(
            "HPE Comware 7 (5520, 5510, 5120, 5130, 5500, 5900 series). "
            "SSH backup using 'display current-configuration'."
        ),
        doc_reference="HPE Comware 7 Configuration Guide — Configuration File Management",
        suggested_key="hp_comware",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="Huawei VRP",
        key="huawei",
        netmiko_type="huawei",
        backup_commands=["display current-configuration"],
        supports_enable=False,
        description=(
            "Huawei VRP (S5700, S6700, S7700, S9700, AR1200, AR2200, "
            "AR3200, AR3600). SSH backup using 'display current-configuration'."
        ),
        doc_reference="Huawei VRP Configuration Guide — Configuration File Management",
        suggested_key="huawei",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="Huawei VRPv8",
        key="huawei_vrpv8",
        netmiko_type="huawei_vrpv8",
        backup_commands=["display current-configuration"],
        supports_enable=False,
        description=(
            "Huawei VRPv8 (CE6800, CE7800, CE8800, CE12800 CloudEngine "
            "series). SSH backup using 'display current-configuration'."
        ),
        doc_reference="Huawei CloudEngine Series Configuration Guide",
        suggested_key="huawei_vrpv8",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="MikroTik RouterOS",
        key="mikrotik_routeros",
        netmiko_type="mikrotik_routeros",
        backup_commands=["/export"],
        supports_enable=False,
        description=(
            "MikroTik RouterOS (RB, CCR, CRS series). SSH backup using "
            "'/export' which returns the full configuration as RouterOS "
            "commands."
        ),
        doc_reference="MikroTik Wiki — Configuration Export",
        suggested_key="mikrotik_routeros",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="Extreme EXOS",
        key="extreme_exos",
        netmiko_type="extreme_exos",
        backup_commands=["show configuration"],
        supports_enable=False,
        description=(
            "Extreme EXOS (X440, X460, X670, X770, X870 series). "
            "SSH backup using 'show configuration'."
        ),
        doc_reference="Extreme EXOS User Guide — Configuration Management",
        suggested_key="extreme_exos",
    ),

    VendorTemplate(
        category="Router/Switch",
        label="Ruckus FastIron",
        key="ruckus_fastiron",
        netmiko_type="ruckus_fastiron",
        backup_commands=["show running-config"],
        supports_enable=True,
        description=(
            "Ruckus FastIron (ICX 6610, 7150, 7750, 7800, 8200). "
            "SSH backup using 'show running-config' in enable mode."
        ),
        doc_reference="Ruckus FastIron Configuration Guide",
        suggested_key="ruckus_fastiron",
    ),
]


# ════════════════════════════════════════════════════════════════
# LOOKUP HELPERS
# ════════════════════════════════════════════════════════════════

ALL_TEMPLATES: List[VendorTemplate] = FIREWALL_TEMPLATES + ROUTER_SWITCH_TEMPLATES

# Map: key -> VendorTemplate (for both firewall and router/switch)
TEMPLATE_BY_KEY: Dict[str, VendorTemplate] = {t.key: t for t in ALL_TEMPLATES}

# Map: label -> VendorTemplate
TEMPLATE_BY_LABEL: Dict[str, VendorTemplate] = {t.label: t for t in ALL_TEMPLATES}


def firewall_templates() -> List[VendorTemplate]:
    """Return all firewall vendor templates."""
    return list(FIREWALL_TEMPLATES)


def router_switch_templates() -> List[VendorTemplate]:
    """Return all router/switch vendor templates."""
    return list(ROUTER_SWITCH_TEMPLATES)


def get_template(key: str) -> Optional[VendorTemplate]:
    """Look up a template by vendor key. Returns None if not found."""
    return TEMPLATE_BY_KEY.get(key)


def get_template_by_label(label: str) -> Optional[VendorTemplate]:
    """Look up a template by display label. Returns None if not found."""
    return TEMPLATE_BY_LABEL.get(label)


def template_labels_for_category(category: str) -> List[str]:
    """Return template labels for a given category ('Firewall' or 'Router/Switch')."""
    if category == "Firewall":
        return [t.label for t in FIREWALL_TEMPLATES]
    else:
        return [t.label for t in ROUTER_SWITCH_TEMPLATES]
