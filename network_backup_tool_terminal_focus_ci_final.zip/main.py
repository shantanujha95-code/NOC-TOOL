#!/usr/bin/env python3
"""
Network Backup Tool - Entry Point
=================================

Unified tool for backing up:
  - Routers      (SSH, shared SSH credentials)
  - Switches     (SSH, shared SSH credentials)
  - Firewalls    (vendor-specific: FortiGate API, SonicWall XAPI, Check Point SSH,
                 with API-first / SSH-fallback dispatch and per-vendor credentials)

Usage:
    python main.py
"""

import sys
import os
import hashlib


# ── hashlib.md5 compatibility shim (install as early as possible) ──
# ReportLab calls md5(data, usedforsecurity=False); the kwarg only exists
# in Python 3.9+. On Python 3.8 the call raises:
#     TypeError: usedforsecurity is an invalid keyword argument for openssl md5()
_ORIG_MD5 = hashlib.md5

def _md5_compat(data=b"", *, usedforsecurity=True):
    try:
        return _ORIG_MD5(data, usedforsecurity=usedforsecurity)
    except TypeError:
        return _ORIG_MD5(data)

if not getattr(hashlib, "_ubt_md5_patched", False):
    hashlib.md5 = _md5_compat
    hashlib._ubt_md5_patched = True
# ── end shim ────────────────────────────────────────────────────


if getattr(sys, "frozen", False):
    BASE_DIR = sys._MEIPASS
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)


def check_dependencies():
    """Verify required packages are installed."""
    missing = []
    try:
        import netmiko  # noqa: F401
    except ImportError:
        missing.append("netmiko")
    try:
        import reportlab  # noqa: F401
    except ImportError:
        missing.append("reportlab")

    if missing:
        print("=" * 55)
        print("  NETWORK BACKUP TOOL - Missing Dependencies")
        print("=" * 55)
        print(f"\n  Missing packages: {', '.join(missing)}\n")
        print("  Install with:")
        print(f"    pip install {' '.join(missing)}")
        print("\n  Or install all dependencies:")
        print("    pip install -r requirements.txt")
        print("\n" + "=" * 55)
        input("\nPress Enter to exit...")
        sys.exit(1)


def smoke_test():
    """Initialize the GUI and core modules, then exit successfully.

    This is intentionally side-effect-light so CI can verify that the
    packaged executable starts correctly without requiring real network
    devices or credentials.
    """
    check_dependencies()

    # Import the same modules used by the GUI/application.
    from device_manager import DeviceManager
    from backup_engine import UnifiedBackupEngine
    from report_generator import UnifiedReportGenerator
    from vendors import active_vendors

    assert active_vendors(), "No active vendors are registered"
    DeviceManager(data_dir=os.path.join(BASE_DIR, ".ci_smoke_data"))
    UnifiedBackupEngine()
    UnifiedReportGenerator(output_dir=os.path.join(BASE_DIR, ".ci_smoke_reports"))

    # Verify Tk can initialize in the Windows CI desktop environment.
    import tkinter as tk
    root = tk.Tk()
    root.withdraw()
    root.update_idletasks()
    root.destroy()


def main():
    """Launch the GUI application."""
    if "--smoke-test" in sys.argv:
        smoke_test()
        return

    check_dependencies()

    if sys.platform == "win32":
        try:
            from ctypes import windll
            windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass

    from gui import NetworkBackupTool
    app = NetworkBackupTool()
    app.mainloop()


if __name__ == "__main__":
    main()
