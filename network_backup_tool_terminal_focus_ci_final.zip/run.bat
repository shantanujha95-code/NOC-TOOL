@echo off
REM ============================================================
REM  Network Backup Tool - Portable Runner (Windows)
REM  PREREQUISITE: Python 3.8+ must be installed
REM ============================================================

echo.
echo  Network Backup Tool - Portable Runner
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python is not found. Please install Python 3.8+
    echo  from https://www.python.org/downloads/
    echo  Check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

echo  Checking dependencies...
pip install --quiet netmiko reportlab paramiko 2>nul

echo  Starting Network Backup Tool...
python main.py

if errorlevel 1 (
    echo.
    echo  The application closed with an error.
    pause
)
