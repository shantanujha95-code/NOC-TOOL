"""
Device Manager
==============

CRUD operations for the device inventory (Router / Switch / Firewall) and
credential storage.

Credentials are stored in TWO separate slots:

  1. SHARED SSH CREDENTIALS  — a single (username, password, enable_password)
     tuple used for every Router and Switch. Routers and switches typically
     share the same management credentials across a fleet, so one slot is
     enough.

  2. PER-VENDOR FIREWALL CREDENTIALS — a dict per firewall vendor:
        {
          "username":       str,
          "password":       str,
          "enable_password": str,
          "api_token":      str,
        }
     Firewalls need per-vendor creds because each vendor uses a different
     API auth scheme (FortiGate: Bearer token, SonicWall: HTTP Basic,
     Check Point: SSH only, etc.).

Storage files (both in <data_dir>/):
  - devices.json                — device inventory
  - shared_credentials.json     — shared SSH creds (router/switch)
  - firewall_credentials.json   — per-vendor firewall creds
"""

import json
import os
import threading
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from security_utils import secure_write_json, restrict_existing_file, validate_ip_address, validate_port, encrypt_creds_dict, decrypt_creds_dict

from vendors import active_vendors, get_vendor, vendor_label


DEVICE_FILE = "devices.json"
SHARED_CRED_FILE = "shared_credentials.json"
FW_CRED_FILE = "firewall_credentials.json"

DEVICE_TYPES = ["Router", "Switch", "Firewall"]


class DeviceManager:
    """Manages the inventory of routers, switches, and firewalls."""

    def __init__(self, data_dir: str = "."):
        self.data_dir = data_dir
        self.devices_file = os.path.join(data_dir, DEVICE_FILE)
        self.shared_cred_file = os.path.join(data_dir, SHARED_CRED_FILE)
        self.fw_cred_file = os.path.join(data_dir, FW_CRED_FILE)

        self._devices: List[Dict] = []
        self._shared_creds: Dict = {}
        # vendor_key -> {username, password, enable_password, api_token}
        self._fw_credentials: Dict[str, Dict] = {}
        self._lock = threading.Lock()  # Fix H1: protect shared state from concurrent access

        self._load_devices()
        self._load_shared_credentials()
        self._load_fw_credentials()
        # Fix C1+H1: Restrict permissions on existing credential files
        restrict_existing_file(self.devices_file)
        restrict_existing_file(self.shared_cred_file)
        restrict_existing_file(self.fw_cred_file)

    # ════════════════════════════════════════════════════════════
    # DEVICE CRUD
    # ════════════════════════════════════════════════════════════
    def _load_devices(self):
        if not os.path.exists(self.devices_file):
            self._devices = []
            return
        try:
            with open(self.devices_file, "r", encoding="utf-8") as f:
                self._devices = json.load(f)
        except (json.JSONDecodeError, IOError):
            self._devices = []
            return
        # Backward compat: ensure every device has the per-device-creds fields
        # (added in a later version). Old devices.json files won't have them.
        for d in self._devices:
            if "use_device_creds" not in d:
                d["use_device_creds"] = False
            if "device_username" not in d:
                d["device_username"] = ""
            if "device_password" not in d:
                d["device_password"] = ""
            if "device_enable_password" not in d:
                d["device_enable_password"] = ""
            # Decrypt per-device credential fields (fixes C1)
            d_decrypted = decrypt_creds_dict(d)
            d["device_username"] = d_decrypted.get("device_username", d.get("device_username", ""))
            d["device_password"] = d_decrypted.get("device_password", d.get("device_password", ""))
            d["device_enable_password"] = d_decrypted.get("device_enable_password", d.get("device_enable_password", ""))

    def _save_devices(self):
        # Encrypt per-device credential fields before writing (fixes C1)
        encrypted_devices = []
        for d in self._devices:
            enc_d = encrypt_creds_dict(d)
            encrypted_devices.append(enc_d)
        with self._lock:
            secure_write_json(self.devices_file, encrypted_devices)

    def add_device(
        self,
        hostname: str,
        ip_address: str,
        device_type: str,
        location: str,
        vendor: str = "cisco_ios",
        port: int = 22,
        use_device_creds: bool = False,
        device_username: str = "",
        device_password: str = "",
        device_enable_password: str = "",
    ) -> Dict:
        """
        Add a new device.

        Args:
            hostname    : device hostname / label
            ip_address  : management IP
            device_type : 'router' | 'switch' | 'firewall'
            location    : physical site (used in the backup tree path)
            vendor      : vendor key. For Router/Switch this is the netmiko
                          device_type (cisco_ios, juniper_junos, ...). For
                          Firewall this is the firewall vendor key
                          (fortigate, checkpoint, sonicwall, ...).
            port        : SSH port (default 22)
        """
        # Fix H10: Validate IP address
        if not validate_ip_address(ip_address):
            raise ValueError(f"Invalid IP address or hostname: {ip_address}")
        if not validate_port(port):
            raise ValueError(f"Invalid port number: {port} (must be 1-65535)")

        device = {
            "id": str(uuid.uuid4()),
            "hostname": hostname,
            "ip_address": ip_address,
            "device_type": device_type.lower(),
            "location": location.strip(),
            "vendor": vendor,
            "port": port,
            "added_at": datetime.now().isoformat(),
            "last_backup": None,
            "last_status": None,
            # Per-device credential override (optional).
            "use_device_creds": bool(use_device_creds),
            "device_username": device_username or "",
            "device_password": device_password or "",
            "device_enable_password": device_enable_password or "",
        }
        self._devices.append(device)
        self._save_devices()
        return device

    def remove_device(self, device_id: str) -> bool:
        original = len(self._devices)
        self._devices = [d for d in self._devices if d["id"] != device_id]
        if len(self._devices) < original:
            self._save_devices()
            return True
        return False

    def update_device(self, device_id: str, **kwargs) -> Optional[Dict]:
        for d in self._devices:
            if d["id"] == device_id:
                for k, v in kwargs.items():
                    if k in d and k != "id":
                        d[k] = v
                self._save_devices()
                return d
        return None

    def get_device(self, device_id: str) -> Optional[Dict]:
        for d in self._devices:
            if d["id"] == device_id:
                return d
        return None

    def get_all_devices(self) -> List[Dict]:
        return list(self._devices)

    def get_routers(self) -> List[Dict]:
        return [d for d in self._devices if d["device_type"] == "router"]

    def get_switches(self) -> List[Dict]:
        return [d for d in self._devices if d["device_type"] == "switch"]

    def get_firewalls(self) -> List[Dict]:
        return [d for d in self._devices if d["device_type"] == "firewall"]

    def get_by_type(self, device_type: str) -> List[Dict]:
        return [d for d in self._devices if d["device_type"] == device_type.lower()]

    def get_locations(self) -> List[str]:
        return sorted(set(d["location"] for d in self._devices if d["location"]))

    def update_backup_status(self, device_id: str, success: bool, timestamp: str = None):
        with self._lock:
            for d in self._devices:
                if d["id"] == device_id:
                    d["last_status"] = "success" if success else "failed"
                    d["last_backup"] = timestamp or datetime.now().isoformat()
                    break
        self._save_devices()

    def device_count(self) -> int:
        return len(self._devices)

    # ════════════════════════════════════════════════════════════
    # PER-DEVICE CREDENTIAL OVERRIDE
    # ════════════════════════════════════════════════════════════
    # Each device can optionally store its own credentials
    # (username / password / enable_password) that override the
    # shared SSH creds, single-credential-mode creds, or per-vendor
    # firewall creds. This is for devices that use local credentials
    # different from the rest of the fleet.
    # ════════════════════════════════════════════════════════════
    def set_device_credentials(
        self,
        device_id: str,
        username: str,
        password: str,
        enable_password: str = "",
        use_device_creds: bool = True,
    ):
        """Set per-device credentials for a specific device."""
        for d in self._devices:
            if d["id"] == device_id:
                d["use_device_creds"] = bool(use_device_creds)
                d["device_username"] = username or ""
                d["device_password"] = password or ""
                d["device_enable_password"] = enable_password or ""
                self._save_devices()
                return True
        return False

    def clear_device_credentials(self, device_id: str):
        """Remove the per-device credential override (fall back to shared/per-vendor creds)."""
        for d in self._devices:
            if d["id"] == device_id:
                d["use_device_creds"] = False
                d["device_username"] = ""
                d["device_password"] = ""
                d["device_enable_password"] = ""
                self._save_devices()
                return True
        return False

    def get_device_credentials(self, device_id: str) -> Optional[Dict]:
        """Return the per-device credential dict, or None if device not found."""
        d = self.get_device(device_id)
        if not d:
            return None
        return {
            "use_device_creds": d.get("use_device_creds", False),
            "username": d.get("device_username", ""),
            "password": d.get("device_password", ""),
            "enable_password": d.get("device_enable_password", ""),
        }

    def has_device_credentials(self, device_id: str) -> bool:
        """True if this device has per-device creds enabled and populated."""
        d = self.get_device(device_id)
        if not d:
            return False
        return bool(
            d.get("use_device_creds")
            and d.get("device_username")
            and d.get("device_password")
        )

    # ════════════════════════════════════════════════════════════
    # SHARED SSH CREDENTIALS (Router / Switch)
    # ════════════════════════════════════════════════════════════
    # The shared credentials slot stores:
    #   {
    #     "username":             str,
    #     "password":             str,
    #     "enable_password":      str,
    #     "use_single_credential": bool,  # if True, these creds also
    #                                     # apply to all firewalls that
    #                                     # don't have an explicit
    #                                     # per-vendor override
    #   }
    # When use_single_credential is True, the engine pushes the shared
    # creds into every firewall vendor slot that doesn't already have an
    # explicit per-vendor override. This lets users with one common
    # credential across their whole fleet avoid entering it N times.
    # ════════════════════════════════════════════════════════════
    def _load_shared_credentials(self):
        if not os.path.exists(self.shared_cred_file):
            self._shared_creds = {
                "username": "", "password": "", "enable_password": "",
                "use_single_credential": False,
            }
            return
        try:
            with open(self.shared_cred_file, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, dict):
                # Decrypt credential fields (fixes C1: credentials were plaintext)
                raw = decrypt_creds_dict(raw)
                self._shared_creds = {
                    "username": raw.get("username", ""),
                    "password": raw.get("password", ""),
                    "enable_password": raw.get("enable_password", ""),
                    "use_single_credential": raw.get("use_single_credential", False),
                }
            elif isinstance(raw, list) and len(raw) >= 3:
                # Backward compat: old tuple format [user, pass, enable]
                self._shared_creds = {
                    "username": raw[0] or "",
                    "password": raw[1] or "",
                    "enable_password": raw[2] or "",
                    "use_single_credential": False,
                }
            else:
                self._shared_creds = {
                    "username": "", "password": "", "enable_password": "",
                    "use_single_credential": False,
                }
        except (json.JSONDecodeError, IOError):
            self._shared_creds = {
                "username": "", "password": "", "enable_password": "",
                "use_single_credential": False,
            }

    def _save_shared_credentials(self):
        # Encrypt credential fields before writing to disk (fixes C1)
        encrypted = encrypt_creds_dict(self._shared_creds)
        secure_write_json(self.shared_cred_file, encrypted)

    def set_shared_credentials(
        self,
        username: str,
        password: str,
        enable_password: str = "",
        use_single_credential: bool = False,
    ):
        """Set the shared SSH credentials.

        Args:
            username: SSH/API username
            password: SSH/API password
            enable_password: Cisco enable secret (optional)
            use_single_credential: if True, these credentials also apply
                to all firewalls that don't have an explicit per-vendor
                override. Lets users with one common credential avoid
                entering it per-vendor.
        """
        self._shared_creds = {
            "username": username,
            "password": password,
            "enable_password": enable_password or "",
            "use_single_credential": bool(use_single_credential),
        }
        self._save_shared_credentials()

    def get_shared_credentials(self) -> Dict:
        return dict(self._shared_creds)

    def has_shared_credentials(self) -> bool:
        return bool(
            self._shared_creds.get("username") and self._shared_creds.get("password")
        )

    def is_single_credential_mode(self) -> bool:
        """True if the shared creds should also apply to all firewalls."""
        return bool(self._shared_creds.get("use_single_credential"))

    # ════════════════════════════════════════════════════════════
    # PER-VENDOR FIREWALL CREDENTIALS
    # ════════════════════════════════════════════════════════════
    def _load_fw_credentials(self):
        if not os.path.exists(self.fw_cred_file):
            self._fw_credentials = {}
            return
        try:
            with open(self.fw_cred_file, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except (json.JSONDecodeError, IOError):
            self._fw_credentials = {}
            return

        creds = {}
        for vkey, val in raw.items():
            if isinstance(val, dict):
                # Decrypt credential fields (fixes C1)
                val = decrypt_creds_dict(val)
                creds[vkey] = {
                    "username": val.get("username", ""),
                    "password": val.get("password", ""),
                    "enable_password": val.get("enable_password", ""),
                    "api_token": val.get("api_token", ""),
                }
            elif isinstance(val, list) and len(val) >= 3:
                # Backward compat: old tuple format
                creds[vkey] = {
                    "username": val[0] or "",
                    "password": val[1] or "",
                    "enable_password": val[2] or "",
                    "api_token": val[3] if len(val) > 3 else "",
                }
        self._fw_credentials = creds

    def _save_fw_credentials(self):
        # Encrypt all credential fields before writing to disk (fixes C1)
        encrypted = {}
        for vkey, creds in self._fw_credentials.items():
            encrypted[vkey] = encrypt_creds_dict(creds)
        secure_write_json(self.fw_cred_file, encrypted)

    def set_fw_credentials(
        self,
        vendor_key: str,
        username: str = "",
        password: str = "",
        enable_password: str = "",
        api_token: str = "",
    ):
        existing = self._fw_credentials.get(vendor_key, {})
        self._fw_credentials[vendor_key] = {
            "username": username or existing.get("username", ""),
            "password": password or existing.get("password", ""),
            "enable_password": enable_password or existing.get("enable_password", ""),
            "api_token": api_token or existing.get("api_token", ""),
        }
        self._save_fw_credentials()

    def set_fw_credentials_dict(self, vendor_key: str, creds: Dict):
        self._fw_credentials[vendor_key] = {
            "username": creds.get("username", ""),
            "password": creds.get("password", ""),
            "enable_password": creds.get("enable_password", ""),
            "api_token": creds.get("api_token", ""),
        }
        self._save_fw_credentials()

    def get_fw_credentials(self, vendor_key: str) -> Optional[Dict]:
        return self._fw_credentials.get(vendor_key)

    def has_fw_ssh_credentials(self, vendor_key: str) -> bool:
        c = self._fw_credentials.get(vendor_key)
        return bool(c and c.get("username") and c.get("password"))

    def has_fw_api_credentials(self, vendor_key: str) -> bool:
        c = self._fw_credentials.get(vendor_key)
        if not c:
            return False
        return bool(c.get("api_token")) or (
            bool(c.get("username")) and bool(c.get("password"))
        )

    def has_fw_credentials(self, vendor_key: str) -> bool:
        return self.has_fw_ssh_credentials(vendor_key) or self.has_fw_api_credentials(vendor_key)

    def list_configured_fw_vendors(self) -> List[str]:
        return [k for k in self._fw_credentials.keys() if self.has_fw_credentials(k)]

    # ════════════════════════════════════════════════════════════
    # CSV IMPORT / EXPORT
    # ════════════════════════════════════════════════════════════
    def import_devices_from_csv(self, filepath: str) -> int:
        """Import devices from CSV with validation (fixes H9).
        Skips invalid rows and continues importing the rest."""
        import csv
        count = 0
        skipped = 0
        with open(filepath, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    hostname = row.get("hostname", "").strip()
                    ip_address = row.get("ip_address", "").strip()
                    if not hostname or not ip_address:
                        skipped += 1
                        continue
                    port_str = row.get("port", "22").strip()
                    try:
                        port = int(port_str) if port_str else 22
                    except ValueError:
                        port = 22
                    self.add_device(
                        hostname=hostname,
                        ip_address=ip_address,
                        device_type=row.get("device_type", "router").strip().lower(),
                        location=row.get("location", "Default").strip(),
                        vendor=row.get("vendor", "cisco_ios").strip(),
                        port=port,
                    )
                    count += 1
                except ValueError:
                    skipped += 1
                    continue
        if skipped > 0:
            import warnings
            warnings.warn(f"{skipped} row(s) skipped due to validation errors")
        return count

    def export_devices_to_csv(self, filepath: str):
        import csv
        fieldnames = [
            "hostname", "ip_address", "device_type", "vendor",
            "location", "port", "last_backup", "last_status",
        ]
        with open(filepath, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for d in self._devices:
                writer.writerow(d)

    def clear_all_devices(self):
        self._devices = []
        self._save_devices()
