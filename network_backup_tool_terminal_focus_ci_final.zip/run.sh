#!/usr/bin/env bash
# ============================================================
#  Network Backup Tool - Portable Runner (Linux / macOS)
#  PREREQUISITE: Python 3.8+ must be installed
# ============================================================
set -e

echo
echo "  Network Backup Tool - Portable Runner"
echo

if ! command -v python3 >/dev/null 2>&1; then
    echo "  [ERROR] python3 not found. Please install Python 3.8+."
    exit 1
fi

echo "  Checking dependencies..."
pip3 install --quiet netmiko reportlab paramiko 2>/dev/null || true

echo "  Starting Network Backup Tool..."
python3 main.py
