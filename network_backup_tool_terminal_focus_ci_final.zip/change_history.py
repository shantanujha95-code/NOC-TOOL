"""
Change History / Audit Trail
=============================

Logs every configuration change (config push) with timestamp, device,
commands, and result. Provides query/filter for the audit trail.

Inspired by SolarWinds NCM and ManageEngine NCM change management modules.
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Optional
from security_utils import secure_write_json, restrict_existing_file


HISTORY_FILE = "change_history.json"


class ChangeRecord:
    """A single configuration change record.

    The 'source' field distinguishes between:
      - "config_push"  : changes pushed via the Config Push panel (bulk or individual)
      - "interactive"  : commands typed manually in the interactive SSH terminal
    """

    def __init__(
        self,
        timestamp: str = "",
        device_id: str = "",
        hostname: str = "",
        ip_address: str = "",
        device_type: str = "",
        commands: List[str] = None,
        success: bool = False,
        error: str = "",
        output: str = "",
        pushed_by: str = "operator",
        source: str = "config_push",
    ):
        self.timestamp = timestamp or datetime.now().isoformat()
        self.device_id = device_id
        self.hostname = hostname
        self.ip_address = ip_address
        self.device_type = device_type
        self.commands = commands or []
        self.success = success
        self.error = error
        self.output = output
        self.pushed_by = pushed_by
        self.source = source

    def to_dict(self) -> Dict:
        return {
            "timestamp": self.timestamp,
            "device_id": self.device_id,
            "hostname": self.hostname,
            "ip_address": self.ip_address,
            "device_type": self.device_type,
            "commands": self.commands,
            "success": self.success,
            "error": self.error,
            "output": self.output[:1000],  # truncate for storage
            "pushed_by": self.pushed_by,
            "source": self.source,
        }

    @classmethod
    def from_dict(cls, d: Dict) -> "ChangeRecord":
        return cls(
            timestamp=d.get("timestamp", ""),
            device_id=d.get("device_id", ""),
            hostname=d.get("hostname", ""),
            ip_address=d.get("ip_address", ""),
            device_type=d.get("device_type", ""),
            commands=d.get("commands", []),
            success=d.get("success", False),
            error=d.get("error", ""),
            output=d.get("output", ""),
            pushed_by=d.get("pushed_by", "operator"),
            source=d.get("source", "config_push"),
        )


class ChangeHistory:
    """Manages the change history / audit trail."""

    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        self.history_file = os.path.join(data_dir, HISTORY_FILE)
        self._records: List[ChangeRecord] = []
        self._load()
        restrict_existing_file(self.history_file)

    def _load(self):
        if not os.path.exists(self.history_file):
            self._records = []
            return
        try:
            with open(self.history_file, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if isinstance(raw, list):
                self._records = [ChangeRecord.from_dict(d) for d in raw if isinstance(d, dict)]
        except (json.JSONDecodeError, IOError):
            self._records = []

    def _save(self):
        secure_write_json(self.history_file, [r.to_dict() for r in self._records])

    def add(self, record: ChangeRecord):
        """Add a change record to the history."""
        self._records.append(record)
        self._save()

    def get_all(self) -> List[ChangeRecord]:
        """Return all change records, newest first."""
        return sorted(self._records, key=lambda r: r.timestamp, reverse=True)

    def get_for_device(self, device_id: str) -> List[ChangeRecord]:
        """Return change records for a specific device, newest first."""
        return sorted(
            [r for r in self._records if r.device_id == device_id],
            key=lambda r: r.timestamp,
            reverse=True,
        )

    def get_recent(self, limit: int = 50) -> List[ChangeRecord]:
        """Return the N most recent change records."""
        return self.get_all()[:limit]

    def clear(self):
        """Clear all change history."""
        self._records = []
        self._save()

    def count(self) -> int:
        return len(self._records)
