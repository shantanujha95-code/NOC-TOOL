"""
Report Generator
================

Creates a professional PDF report summarizing backup operations across
all device types (Router / Switch / Firewall), including a per-device
config-diff summary section.
"""

import os
import hashlib
from datetime import datetime
from typing import List, Dict, Optional

from backup_engine import BackupResult
from security_utils import xml_escape
from vendors import vendor_label as _fw_vendor_label


# ── hashlib.md5 compatibility shim (Python 3.8 compat for reportlab) ──
# ReportLab calls md5(data, usedforsecurity=False); the kwarg only exists
# in Python 3.9+. On older interpreters this raises:
#     TypeError: usedforsecurity is an invalid keyword argument for openssl md5()
_ORIG_MD5 = hashlib.md5

def _md5_compat(data=b"", *, usedforsecurity=True):
    try:
        return _ORIG_MD5(data, usedforsecurity=usedforsecurity)
    except TypeError:
        return _ORIG_MD5(data)

if not getattr(hashlib, "_ubt_md5_patched", False):
    hashlib.md5 = _md5_compat
    hashlib._ubt_md5_patched = True
# ── end shim ────────────────────────────────────────────────────


# ── Colour palette ──────────────────────────────────────────────
DARK_BLUE  = (26, 58, 95)
MED_BLUE   = (41, 98, 155)
LIGHT_BLUE = (220, 232, 245)
GREEN      = (34, 139, 34)
RED        = (200, 40, 40)
ORANGE     = (210, 120, 20)
GRAY       = (100, 100, 100)
WHITE      = (255, 255, 255)
BLACK      = (0, 0, 0)


def _hex(rgb):
    return "#{:02x}{:02x}{:02x}".format(*rgb)


def _vendor_display(device_type: str, vendor_key: str) -> str:
    """Return a human-friendly vendor label for the report."""
    if device_type == "firewall":
        return _fw_vendor_label(vendor_key)
    # For router/switch, vendor_key IS the netmiko device_type
    return vendor_key


class UnifiedReportGenerator:
    """Generates a PDF report summarizing backup operations."""

    def __init__(self, output_dir: str = "."):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def generate(
        self,
        results: List[BackupResult],
        all_devices: List[Dict] = None,
        title: str = "Network Backup Report",
    ) -> str:
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.units import mm, cm
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.enums import TA_CENTER
            from reportlab.platypus import (
                SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                PageBreak, HRFlowable, KeepTogether, Preformatted,
            )
            from reportlab.lib.colors import HexColor
        except ImportError:
            raise ImportError(
                "reportlab is required for PDF reports. "
                "Install with: pip install reportlab"
            )

        timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        filename = f"Backup_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        filepath = os.path.join(self.output_dir, filename)

        doc = SimpleDocTemplate(
            filepath, pagesize=A4,
            topMargin=2 * cm, bottomMargin=2 * cm,
            leftMargin=2 * cm, rightMargin=2 * cm,
        )

        styles = getSampleStyleSheet()
        story = []

        styles.add(ParagraphStyle(
            name="CoverTitle", parent=styles["Title"],
            fontSize=26, leading=32,
            textColor=HexColor(_hex(DARK_BLUE)),
            spaceAfter=6 * mm, alignment=TA_CENTER,
        ))
        styles.add(ParagraphStyle(
            name="CoverSubtitle", parent=styles["Normal"],
            fontSize=12, textColor=HexColor(_hex(GRAY)),
            alignment=TA_CENTER, spaceAfter=3 * mm,
        ))
        styles.add(ParagraphStyle(
            name="SectionHead", parent=styles["Heading2"],
            fontSize=16, leading=20,
            textColor=HexColor(_hex(DARK_BLUE)),
            spaceBefore=6 * mm, spaceAfter=4 * mm,
        ))
        styles.add(ParagraphStyle(
            name="BodyText2", parent=styles["Normal"],
            fontSize=10, leading=14,
            textColor=HexColor(_hex(BLACK)),
            spaceAfter=2 * mm,
        ))
        styles.add(ParagraphStyle(
            name="DiffStyle", parent=styles["Normal"],
            fontName="Courier", fontSize=7, leading=9,
            textColor=HexColor(_hex(BLACK)),
        ))
        # ── Cell-paragraph styles for table cells (so text wraps) ──
        # These are used to wrap long text inside Table cells, which
        # plain strings don't do (they overflow past the column width
        # and get clipped at the page edge).
        styles.add(ParagraphStyle(
            name="CellText", parent=styles["Normal"],
            fontName="Helvetica", fontSize=8, leading=10,
            textColor=HexColor(_hex(BLACK)),
        ))
        styles.add(ParagraphStyle(
            name="CellTextBold", parent=styles["Normal"],
            fontName="Helvetica-Bold", fontSize=8, leading=10,
            textColor=HexColor(_hex(BLACK)),
        ))
        styles.add(ParagraphStyle(
            name="CellTextSmall", parent=styles["Normal"],
            fontName="Helvetica", fontSize=7, leading=9,
            textColor=HexColor(_hex(BLACK)),
        ))
        styles.add(ParagraphStyle(
            name="CellTextRed", parent=styles["Normal"],
            fontName="Helvetica", fontSize=8, leading=10,
            textColor=HexColor(_hex(RED)),
        ))
        styles.add(ParagraphStyle(
            name="CellTextGreen", parent=styles["Normal"],
            fontName="Helvetica-Bold", fontSize=8, leading=10,
            textColor=HexColor(_hex(GREEN)),
        ))
        styles.add(ParagraphStyle(
            name="CellHeader", parent=styles["Normal"],
            fontName="Helvetica-Bold", fontSize=8, leading=10,
            textColor=HexColor(_hex(WHITE)),
            alignment=TA_CENTER,
        ))
        styles.add(ParagraphStyle(
            name="CellHeaderCenter", parent=styles["Normal"],
            fontName="Helvetica-Bold", fontSize=9, leading=11,
            textColor=HexColor(_hex(WHITE)),
            alignment=TA_CENTER,
        ))

        # ── Helper: wrap a string in a Paragraph so it wraps inside a Table cell ──
        def _cell(text, style_name="CellText"):
            """Convert a string to a Paragraph for table cell wrapping."""
            if text is None:
                text = ""
            text = str(text)
            # Escape XML special characters that would break Paragraph parsing
            text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            return Paragraph(text, styles[style_name])

        def add_page_number(canvas, doc_obj):
            canvas.saveState()
            canvas.setFont("Helvetica", 8)
            canvas.setFillColor(HexColor(_hex(GRAY)))
            canvas.drawCentredString(A4[0] / 2, 1.2 * cm, f"Page {canvas.getPageNumber()}")
            canvas.setStrokeColor(HexColor(_hex(LIGHT_BLUE)))
            canvas.setLineWidth(0.5)
            canvas.line(2 * cm, 1.5 * cm, A4[0] - 2 * cm, 1.5 * cm)
            canvas.restoreState()

        # ════════════════════════════════════════════════════════
        # COVER PAGE
        # ════════════════════════════════════════════════════════
        story.append(Spacer(1, 60 * mm))
        story.append(Paragraph(title, styles["CoverTitle"]))
        story.append(Spacer(1, 5 * mm))
        story.append(HRFlowable(
            width="60%", thickness=2,
            color=HexColor(_hex(MED_BLUE)),
            spaceAfter=5 * mm, spaceBefore=2 * mm, hAlign="CENTER",
        ))
        story.append(Paragraph(f"Generated: {timestamp_str}", styles["CoverSubtitle"]))
        story.append(Spacer(1, 10 * mm))

        success_count = sum(1 for r in results if r.success)
        fail_count = sum(1 for r in results if not r.success)
        total_count = len(results)

        summary_data = [
            [_cell("Total Devices", "CellHeaderCenter"),
             _cell("Successful", "CellHeaderCenter"),
             _cell("Failed", "CellHeaderCenter"),
             _cell("Success Rate", "CellHeaderCenter")],
            [_cell(str(total_count), "CellTextBold"),
             _cell(str(success_count), "CellTextBold"),
             _cell(str(fail_count), "CellTextBold"),
             _cell(f"{(success_count / total_count * 100):.1f}%" if total_count else "N/A", "CellTextBold")],
        ]
        summary_table = Table(summary_data, colWidths=[90, 80, 80, 80])
        summary_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), HexColor(_hex(DARK_BLUE))),
            ("TEXTCOLOR", (0, 0), (-1, 0), HexColor(_hex(WHITE))),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 11),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("GRID", (0, 0), (-1, -1), 0.5, HexColor(_hex(GRAY))),
            ("BACKGROUND", (0, 1), (-1, 1), HexColor(_hex(LIGHT_BLUE))),
            ("TOPPADDING", (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(summary_table)
        story.append(PageBreak())

        # ════════════════════════════════════════════════════════
        # 1. DEVICE INVENTORY
        # ════════════════════════════════════════════════════════
        story.append(Paragraph("1. Device Inventory", styles["SectionHead"]))
        if all_devices:
            story.append(Paragraph(
                f"Total registered devices: <b>{len(all_devices)}</b>",
                styles["BodyText2"],
            ))
            routers = [d for d in all_devices if d["device_type"] == "router"]
            switches = [d for d in all_devices if d["device_type"] == "switch"]
            firewalls = [d for d in all_devices if d["device_type"] == "firewall"]
            locations = sorted(set(d.get("location", "Unknown") for d in all_devices))

            inv_data = [
                [_cell("Property", "CellHeaderCenter"), _cell("Value", "CellHeaderCenter")],
                [_cell("Routers", "CellTextBold"), _cell(str(len(routers)))],
                [_cell("Switches", "CellTextBold"), _cell(str(len(switches)))],
                [_cell("Firewalls", "CellTextBold"), _cell(str(len(firewalls)))],
                [_cell("Locations", "CellTextBold"),
                 _cell(", ".join(locations) if locations else "N/A")],
            ]
            inv_table = Table(inv_data, colWidths=[120, 350])
            inv_table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), HexColor(_hex(MED_BLUE))),
                ("TEXTCOLOR", (0, 0), (-1, 0), HexColor(_hex(WHITE))),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTNAME", (0, 1), (0, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 10),
                ("GRID", (0, 0), (-1, -1), 0.5, HexColor(_hex(GRAY))),
                ("BACKGROUND", (0, 1), (0, -1), HexColor(_hex(LIGHT_BLUE))),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
            ]))
            story.append(inv_table)
            story.append(Spacer(1, 4 * mm))

            # Full device table — all cells wrapped in Paragraphs so long
            # hostnames, vendor names, and locations wrap within their columns
            # instead of overflowing past the page edge.
            dev_header = [
                _cell("#", "CellHeaderCenter"),
                _cell("Hostname", "CellHeaderCenter"),
                _cell("IP Address", "CellHeaderCenter"),
                _cell("Type", "CellHeaderCenter"),
                _cell("Vendor", "CellHeaderCenter"),
                _cell("Location", "CellHeaderCenter"),
                _cell("Port", "CellHeaderCenter"),
            ]
            dev_rows = [dev_header]
            for i, d in enumerate(all_devices, 1):
                dev_rows.append([
                    _cell(str(i), "CellTextSmall"),
                    _cell(d["hostname"], "CellTextSmall"),
                    _cell(d["ip_address"], "CellTextSmall"),
                    _cell(d["device_type"].title(), "CellTextSmall"),
                    _cell(_vendor_display(d["device_type"], d.get("vendor", "")), "CellTextSmall"),
                    _cell(d.get("location", "N/A"), "CellTextSmall"),
                    _cell(str(d.get("port", 22)), "CellTextSmall"),
                ])
            dev_table = Table(dev_rows, colWidths=[22, 80, 80, 50, 80, 80, 35])
            dev_style_cmds = [
                ("BACKGROUND", (0, 0), (-1, 0), HexColor(_hex(DARK_BLUE))),
                ("TEXTCOLOR", (0, 0), (-1, 0), HexColor(_hex(WHITE))),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 9),
                ("FONTSIZE", (0, 1), (-1, -1), 8),
                ("ALIGN", (0, 0), (0, -1), "CENTER"),
                ("ALIGN", (6, 0), (6, -1), "CENTER"),
                ("GRID", (0, 0), (-1, -1), 0.4, HexColor(_hex(GRAY))),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
            for i in range(1, len(dev_rows)):
                if i % 2 == 0:
                    dev_style_cmds.append(
                        ("BACKGROUND", (0, i), (-1, i), HexColor(_hex(LIGHT_BLUE)))
                    )
            dev_table.setStyle(TableStyle(dev_style_cmds))
            story.append(dev_table)
        else:
            story.append(Paragraph("No device inventory data available.", styles["BodyText2"]))

        story.append(PageBreak())

        # ════════════════════════════════════════════════════════
        # 2. BACKUP RESULTS
        # ════════════════════════════════════════════════════════
        story.append(Paragraph("2. Backup Results", styles["SectionHead"]))

        if not results:
            story.append(Paragraph("No backup operations were performed.", styles["BodyText2"]))
        else:
            res_header = [
                _cell("#", "CellHeaderCenter"),
                _cell("Hostname", "CellHeaderCenter"),
                _cell("IP", "CellHeaderCenter"),
                _cell("Type", "CellHeaderCenter"),
                _cell("Method", "CellHeaderCenter"),
                _cell("Status", "CellHeaderCenter"),
                _cell("Diff", "CellHeaderCenter"),
            ]
            res_rows = [res_header]
            for i, r in enumerate(results, 1):
                status_text = "SUCCESS" if r.success else "FAILED"
                diff_short = r.diff_summary if r.success else "-"
                status_style = "CellTextGreen" if r.success else "CellTextRed"
                res_rows.append([
                    _cell(str(i), "CellTextSmall"),
                    _cell(r.hostname, "CellTextSmall"),
                    _cell(r.ip_address, "CellTextSmall"),
                    _cell(r.device_type.title(), "CellTextSmall"),
                    _cell(r.backup_method.upper() if r.success else "-", "CellTextSmall"),
                    _cell(status_text, status_style),
                    _cell(diff_short, "CellTextSmall"),
                ])
            res_table = Table(res_rows, colWidths=[20, 65, 65, 50, 45, 55, 90])
            res_style_cmds = [
                ("BACKGROUND", (0, 0), (-1, 0), HexColor(_hex(DARK_BLUE))),
                ("TEXTCOLOR", (0, 0), (-1, 0), HexColor(_hex(WHITE))),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 8),
                ("FONTSIZE", (0, 1), (-1, -1), 7),
                ("ALIGN", (0, 0), (0, -1), "CENTER"),
                ("GRID", (0, 0), (-1, -1), 0.4, HexColor(_hex(GRAY))),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ]
            for i, r in enumerate(results, 1):
                if r.success:
                    res_style_cmds.append(
                        ("TEXTCOLOR", (5, i), (5, i), HexColor(_hex(GREEN)))
                    )
                else:
                    res_style_cmds.append(
                        ("TEXTCOLOR", (5, i), (5, i), HexColor(_hex(RED)))
                    )
                if i % 2 == 0:
                    res_style_cmds.append(
                        ("BACKGROUND", (0, i), (-1, i), HexColor(_hex(LIGHT_BLUE)))
                    )
            res_table.setStyle(TableStyle(res_style_cmds))
            story.append(res_table)

            failed = [r for r in results if not r.success]
            if failed:
                story.append(Spacer(1, 6 * mm))
                story.append(Paragraph("2.1 Failed Backups - Detail", styles["SectionHead"]))
                for r in failed:
                    fail_data = [
                        [_cell("Device", "CellTextBold"), _cell(r.hostname)],
                        [_cell("IP Address", "CellTextBold"), _cell(r.ip_address)],
                        [_cell("Type", "CellTextBold"), _cell(r.device_type.title())],
                        [_cell("Vendor", "CellTextBold"),
                         _cell(_vendor_display(r.device_type, r.vendor))],
                        [_cell("Error", "CellTextBold"), _cell(r.error_message)],
                    ]
                    fail_table = Table(fail_data, colWidths=[80, 390])
                    fail_table.setStyle(TableStyle([
                        ("BACKGROUND", (0, 0), (0, -1), HexColor("#fde8e8")),
                        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                        ("FONTSIZE", (0, 0), (-1, -1), 9),
                        ("GRID", (0, 0), (-1, -1), 0.4, HexColor(_hex(RED))),
                        ("TOPPADDING", (0, 0), (-1, -1), 5),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                        ("LEFTPADDING", (0, 0), (-1, -1), 6),
                    ]))
                    story.append(KeepTogether([fail_table, Spacer(1, 3 * mm)]))

        story.append(PageBreak())

        # ════════════════════════════════════════════════════════
        # 3. CONFIGURATION CHANGES (DIFF SUMMARY)
        # ════════════════════════════════════════════════════════
        story.append(Paragraph("3. Configuration Changes", styles["SectionHead"]))

        changed = [r for r in results if r.success and r.diff_summary
                   and r.diff_summary not in ("No changes", "First backup (no previous version)")]
        unchanged = [r for r in results if r.success and r.diff_summary == "No changes"]
        first_backup = [r for r in results if r.success
                        and r.diff_summary == "First backup (no previous version)"]

        diff_summary_data = [
            [_cell("Category", "CellHeaderCenter"), _cell("Count", "CellHeaderCenter")],
            [_cell("Changed since last backup", "CellTextBold"), _cell(str(len(changed)))],
            [_cell("Unchanged", "CellTextBold"), _cell(str(len(unchanged)))],
            [_cell("First backup (no baseline)", "CellTextBold"), _cell(str(len(first_backup)))],
            [_cell("Failed (no diff)", "CellTextBold"), _cell(str(fail_count))],
        ]
        diff_table = Table(diff_summary_data, colWidths=[200, 80])
        diff_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), HexColor(_hex(MED_BLUE))),
            ("TEXTCOLOR", (0, 0), (-1, 0), HexColor(_hex(WHITE))),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTNAME", (0, 1), (0, -1), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 10),
            ("GRID", (0, 0), (-1, -1), 0.5, HexColor(_hex(GRAY))),
            ("BACKGROUND", (0, 1), (0, -1), HexColor(_hex(LIGHT_BLUE))),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(diff_table)
        story.append(Spacer(1, 5 * mm))

        if changed:
            story.append(Paragraph("3.1 Diff Details (changed devices)", styles["SectionHead"]))
            for r in changed:
                story.append(Paragraph(
                    f"<b>{xml_escape(r.hostname)}</b> ({xml_escape(r.ip_address)}) — {xml_escape(r.device_type.title())} — "
                    f"<font color='{_hex(ORANGE)}'>{xml_escape(r.diff_summary)}</font>",
                    styles["BodyText2"],
                ))
                if r.diff_text:
                    diff_lines = r.diff_text.splitlines()
                    truncated = diff_lines[:200]
                    if len(diff_lines) > 200:
                        truncated.append(
                            f"... ({len(diff_lines) - 200} more lines truncated)"
                        )
                    pre = Preformatted("\n".join(truncated), styles["DiffStyle"])
                    story.append(pre)
                story.append(Spacer(1, 4 * mm))

        story.append(PageBreak())

        # ════════════════════════════════════════════════════════
        # 4. SUMMARY & RECOMMENDATIONS
        # ════════════════════════════════════════════════════════
        story.append(Paragraph("4. Summary & Recommendations", styles["SectionHead"]))

        if results:
            rate = (success_count / total_count * 100) if total_count else 0
            if rate == 100:
                story.append(Paragraph(
                    "All devices were backed up successfully. No action required.",
                    styles["BodyText2"],
                ))
            elif rate >= 80:
                story.append(Paragraph(
                    f"Most backups completed successfully ({rate:.1f}%). "
                    f"Please review the {fail_count} failed device(s) and retry.",
                    styles["BodyText2"],
                ))
            else:
                story.append(Paragraph(
                    f"Warning: Only {rate:.1f}% of backups succeeded. "
                    f"{fail_count} out of {total_count} devices failed. "
                    "Please verify network connectivity and credentials, then retry.",
                    styles["BodyText2"],
                ))

            if changed:
                story.append(Spacer(1, 3 * mm))
                story.append(Paragraph(
                    f"<b>Configuration drift detected on {len(changed)} device(s).</b> "
                    "Review the Diff Details section above to confirm the changes were intentional.",
                    styles["BodyText2"],
                ))

            if failed:
                story.append(Spacer(1, 3 * mm))
                story.append(Paragraph(
                    "<b>Recommendations for failed backups:</b>",
                    styles["BodyText2"],
                ))
                recommendations = [
                    "Verify the device is reachable (ping the management IP)",
                    "Check SSH is enabled on the device and the port is correct",
                    "For Router/Switch: confirm shared SSH credentials are valid",
                    "For Firewalls: confirm per-vendor credentials (Set Firewall Credentials)",
                    "For FortiGate: API needs an API token (Bearer) or username+password (Basic)",
                    "For SonicWall: XAPI uses HTTP Basic with management admin credentials",
                    "For Check Point: ensure the SSH user has clish access",
                    "Try the 'Retry Failed' option to re-run only the failed backups",
                ]
                for rec in recommendations:
                    story.append(Paragraph(f"  - {rec}", styles["BodyText2"]))
        else:
            story.append(Paragraph(
                "No backup operations have been performed yet. "
                "Add devices and run a backup to generate a detailed report.",
                styles["BodyText2"],
            ))

        doc.build(story, onFirstPage=add_page_number, onLaterPages=add_page_number)
        return filepath
