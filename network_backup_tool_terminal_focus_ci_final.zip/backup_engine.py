"""
Unified Backup Engine
=====================

Performs configuration backups for routers, switches, and firewalls.

Dispatch logic:
  - Router / Switch  →  simple SSH backup via netmiko (uses the shared
                        SSH credentials slot).
  - Firewall         →  vendor-specific backup via the vendor registry:
                        tries each method in `vendor.backup_priority`
                        (e.g. API first, SSH fallback). Uses per-vendor
                        firewall credentials.

All backups land at:
    backups/{Location}/{DeviceType}/{ip}_{timestamp}.txt

Where DeviceType is "Router", "Switches", or "Firewall" (matches the
folder names requested by the user).

Also computes a unified diff against the previous backup of the same
device, so the GUI activity log and PDF report can show what changed.
"""

import difflib
import os
import socket
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from vendors import FirewallVendor, get_vendor
from security_utils import sanitize_error_message


# ── Backup commands for Router/Switch vendors (netmiko device types) ──
# Firewalls use the vendor registry instead, so they don't appear here.
ROUTER_SWITCH_BACKUP_COMMANDS = {
    "cisco_ios":         ["show running-config"],
    "cisco_xe":          ["show running-config"],
    "cisco_xr":          ["show running-config"],
    "cisco_nxos":        ["show running-config"],
    "juniper_junos":     ["show configuration | display set"],
    "huawei":            ["display current-configuration"],
    "huawei_vrpv8":      ["display current-configuration"],
    "hp_comware":        ["display current-configuration"],
    "arista_eos":        ["show running-config"],
    "mikrotik_routeros": ["/export"],
    "ruckus_fastiron":   ["show running-config"],
    "extreme_exos":      ["show configuration"],
    "dell_os6":          ["show running-config"],
    "dell_os10":         ["show running-config"],
}


# ════════════════════════════════════════════════════════════════
# RESULT
# ════════════════════════════════════════════════════════════════

class BackupResult:
    """Outcome of a single device backup."""

    def __init__(
        self,
        device_id: str,
        hostname: str,
        ip_address: str,
        device_type: str,
        vendor: str,
        success: bool,
        filepath: Optional[str] = None,
        error_message: str = "",
        timestamp: str = "",
        config_text: str = "",
        backup_method: str = "ssh",   # "ssh" or "api"
        diff_summary: str = "",
        diff_text: str = "",
    ):
        self.device_id = device_id
        self.hostname = hostname
        self.ip_address = ip_address
        self.device_type = device_type
        self.vendor = vendor
        self.success = success
        self.filepath = filepath
        self.error_message = error_message
        self.timestamp = timestamp or datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.config_text = config_text
        self.backup_method = backup_method
        self.diff_summary = diff_summary
        self.diff_text = diff_text

    def to_dict(self) -> Dict:
        return {
            "device_id": self.device_id,
            "hostname": self.hostname,
            "ip_address": self.ip_address,
            "device_type": self.device_type,
            "vendor": self.vendor,
            "success": self.success,
            "filepath": self.filepath,
            "error_message": self.error_message,
            "timestamp": self.timestamp,
            "backup_method": self.backup_method,
            "diff_summary": self.diff_summary,
        }


# ════════════════════════════════════════════════════════════════
# ENGINE
# ════════════════════════════════════════════════════════════════

class UnifiedBackupEngine:
    """
    Core engine for performing network device backups.

    Routers and switches use a simple SSH path with the shared SSH
    credentials. Firewalls use the vendor registry and per-vendor
    credentials, with API-first / SSH-fallback dispatch.
    """

    # On-disk folder name per device type — matches the user's requested tree.
    DEVICE_TYPE_FOLDERS = {
        "router":   "Router",
        "switch":   "Switches",
        "firewall": "Firewall",
    }

    def __init__(self, backup_base_dir: str = "backups"):
        self.backup_base_dir = backup_base_dir
        # Shared SSH creds for Router/Switch
        self._shared_creds: Dict = {}
        # Per-vendor firewall creds: vendor_key -> {username, password, ...}
        self._fw_credentials: Dict[str, Dict] = {}

    # ── credential setters ─────────────────────────────────────
    def set_shared_credentials(self, username: str, password: str, enable_password: str = ""):
        self._shared_creds = {
            "username": username,
            "password": password,
            "enable_password": enable_password or "",
        }

    def set_shared_credentials_dict(self, creds: Dict):
        self._shared_creds = {
            "username": creds.get("username", ""),
            "password": creds.get("password", ""),
            "enable_password": creds.get("enable_password", ""),
        }

    def set_fw_credentials_dict(self, vendor_key: str, creds: Dict):
        self._fw_credentials[vendor_key] = {
            "username": creds.get("username", ""),
            "password": creds.get("password", ""),
            "enable_password": creds.get("enable_password", ""),
            "api_token": creds.get("api_token", ""),
        }

    def set_all_fw_credentials(self, creds: Dict[str, Dict]):
        self._fw_credentials = {}
        for vkey, c in creds.items():
            self._fw_credentials[vkey] = {
                "username": c.get("username", ""),
                "password": c.get("password", ""),
                "enable_password": c.get("enable_password", ""),
                "api_token": c.get("api_token", ""),
            }

    # ── filesystem helpers ─────────────────────────────────────
    def _get_device_type_folder(self, device_type: str) -> str:
        key = device_type.lower()
        return self.DEVICE_TYPE_FOLDERS.get(key, key.capitalize() or "Device")

    def _get_backup_dir(self, device: Dict) -> str:
        """backups/{Location}/{DeviceType}/"""
        location = device.get("location", "Default").strip()
        safe_location = "".join(
            c if c.isalnum() or c in " _-" else "_" for c in location
        ).strip()
        if not safe_location:
            safe_location = "Default"
        type_folder = self._get_device_type_folder(device["device_type"])
        backup_dir = os.path.join(self.backup_base_dir, safe_location, type_folder)
        os.makedirs(backup_dir, exist_ok=True)
        return backup_dir

    def _get_backup_filename(self, device: Dict, timestamp: str) -> str:
        """<ip>_<timestamp>.txt — IP-based per user requirement."""
        raw_ip = str(device.get("ip_address", "unknown"))
        safe_ip = "".join(c if c.isalnum() or c in ".:-_" else "_" for c in raw_ip)
        if not safe_ip:
            safe_ip = "unknown"
        return f"{safe_ip}_{timestamp}.txt"

    # ── reachability ───────────────────────────────────────────
    def _test_reachability(self, ip: str, port: int, timeout: int = 5) -> Tuple[bool, str]:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((ip, port))
            sock.close()
            if result == 0:
                return True, ""
            return False, f"Connection refused on {ip}:{port}"
        except socket.gaierror:
            return False, f"DNS resolution failed for {ip}"
        except socket.timeout:
            return False, f"Connection timed out to {ip}:{port}"
        except Exception as e:
            return False, f"Network error: {e}"

    # ── diff ───────────────────────────────────────────────────
    def _find_previous_backup(self, backup_dir: str, current_filepath: str) -> Optional[str]:
        if not os.path.isdir(backup_dir):
            return None
        candidates = []
        for name in os.listdir(backup_dir):
            if not name.endswith(".txt"):
                continue
            full = os.path.join(backup_dir, name)
            if os.path.abspath(full) == os.path.abspath(current_filepath):
                continue
            candidates.append((os.path.getmtime(full), full))
        if not candidates:
            return None
        candidates.sort(reverse=True)
        return candidates[0][1]

    def _compute_diff(self, previous_path: str, current_text: str) -> Tuple[str, str]:
        try:
            with open(previous_path, "r", encoding="utf-8-sig", errors="replace") as f:
                old_lines = f.read().splitlines()
        except Exception:
            return ("", "")
        old_body = [l for l in old_lines if not l.startswith("!")]
        new_body = [l for l in current_text.splitlines() if not l.startswith("!")]
        diff_lines = list(difflib.unified_diff(
            old_body, new_body,
            fromfile="previous", tofile="current",
            lineterm="",
        ))
        if not diff_lines:
            return ("No changes", "")
        added = sum(1 for l in diff_lines if l.startswith("+") and not l.startswith("+++"))
        removed = sum(1 for l in diff_lines if l.startswith("-") and not l.startswith("---"))
        return (f"+{added} -{removed} lines changed", "\n".join(diff_lines))

    # ── SSH backup (shared by Router/Switch and Firewall fallback) ──
    def _backup_via_ssh(
        self,
        device: Dict,
        netmiko_type: str,
        backup_commands: List[str],
        username: str,
        password: str,
        enable_password: str = "",
        pre_commands: List[str] = None,
        supports_enable: bool = False,
    ) -> str:
        """Connect via SSH and execute the given backup commands."""
        from netmiko import ConnectHandler

        ip = device["ip_address"]
        port = device.get("port", 22)

        device_params = {
            "device_type": netmiko_type,
            "host": ip,
            "port": port,
            "username": username,
            "password": password,
            "timeout": 30,
            "conn_timeout": 15,
        }
        if supports_enable and enable_password:
            device_params["secret"] = enable_password

        connection = ConnectHandler(**device_params)
        try:
            if supports_enable and enable_password:
                try:
                    connection.enable()
                except Exception:
                    pass

            config_sections = []
            for cmd in (pre_commands or []):
                try:
                    connection.send_command(cmd, read_timeout=20, cmd_verify=False)
                except Exception:
                    pass  # best-effort

            for cmd in backup_commands:
                output = connection.send_command(
                    cmd, read_timeout=60, cmd_verify=False
                )
                config_sections.append(
                    f"! Command: {cmd}\n{'=' * 60}\n{output}\n"
                )
            return "\n".join(config_sections)
        finally:
            try:
                connection.disconnect()
            except Exception:
                pass

    # ── API backup wrapper (vendor-specific) ───────────────────
    def _backup_via_api(
        self,
        device: Dict,
        vendor: FirewallVendor,
        username: str,
        password: str,
        api_token: str,
    ) -> str:
        """
        Call the vendor's HTTPS API backup. Returns the raw config text.
        Raises NotImplementedError or RuntimeError on failure.
        """
        return vendor.fetch_via_api(
            host=device["ip_address"],
            port=vendor.api_port,
            username=username,
            password=password,
            api_token=api_token,
        )

    # ── Router/Switch backup entry point ───────────────────────
    def _backup_router_or_switch(self, device: Dict) -> BackupResult:
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        d_id = device["id"]
        hostname = device["hostname"]
        ip = device["ip_address"]
        dtype = device["device_type"]
        vendor_key = device.get("vendor", "cisco_ios")

        # ── Credential resolution (per-device > shared) ────────
        # If the device has its own per-device credentials enabled,
        # use them. Otherwise fall back to the shared SSH creds.
        if device.get("use_device_creds") and device.get("device_username") and device.get("device_password"):
            username = device["device_username"]
            password = device["device_password"]
            enable_password = device.get("device_enable_password", "")
            cred_source = "device-specific"
        elif self._shared_creds.get("username") and self._shared_creds.get("password"):
            username = self._shared_creds["username"]
            password = self._shared_creds["password"]
            enable_password = self._shared_creds.get("enable_password", "")
            cred_source = "shared"
        else:
            return BackupResult(
                device_id=d_id, hostname=hostname, ip_address=ip,
                device_type=dtype, vendor=vendor_key, success=False,
                error_message=(
                    "No credentials available for this Router/Switch. "
                    "Either set shared SSH credentials, or enable "
                    "per-device credentials for this device."
                ),
                timestamp=timestamp,
            )

        # Test reachability
        port = device.get("port", 22)
        reachable, err = self._test_reachability(ip, port)
        if not reachable:
            return BackupResult(
                device_id=d_id, hostname=hostname, ip_address=ip,
                device_type=dtype, vendor=vendor_key, success=False,
                error_message=err, timestamp=timestamp,
            )

        # Look up backup commands for this netmiko vendor
        backup_commands = ROUTER_SWITCH_BACKUP_COMMANDS.get(vendor_key, ["show running-config"])

        # Cisco IOS/XE/NX-OS use enable mode
        supports_enable = "cisco" in vendor_key and vendor_key != "cisco_xr"

        try:
            config_text = self._backup_via_ssh(
                device=device,
                netmiko_type=vendor_key,
                backup_commands=backup_commands,
                username=username,
                password=password,
                enable_password=enable_password,
                supports_enable=supports_enable,
            )
        except ImportError:
            return BackupResult(
                device_id=d_id, hostname=hostname, ip_address=ip,
                device_type=dtype, vendor=vendor_key, success=False,
                error_message="netmiko library not installed. Run: pip install netmiko",
                timestamp=timestamp,
            )
        except Exception as e:
            return BackupResult(
                device_id=d_id, hostname=hostname, ip_address=ip,
                device_type=dtype, vendor=vendor_key, success=False,
                error_message=sanitize_error_message(str(e), username, ip), timestamp=timestamp,
            )

        return self._save_backup(device, config_text, "ssh", timestamp)

    # ── Firewall backup entry point (vendor registry dispatch) ──
    def _backup_firewall(self, device: Dict) -> BackupResult:
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        d_id = device["id"]
        hostname = device["hostname"]
        ip = device["ip_address"]
        dtype = device["device_type"]
        vendor_key = device.get("vendor", "fortigate")
        vendor = get_vendor(vendor_key)

        if vendor is None:
            return BackupResult(
                device_id=d_id, hostname=hostname, ip_address=ip,
                device_type=dtype, vendor=vendor_key, success=False,
                error_message=f"Unknown firewall vendor '{vendor_key}'.",
                timestamp=timestamp,
            )

        # ── Credential resolution (per-device > per-vendor > single-cred) ──
        # If the device has its own per-device credentials enabled, use them
        # (overrides both per-vendor and shared/single-cred creds).
        if device.get("use_device_creds") and device.get("device_username") and device.get("device_password"):
            username = device["device_username"]
            password = device["device_password"]
            enable_password = device.get("device_enable_password", "")
            api_token = ""  # per-device creds don't include API tokens
        else:
            # Fall back to per-vendor creds (which may have been auto-filled
            # from shared creds by single-credential mode in the GUI)
            creds = self._fw_credentials.get(vendor_key) or {}
            username = creds.get("username", "")
            password = creds.get("password", "")
            enable_password = creds.get("enable_password", "")
            api_token = creds.get("api_token", "")

        has_ssh_creds = bool(username and password)
        has_api_creds = bool(api_token or (username and password))

        usable_methods = []
        for method in vendor.backup_priority:
            if method == "ssh" and vendor.ssh_supported and has_ssh_creds:
                usable_methods.append("ssh")
            elif method == "api" and vendor.api_supported and has_api_creds:
                usable_methods.append("api")

        if not usable_methods:
            missing = []
            if "ssh" in vendor.backup_priority and not has_ssh_creds:
                missing.append("SSH username+password")
            if "api" in vendor.backup_priority and not has_api_creds:
                missing.append(
                    f"API token{' or username+password' if vendor.api_auth_mode == 'either' else ''}"
                )
            return BackupResult(
                device_id=d_id, hostname=hostname, ip_address=ip,
                device_type=dtype, vendor=vendor_key, success=False,
                error_message=(
                    f"No usable credentials for firewall vendor '{vendor.label}'. "
                    f"Need: {', '.join(missing) if missing else 'credentials'}. "
                    "Use Set Firewall Credentials (per vendor) first."
                ),
                timestamp=timestamp,
            )

        # Iterate through usable methods
        config_text = None
        method_used = ""
        errors_per_method = []

        for method in usable_methods:
            if method == "ssh":
                port = device.get("port", 22)
                reachable, err = self._test_reachability(ip, port)
                if not reachable:
                    errors_per_method.append(f"SSH: {err}")
                    continue
                try:
                    config_text = self._backup_via_ssh(
                        device=device,
                        netmiko_type=vendor.netmiko_type,
                        backup_commands=vendor.backup_commands,
                        username=username,
                        password=password,
                        enable_password=enable_password,
                        pre_commands=vendor.pre_commands,
                        supports_enable=vendor.supports_enable,
                    )
                    method_used = "ssh"
                    break
                except ImportError:
                    return BackupResult(
                        device_id=d_id, hostname=hostname, ip_address=ip,
                        device_type=dtype, vendor=vendor_key, success=False,
                        error_message="netmiko library not installed. Run: pip install netmiko",
                        timestamp=timestamp,
                    )
                except Exception as e:
                    errors_per_method.append(f"SSH: {e}")
                    config_text = None

            elif method == "api":
                reachable, err = self._test_reachability(ip, vendor.api_port)
                if not reachable:
                    errors_per_method.append(f"API(port {vendor.api_port}): {err}")
                    continue
                try:
                    config_text = self._backup_via_api(
                        device, vendor, username, password, api_token,
                    )
                    method_used = "api"
                    break
                except NotImplementedError as e:
                    errors_per_method.append(f"API: {e}")
                    config_text = None
                except Exception as e:
                    errors_per_method.append(f"API: {e}")
                    config_text = None

        if config_text is None:
            return BackupResult(
                device_id=d_id, hostname=hostname, ip_address=ip,
                device_type=dtype, vendor=vendor_key, success=False,
                error_message=" | ".join(errors_per_method) or "All backup methods failed",
                timestamp=timestamp,
            )

        return self._save_backup(device, config_text, method_used, timestamp)

    # ── shared save+diff routine ───────────────────────────────
    def _save_backup(
        self,
        device: Dict,
        config_text: str,
        method: str,
        timestamp: str,
    ) -> BackupResult:
        backup_dir = self._get_backup_dir(device)
        filename = self._get_backup_filename(device, timestamp)
        filepath = os.path.join(backup_dir, filename)

        # Vendor label for the header
        from vendors import vendor_label as _vendor_label
        dtype = device["device_type"]
        vendor_key = device.get("vendor", "")
        if dtype == "firewall":
            vendor_display = _vendor_label(vendor_key)
        else:
            vendor_display = vendor_key

        header = (
            f"! Backup: {device['hostname']} ({device['ip_address']})\n"
            f"! Device Type: {dtype.title()}\n"
            f"! Vendor: {vendor_display}\n"
            f"! Location: {device.get('location', 'N/A')}\n"
            f"! Backup method: {method.upper()}\n"
            f"! Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"! {'=' * 60}\n\n"
        )
        full_text = header + config_text

        try:
            with open(filepath, "w", encoding="utf-8-sig", newline="\n") as f:
                f.write(full_text)
        except OSError as e:
            return BackupResult(
                device_id=device["id"],
                hostname=device["hostname"],
                ip_address=device["ip_address"],
                device_type=dtype,
                vendor=vendor_key,
                success=False,
                error_message=f"Failed to write backup file: {sanitize_error_message(str(e))}",
                timestamp=timestamp,
            )

        # Compute diff vs previous backup
        prev_path = self._find_previous_backup(backup_dir, filepath)
        diff_summary = ""
        diff_text = ""
        if prev_path:
            diff_summary, diff_text = self._compute_diff(prev_path, full_text)
        else:
            diff_summary = "First backup (no previous version)"

        return BackupResult(
            device_id=device["id"],
            hostname=device["hostname"],
            ip_address=device["ip_address"],
            device_type=dtype,
            vendor=vendor_key,
            success=True,
            filepath=filepath,
            timestamp=timestamp,
            config_text=full_text,
            backup_method=method,
            diff_summary=diff_summary,
            diff_text=diff_text,
        )

    # ── public dispatch ────────────────────────────────────────
    def backup_device(self, device: Dict) -> BackupResult:
        """Back up a single device. Dispatches based on device_type."""
        dtype = device["device_type"].lower()
        if dtype == "firewall":
            return self._backup_firewall(device)
        else:
            # Router or Switch
            return self._backup_router_or_switch(device)

    def backup_all(
        self,
        devices: List[Dict],
        progress_callback=None,
    ) -> List[BackupResult]:
        results = []
        total = len(devices)
        for index, dev in enumerate(devices):
            result = self.backup_device(dev)
            results.append(result)
            if progress_callback:
                try:
                    progress_callback(index + 1, total, result)
                except Exception:
                    pass
        return results

    # ── stats ──────────────────────────────────────────────────
    def get_backup_count(self) -> Dict:
        """Walk backups/{Location}/{DeviceType}/ and count files."""
        stats = {
            "routers": 0, "switches": 0, "firewalls": 0,
            "total": 0, "locations": {},
        }
        if not os.path.exists(self.backup_base_dir):
            return stats

        folder_to_key = {
            "Router": "routers",
            "Switches": "switches",
            "Firewall": "firewalls",
        }
        for location in os.listdir(self.backup_base_dir):
            loc_path = os.path.join(self.backup_base_dir, location)
            if not os.path.isdir(loc_path):
                continue
            for type_folder in os.listdir(loc_path):
                type_path = os.path.join(loc_path, type_folder)
                if not os.path.isdir(type_path):
                    continue
                files = [f for f in os.listdir(type_path) if f.endswith(".txt")]
                count = len(files)
                if count == 0:
                    continue
                stats["total"] += count
                stats["locations"][f"{location}/{type_folder}"] = count
                stat_key = folder_to_key.get(type_folder)
                if stat_key:
                    stats[stat_key] += count
        return stats
