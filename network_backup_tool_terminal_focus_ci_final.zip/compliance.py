"""
Compliance Check Engine
=======================

Pre-built compliance rules that check device running-configs against
common security best practices. Inspired by enterprise NCM tools
(SolarWinds NCM, ManageEngine NCM) compliance modules.

Each rule is a simple function that takes a running-config string and
returns (passed: bool, details: str).
"""

import re
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple


@dataclass
class ComplianceRule:
    """A single compliance check rule."""
    key: str
    label: str
    description: str
    category: str  # "Security", "Best Practice", "Network"
    check_fn: Callable[[str], Tuple[bool, str]]


@dataclass
class ComplianceResult:
    """Result of running a compliance check against one device."""
    rule_key: str
    rule_label: str
    category: str
    passed: bool
    details: str


@dataclass
class DeviceComplianceReport:
    """Compliance results for a single device."""
    device_id: str
    hostname: str
    ip_address: str
    results: List[ComplianceResult] = field(default_factory=list)

    @property
    def passed_count(self) -> int:
        return sum(1 for r in self.results if r.passed)

    @property
    def failed_count(self) -> int:
        return sum(1 for r in self.results if not r.passed)

    @property
    def total_count(self) -> int:
        return len(self.results)

    @property
    def compliance_score(self) -> float:
        """Percentage of rules that passed (0-100)."""
        if not self.results:
            return 0.0
        return (self.passed_count / self.total_count) * 100.0


# ════════════════════════════════════════════════════════════════
# BUILT-IN COMPLIANCE RULES
# ════════════════════════════════════════════════════════════════

def _check_ssh_enabled(config: str) -> Tuple[bool, str]:
    """Check if SSH is enabled (transport input ssh on VTY lines)."""
    if re.search(r"transport\s+input\s+ssh", config, re.IGNORECASE):
        return True, "SSH is enabled on VTY lines"
    return False, "SSH not found in VTY configuration"


def _check_no_telnet(config: str) -> Tuple[bool, str]:
    """Check that telnet is NOT enabled (security best practice)."""
    # Look for 'transport input telnet' — if present, telnet is enabled
    if re.search(r"transport\s+input\s+.*telnet", config, re.IGNORECASE):
        return False, "Telnet is enabled on VTY lines (security risk)"
    return True, "Telnet is not enabled"


def _check_banner_set(config: str) -> Tuple[bool, str]:
    """Check if a login banner is configured."""
    if re.search(r"banner\s+(login|motd)", config, re.IGNORECASE):
        return True, "Login banner is configured"
    return False, "No login banner configured (recommended for legal/compliance)"


def _check_password_encryption(config: str) -> Tuple[bool, str]:
    """Check if password encryption is enabled."""
    if re.search(r"service\s+password-encryption", config, re.IGNORECASE):
        return True, "Password encryption is enabled"
    return False, "Password encryption is NOT enabled (passwords stored in plaintext)"


def _check_enable_secret(config: str) -> Tuple[bool, str]:
    """Check if enable secret is set (not just enable password)."""
    if re.search(r"enable\s+secret", config, re.IGNORECASE):
        return True, "Enable secret is configured"
    if re.search(r"enable\s+password", config, re.IGNORECASE):
        return False, "Using 'enable password' instead of 'enable secret' (not encrypted)"
    return False, "No enable password/secret configured"


def _check_snmp_v3(config: str) -> Tuple[bool, str]:
    """Check if SNMP v3 is configured (preferred over v1/v2c)."""
    if re.search(r"snmp-server\s+group\s+.+\s+v3", config, re.IGNORECASE):
        return True, "SNMP v3 is configured"
    if re.search(r"snmp-server\s+community", config, re.IGNORECASE):
        # Check if it's v1/v2c only
        return False, "SNMP v1/v2c community strings found — SNMP v3 recommended"
    return True, "No SNMP configured (informational)"


def _check_ssh_version_2(config: str) -> Tuple[bool, str]:
    """Check if SSH version 2 is enforced."""
    if re.search(r"ip\s+ssh\s+version\s+2", config, re.IGNORECASE):
        return True, "SSH version 2 is enforced"
    if re.search(r"ip\s+ssh", config, re.IGNORECASE):
        return False, "SSH is configured but version 2 is not explicitly set"
    return False, "SSH is not configured"


def _check_logging_enabled(config: str) -> Tuple[bool, str]:
    """Check if syslog logging is configured."""
    if re.search(r"logging\s+\d+\.\d+\.\d+\.\d+", config, re.IGNORECASE):
        return True, "Syslog logging to a remote server is configured"
    if re.search(r"logging\s+buffered", config, re.IGNORECASE):
        return True, "Buffered logging is enabled (but no remote syslog server)"
    return False, "No logging configured (recommended for troubleshooting)"


def _check_no_unused_ports(config: str) -> Tuple[bool, str]:
    """Check if unused interfaces are administratively down (informational)."""
    # This is a best-effort check — look for 'shutdown' on interfaces
    shutdown_count = len(re.findall(r"^\s*shutdown\s*$", config, re.MULTILINE))
    if shutdown_count > 0:
        return True, f"{shutdown_count} interface(s) are shut down (good practice for unused ports)"
    return True, "No shut down interfaces found"


def _check_ntp_configured(config: str) -> Tuple[bool, str]:
    """Check if NTP is configured for time synchronization."""
    if re.search(r"ntp\s+server", config, re.IGNORECASE):
        return True, "NTP server is configured"
    return False, "No NTP server configured (time sync is important for logs/certs)"


# ════════════════════════════════════════════════════════════════
# RULE REGISTRY
# ════════════════════════════════════════════════════════════════

ALL_RULES: List[ComplianceRule] = [
    ComplianceRule(
        key="ssh_enabled", label="SSH Enabled",
        description="SSH should be enabled for secure remote access",
        category="Security",
        check_fn=_check_ssh_enabled,
    ),
    ComplianceRule(
        key="no_telnet", label="No Telnet",
        description="Telnet should be disabled (sends passwords in plaintext)",
        category="Security",
        check_fn=_check_no_telnet,
    ),
    ComplianceRule(
        key="ssh_v2", label="SSH Version 2",
        description="SSH version 2 should be enforced (v1 has known vulnerabilities)",
        category="Security",
        check_fn=_check_ssh_version_2,
    ),
    ComplianceRule(
        key="password_encryption", label="Password Encryption",
        description="Service password-encryption should be enabled",
        category="Security",
        check_fn=_check_password_encryption,
    ),
    ComplianceRule(
        key="enable_secret", label="Enable Secret",
        description="Enable secret should be used (not enable password)",
        category="Security",
        check_fn=_check_enable_secret,
    ),
    ComplianceRule(
        key="banner", label="Login Banner",
        description="A login banner should be configured for legal/compliance",
        category="Best Practice",
        check_fn=_check_banner_set,
    ),
    ComplianceRule(
        key="snmp_v3", label="SNMP v3",
        description="SNMP v3 is preferred over v1/v2c for security",
        category="Security",
        check_fn=_check_snmp_v3,
    ),
    ComplianceRule(
        key="logging", label="Syslog Logging",
        description="Remote syslog logging should be configured",
        category="Best Practice",
        check_fn=_check_logging_enabled,
    ),
    ComplianceRule(
        key="ntp", label="NTP Time Sync",
        description="NTP should be configured for accurate timestamps",
        category="Best Practice",
        check_fn=_check_ntp_configured,
    ),
    ComplianceRule(
        key="unused_ports", label="Unused Ports Shutdown",
        description="Unused interfaces should be administratively shut down",
        category="Best Practice",
        check_fn=_check_no_unused_ports,
    ),
]

RULE_BY_KEY: Dict[str, ComplianceRule] = {r.key: r for r in ALL_RULES}


def run_compliance_check(
    config_text: str,
    rules: Optional[List[ComplianceRule]] = None,
) -> List[ComplianceResult]:
    """Run compliance rules against a device's running-config.

    Args:
        config_text: the running-config output from the device
        rules: list of rules to check (default: all rules)

    Returns:
        List of ComplianceResult objects
    """
    if rules is None:
        rules = ALL_RULES

    results = []
    for rule in rules:
        try:
            passed, details = rule.check_fn(config_text)
        except Exception as e:
            passed = False
            details = f"Error checking rule: {e}"
        results.append(ComplianceResult(
            rule_key=rule.key,
            rule_label=rule.label,
            category=rule.category,
            passed=passed,
            details=details,
        ))
    return results


def run_compliance_for_device(
    device: dict,
    config_text: str,
    rules: Optional[List[ComplianceRule]] = None,
) -> DeviceComplianceReport:
    """Run all compliance rules against one device's config."""
    results = run_compliance_check(config_text, rules)
    return DeviceComplianceReport(
        device_id=device.get("id", "?"),
        hostname=device.get("hostname", "?"),
        ip_address=device.get("ip_address", "?"),
        results=results,
    )
