"""
PuTTY Window Embedding (Windows only)
======================================

Embeds real putty.exe windows into this application's own tab strip,
the same technique used by SuperPuTTY / MTPuTTY: putty.exe is launched
as a normal process, its top-level window is located, stripped of its
title bar/borders, and reparented (Win32 SetParent) into a Tk frame
that lives inside our notebook tab.

This is NOT a reimplementation of a terminal — the actual PuTTY
process is doing 100% of the SSH connection, key handling, and VT100
rendering. That's the whole point: every terminal-fidelity issue
(colour, cursor-addressed full-screen apps, resize, key handling
quirks) is resolved "for free" because it really is PuTTY.

Trade-offs (documented honestly, not hidden):
  - Windows-only. SetParent/reparenting a native HWND across process
    boundaries is a Win32-specific mechanism; there is no equivalent
    for embedding a foreign top-level window on Linux/Mac from Tk.
  - Somewhat fragile by nature of the technique: focus-follows-tab
    requires an AttachThreadInput trick (implemented below), and some
    PuTTY versions can flicker on resize. This mirrors known,
    long-standing quirks of SuperPuTTY/MTPuTTY, not bugs unique to
    this implementation.
  - No programmatic access to what's "inside" the shell (no direct
    channel.send() the way the old paramiko-backed tab had). Anything
    that needs programmatic command injection (bulk config push,
    compliance checks, diagnostics) should keep using the existing
    independent ConfigPusher/paramiko path — it already does, since
    those features open their own separate SSH connection rather than
    reusing the interactive tab's channel.

Only import/use this module when sys.platform == "win32". Call
is_supported() first and fail gracefully (fall back to "External
PuTTY" / separate window mode) everywhere else.
"""

import subprocess
import sys
import time
from typing import Optional


def is_supported() -> bool:
    return sys.platform == "win32"


if is_supported():
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    GWL_STYLE = -16
    WS_CHILD = 0x40000000
    WS_VISIBLE = 0x10000000
    WS_CAPTION = 0x00C00000
    WS_THICKFRAME = 0x00040000
    WS_SYSMENU = 0x00080000
    WS_MINIMIZEBOX = 0x00020000
    WS_MAXIMIZEBOX = 0x00010000
    WS_POPUP = 0x80000000
    WS_BORDER = 0x00800000
    WS_DLGFRAME = 0x00400000

    SWP_FRAMECHANGED = 0x0020
    SWP_NOZORDER = 0x0004
    SWP_NOACTIVATE = 0x0010
    SWP_SHOWWINDOW = 0x0040

    WM_CLOSE = 0x0010
    WM_CHAR = 0x0102
    WM_SETFOCUS = 0x0007
    WM_ACTIVATE = 0x0006
    WM_NCACTIVATE = 0x0086
    WM_MOUSEACTIVATE = 0x0021
    MA_ACTIVATE = 1
    WA_ACTIVE = 1
    GA_ROOT = 2
    VK_LBUTTON = 0x01

    EnumWindowsProc = ctypes.WINFUNCTYPE(
        ctypes.c_bool, wintypes.HWND, wintypes.LPARAM
    )

    class POINT(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

    # ── Explicit restype/argtypes for every Win32 call we use ──────
    # This matters more than it looks: several of these return
    # pointer-sized values (HWND, HMODULE, HHOOK). Without an explicit
    # .restype, ctypes assumes a 32-bit int return on ALL platforms —
    # including 64-bit Windows — which silently truncates the upper
    # 32 bits of any real 64-bit handle/address. An earlier version of
    # this module hit exactly this: GetModuleHandleW()'s truncated
    # return value was fed into SetWindowsHookExW() as a corrupted
    # module handle, which made hook installation fail silently every
    # time (SetWindowsHookExW returned NULL, unchecked). Declaring
    # types explicitly here removes that whole bug class.
    user32.EnumWindows.restype = wintypes.BOOL
    user32.EnumWindows.argtypes = [EnumWindowsProc, wintypes.LPARAM]
    user32.GetWindowTextLengthW.restype = ctypes.c_int
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextW.restype = ctypes.c_int
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetClassNameW.restype = ctypes.c_int
    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.IsWindowVisible.restype = wintypes.BOOL
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.IsWindow.restype = wintypes.BOOL
    user32.IsWindow.argtypes = [wintypes.HWND]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowLongW.restype = ctypes.c_long
    user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.SetWindowLongW.restype = ctypes.c_long
    user32.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
    user32.SetParent.restype = wintypes.HWND
    user32.SetParent.argtypes = [wintypes.HWND, wintypes.HWND]
    user32.SetWindowPos.restype = wintypes.BOOL
    user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int,
                                     ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
    user32.MoveWindow.restype = wintypes.BOOL
    user32.MoveWindow.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                   ctypes.c_int, ctypes.c_int, wintypes.BOOL]
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.GetForegroundWindow.argtypes = []
    user32.SetForegroundWindow.restype = wintypes.BOOL
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.SetFocus.restype = wintypes.HWND
    user32.SetFocus.argtypes = [wintypes.HWND]
    user32.SetActiveWindow.restype = wintypes.HWND
    user32.SetActiveWindow.argtypes = [wintypes.HWND]
    user32.BringWindowToTop.restype = wintypes.BOOL
    user32.BringWindowToTop.argtypes = [wintypes.HWND]
    user32.GetAncestor.restype = wintypes.HWND
    user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetFocus.restype = wintypes.HWND
    user32.GetFocus.argtypes = []
    user32.AttachThreadInput.restype = wintypes.BOOL
    user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
    user32.PostMessageW.restype = wintypes.BOOL
    user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user32.WindowFromPoint.restype = wintypes.HWND
    user32.WindowFromPoint.argtypes = [POINT]
    user32.GetCursorPos.restype = wintypes.BOOL
    user32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
    user32.GetAsyncKeyState.restype = ctypes.c_short
    user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    kernel32.GetCurrentThreadId.restype = wintypes.DWORD
    kernel32.GetCurrentThreadId.argtypes = []


class PuttyLaunchError(Exception):
    pass


def launch(putty_path: str, host: str, port: int, username: str,
           password: str = "", extra_args: Optional[list] = None) -> subprocess.Popen:
    """Start putty.exe.

    Passes the password via -pw so PuTTY authenticates silently
    instead of showing its own password prompt (per explicit request
    — the trade-off is that a command-line argument is technically
    visible to other processes/users on the same local machine via
    the process list, same as any -pw usage).
    """
    args = [putty_path, "-ssh", host, "-P", str(port)]
    if username:
        args += ["-l", username]
    if password:
        args += ["-pw", password]
    if extra_args:
        args += extra_args
    try:
        return subprocess.Popen(args)
    except Exception as e:
        raise PuttyLaunchError(str(e))


def find_window_by_pid(pid: int, timeout: float = 8.0) -> Optional[int]:
    """Poll for a visible top-level window owned by the given process
    id, whose window class is PuTTY's own ("PuTTY"). Returns the HWND
    (as an int) or None if nothing matched in time.

    PID-matching avoids needing any window-title trick at all, and
    the window-class check guards against accidentally grabbing some
    unrelated window the same process might transiently own (e.g. a
    Windows security/UAC-style dialog)."""
    if not is_supported():
        return None

    deadline = time.time() + timeout
    found = {"hwnd": None}

    def _callback(hwnd, lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        win_pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(win_pid))
        if win_pid.value != pid:
            return True
        cls_buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, cls_buf, 256)
        if cls_buf.value != "PuTTY":
            return True
        found["hwnd"] = hwnd
        return False  # stop enumeration

    cb = EnumWindowsProc(_callback)
    while time.time() < deadline:
        found["hwnd"] = None
        user32.EnumWindows(cb, 0)
        if found["hwnd"]:
            return int(found["hwnd"])
        time.sleep(0.15)
    return None


def embed(hwnd: int, container_hwnd: int, width: int, height: int):
    """Strip the PuTTY window's decorations and reparent it inside
    container_hwnd (the HWND of a Tk frame — on Windows, Tk widgets
    are real native windows, so frame.winfo_id() gives a usable HWND)."""
    if not is_supported():
        return

    style = user32.GetWindowLongW(hwnd, GWL_STYLE)
    style &= ~(WS_CAPTION | WS_THICKFRAME | WS_SYSMENU |
               WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_POPUP |
               WS_BORDER | WS_DLGFRAME)
    style |= WS_CHILD | WS_VISIBLE
    user32.SetWindowLongW(hwnd, GWL_STYLE, style)

    user32.SetParent(hwnd, container_hwnd)
    user32.SetWindowPos(
        hwnd, 0, 0, 0, max(1, width), max(1, height),
        SWP_FRAMECHANGED | SWP_NOZORDER | SWP_SHOWWINDOW,
    )


def resize(hwnd: int, width: int, height: int):
    if not is_supported() or not hwnd:
        return
    try:
        user32.MoveWindow(hwnd, 0, 0, max(1, width), max(1, height), True)
    except Exception:
        pass


def focus(hwnd: int):
    """Give the embedded PuTTY window keyboard focus AND tell it it's
    active. These are two different things and both are needed:

    - SetFocus (via the AttachThreadInput dance, since cross-thread
      SetFocus silently fails without it) makes Windows route
      keyboard input to hwnd.
    - WS_CHILD windows never receive a real WM_ACTIVATE/WM_NCACTIVATE
      from Windows — that's only ever sent to top-level windows. But
      PuTTY's own internal "am I active, should I actually process
      keystrokes" state is driven by exactly those messages, not by
      WM_SETFOCUS alone. Without nudging them directly, SetFocus can
      succeed (Windows considers the window focused) while PuTTY
      itself still behaves as if inactive and ignores typed input —
      which shows up as "it looks focused but nothing types."
      Sending WM_NCACTIVATE / WM_ACTIVATE / WM_SETFOCUS directly is
      the standard workaround other PuTTY-embedding tools use for
      this exact class of window.
    """
    if not is_supported() or not hwnd:
        return
    try:
        target_thread = user32.GetWindowThreadProcessId(hwnd, None)
        cur_thread = kernel32.GetCurrentThreadId()
        if target_thread and target_thread != cur_thread:
            user32.AttachThreadInput(cur_thread, target_thread, True)
        # A reparented PuTTY window is a child of our Tk frame, so Windows
        # does not perform the normal top-level activation sequence after a
        # click.  Re-activate the child and its root window explicitly.
        # The AttachThreadInput dance is required because PuTTY owns the
        # child window from a different GUI thread/process.
        root_hwnd = user32.GetAncestor(hwnd, GA_ROOT) or hwnd
        user32.SetForegroundWindow(root_hwnd)
        user32.BringWindowToTop(hwnd)
        user32.SetActiveWindow(root_hwnd)
        user32.SetFocus(hwnd)
        if target_thread and target_thread != cur_thread:
            user32.AttachThreadInput(cur_thread, target_thread, False)

        # PuTTY also tracks activation internally.  Explicitly send the
        # activation/focus messages because SetParent changes the normal
        # WM_ACTIVATE lifecycle.  WM_MOUSEACTIVATE mirrors a real click.
        user32.SendMessageW(hwnd, WM_MOUSEACTIVATE, root_hwnd, 0)
        user32.SendMessageW(hwnd, WM_NCACTIVATE, 1, 0)
        user32.SendMessageW(hwnd, WM_ACTIVATE, WA_ACTIVE, 0)
        user32.SendMessageW(hwnd, WM_SETFOCUS, 0, 0)
    except Exception:
        pass


def is_window_alive(hwnd: int) -> bool:
    if not is_supported() or not hwnd:
        return False
    try:
        return bool(user32.IsWindow(hwnd))
    except Exception:
        return False


def close(hwnd: int):
    if not is_supported() or not hwnd:
        return
    try:
        user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
    except Exception:
        pass


# ── Keystroke injection (auto-enable-mode) ──────────────────────
def send_text(hwnd: int, text: str, char_delay: float = 0.02):
    """Post characters into hwnd's message queue one at a time.

    Uses PostMessage rather than requiring OS focus — it delivers
    straight to the target window's queue regardless of what's
    currently focused, which is what lets us auto-type "enable" +
    the enable secret right after connecting without having to fight
    over focus. Call from a background thread; this sleeps between
    characters (some apps drop rapid-fire WM_CHAR bursts otherwise).
    """
    if not is_supported() or not hwnd:
        return
    for ch in text:
        if ch == "\n":
            continue
        code = 13 if ch == "\r" else ord(ch)
        try:
            user32.PostMessageW(hwnd, WM_CHAR, code, 0)
        except Exception:
            pass
        time.sleep(char_delay)


def auto_enable_sequence(hwnd: int, enable_password: str):
    """Replicates the old paramiko-backed flow's automatic elevation:
    type 'enable', the enable secret, then 'terminal length 0' to
    turn off pagination — same commands, same pacing as the old
    SSHTerminal.connect() used. Meant to be run in a background
    thread (it sleeps); call after the shell has had a moment to
    reach its prompt."""
    if not is_supported() or not hwnd or not enable_password:
        return
    time.sleep(1.0)  # let the login banner / initial prompt settle
    send_text(hwnd, "enable\r")
    time.sleep(0.3)
    send_text(hwnd, enable_password + "\r")
    time.sleep(0.3)
    send_text(hwnd, "terminal length 0\r")


# ── Click-to-refocus watcher ─────────────────────────────────────
# Reparented child windows don't reliably reclaim keyboard focus when
# clicked after focus moved elsewhere (a known quirk of this
# embedding technique — PuTTY's own click-to-focus handling doesn't
# fire the same way once it's been forced into WS_CHILD style).
#
# This is deliberately a plain poll (GetCursorPos + GetAsyncKeyState)
# rather than a WH_MOUSE_LL system hook. A low-level hook is the
# "proper" tool for this, but it's also failure-prone in exactly the
# way that bit us here — it install/uninstalls silently, so a bug in
# the installation call (wrong argument types, a module handle
# mismatch, security software blocking global hooks, etc.) leaves you
# with no visible error and the exact symptom reported: it "should"
# work but doesn't. Polling from inside our own already-running Tk
# event loop has no separate install step to fail and is trivial to
# verify by reading the code. The cost is up to ~80ms latency on the
# very first click after switching away, which is imperceptible.
def get_cursor_pos():
    pt = POINT()
    if not is_supported():
        return (0, 0)
    user32.GetCursorPos(ctypes.byref(pt))
    return (pt.x, pt.y)


def is_left_button_down() -> bool:
    if not is_supported():
        return False
    state = user32.GetAsyncKeyState(VK_LBUTTON)
    return bool(state & 0x8000)
