#!/usr/bin/env bash
# ============================================================
#  Network Backup Tool - PyInstaller build script (Linux/macOS)
# ============================================================
set -e

echo "Building Network Backup Tool executable..."

python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
python3 -m pip install pyinstaller

python3 -m PyInstaller --noconfirm --clean --windowed \
    --name "NetworkBackupTool" \
    --hidden-import netmiko \
    --hidden-import reportlab \
    --hidden-import paramiko \
    main.py

echo
echo "Build complete. The executable is in: dist/NetworkBackupTool/"
